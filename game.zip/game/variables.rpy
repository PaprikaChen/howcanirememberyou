## 剧情状态 ######################################################################
##
## 一律用 default（会写进存档、随回滚恢复，新游戏重置），不要用 define 或 persistent。
## 这些状态只用于条件文本 / 回声，不做好感累加。

## 开头内容提示页：是否开启限时选择（screens.rpy 的 choice 界面读取）。
default timed_choices = True

## 玩家花名。序幕中由预设按钮或 name_input.rpy 的输入界面写入。
## TeacherName 见 name_input.rpy：预设名随语言显示，英文为 Ginger。
default teacher_name = TeacherName("小姜")

## 第一幕：先听小麦解释 "listen" ／ 先问男孩 "boys" ／ 先自我介绍 "introduce"
default first_contact = None

## 第二幕：进小卖部前是否和门口的人打招呼（影响第一夜蚊香、第三幕开头、第七幕大叔的态度）
default greeted_villagers = False

## 第二幕：床单 "pink" ／ "blue" ／ "gray" ／ "black"
default sheet_choice = None

## 以下为第三幕（续）至尾声。全部为隐性变量，不弹提示。

## 主变量：小麦对“我”的信任。起始 0，约 −3 到 4；阈值 高 ≥4 ／ 中 2–3 ／ 低 ≤1（麦仔死了的照片结局为 ≥3）。
default trust = 0

## 第三幕编辫子小游戏（game/braid_game.rpy）：是否中途放下小麦的辫子去帮男孩修电扇；
## 难过或生气走开的同学 "girls" ／ "boy" ／ "tattle"。碎片二、第八幕有回响。
default braid_left = False
default braid_upset = ()
default braid_run = None

## 第四幕：是否邀请小麦当照片的主角（胶片摄影大赛）。False 时摄影师・心声不再出现。
default camera = False

## 第四幕：是否邀请小麦当照片的主角。False 时拍空教室。
default mai_subject = False

## camera = True 时拍下的照片 photos、糊掉的 blurred 和胶卷张数，见 game/photo_game.rpy。

## 第六幕：小麦讲过三妹的事后为 True，是第七幕博弈“讲小麦三妹的事”的出现条件。
default sister_memory = False

## 第七幕：第一次选择 "wait"（等其他老师）／ "rush"（冲上去）／ "stay"（不插手）；是否先试过报警
default action = None
default called_police = False

## 第七幕：和大叔博弈的隐藏态度值；≥1 时村子态度 "intact" 并 trust +1，≤0 时 "cold"
default attitude = 0
default listened = False
default paid = False
default bluffed = False

## 第七幕：等老师线当着其他老师说出三妹的事；第八幕小麦会问起，trust −1
default told_secret = False

## 第七幕：麦仔的结果 "fine"（冲上去）／ "lame"（等大家一起，断了一条后腿）／ "dead"（不干涉）
## 村民的态度 "intact" ／ "cold"；不干涉后是否对小麦说谎
default dog = "fine"
default village = "intact"
default lie = False

## 第八幕：回答“你明年还会来吗” "yes" ／ "evade" ／ "no" ／ "silent"（建议，待确认）
default promise = None

## 第八幕：离开前留下的东西 "none" ／ "camera"（儿童相机）／ "hairtie"（发绳）／ "letter"
default gift = None

## 尾声：第一条消息的回复 "now"（热情）／ "brief"（敷衍）／ "later"（晚点再回）
default chat_reply = None

## 尾声：摄影大赛 "full"（投有人物的那张）／ "cut"（只投风景）／ "ask"（先问她）／ "none"（不投）；没拍到人物时为 None
default festival = None
