## 花名输入 ######################################################################
##
## 序幕选择“自己取一个名字”时 call ask_teacher_name。预设按钮（中文 小姜／小雨／栗子，
## 英文 Ginger／Sunny／Hazel）不经过这里，是输入法不可用时的完整备用路径。
##
## 中文输入依赖平台输入法：Windows/macOS 桌面版一般可用；Linux、Android、Web 版
## Ren'Py 对输入法支持有限，可能只能输入字母——此时请用预设名字。
##
## 界面文字的英文写在 story/bilingual_script.md 的 UI 部分。

## 花名最长 8 个字符。输入框多留 2 个字符，好让“小姜老师”“Teacher Bo”这样的误填
## 先去掉“老师”再截断。
define TEACHER_NAME_MAX = 8
define TEACHER_NAME_INPUT_MAX = TEACHER_NAME_MAX + 2

init python:

    import unicodedata

    def _load_font_charset():
        try:
            with renpy.open_file("fonts/SourceHanSansLite.charset.txt", encoding="utf-8") as f:
                return frozenset(f.read()) | {" "}
        except Exception:
            return None     # 找不到字符表时不过滤

    TEACHER_NAME_CHARSET = _load_font_charset()

    ## 预设花名以中文原文保存，英文由主稿 UI/选项翻译给出（小姜 → Ginger 等）。
    TEACHER_NAME_PRESETS = ("小姜", "小雨", "栗子")

    class TeacherName(str):
        """玩家花名。

        值本身是保存进存档的原文：预设名存中文（"小姜"），自定义名存玩家输入。
        在台词和名字栏里插值 [teacher_name] 时走 __format__：预设名按当前语言显示
        （中文“小姜”、英文“Ginger”），切换语言后立即跟着变；自定义名原样显示。
        同时把花括号转义，作用等同于 !q，花名里的字符不会被当作文本标签。
        旧存档里的普通字符串照常显示（只是不随语言切换）。
        """

        __slots__ = ()

        def display(self):
            name = str(self)
            return __(name) if name in TEACHER_NAME_PRESETS else name

        def __format__(self, spec):
            return format(self.display().replace("{", "{{"), spec)

    def clean_teacher_name(raw):
        """把输入整理成安全的花名；整理后为空就回退默认名“小姜”（英文显示为 Ginger）。"""
        name = unicodedata.normalize("NFC", raw or "")

        # 去掉控制字符、格式字符、换行，以及会被当作文本标签或插值的符号。
        name = "".join(
            ch for ch in name
            if unicodedata.category(ch)[0] not in "CZ" or ch in " 　"
        )
        for ch in "{}[]\\":
            name = name.replace(ch, "")

        # 去掉字体里没有的字，避免名字栏出现缺字方块。
        if TEACHER_NAME_CHARSET is not None:
            name = "".join(ch for ch in name if ch in TEACHER_NAME_CHARSET or ch == "　")

        name = " ".join(name.replace("　", " ").split())

        # 只填名字：去掉误填的“老师”／“Teacher”。
        if name.endswith("老师"):
            name = name[:-2].rstrip()
        if name.lower().startswith("teacher "):
            name = name[8:].lstrip()
        elif name.lower() == "teacher":
            name = ""

        name = name[:TEACHER_NAME_MAX].strip()
        return TeacherName(name or "小姜")


label ask_teacher_name:
    call screen name_input
    $ teacher_name = clean_teacher_name(_return)
    return


screen name_input():
    modal True
    style_prefix "name_input"
    default name_buf = ""

    frame:
        vbox:
            text _("孩子们该怎么称呼我？") style "name_input_prompt"
            text _("只填名字，不用加‘老师’") style "name_input_hint"

            frame:
                style "name_input_field"
                input:
                    value ScreenVariableInputValue("name_buf", returnable=True)
                    length TEACHER_NAME_INPUT_MAX
                    exclude "{}[]\\"
                    pixel_width 560

            textbutton _("确定") action Return(name_buf) id "name_ok"


style name_input_frame:
    xalign 0.5
    yalign 0.42
    xsize 900
    padding (60, 48)
    background Frame("gui/frame.png", gui.frame_borders, tile=gui.frame_tile)

style name_input_vbox:
    xfill True
    spacing 24

style name_input_prompt is default:
    xalign 0.5
    size gui.text_size

style name_input_hint is default:
    xalign 0.5
    size gui.notify_text_size + 6
    color gui.idle_small_color

style name_input_field:
    xalign 0.5
    xsize 640
    padding (40, 16)
    background Frame("gui/frame.png", gui.frame_borders, tile=gui.frame_tile)

style name_input_input is default:
    xalign 0.5
    size gui.text_size
    color gui.accent_color

style name_input_button is button:
    xalign 0.5

style name_input_button_text is button_text:
    size gui.text_size
