## 人物贴纸 ######################################################################
##
## 透明底 PNG 放在 game/images/figures/，在这里定义成图像，剧本里 show 出来：
##
##     show mai back at figure_at(0.43, 0.87), wobble
##     hide mai
##
## figure_at 负责站位（按脚底定位），wobble 负责抖动，两者分开，可随意组合。
## 主稿里用〔代码〕指令写 show / hide。

## 贴纸统一缩放倍数（原图约 1100px 高，缩到约 2/3 屏高以内）。
define figure_zoom = 0.55

image mai back = Transform("images/figures/mai_back.png", zoom=figure_zoom)
image mai questionmark = Transform("images/figures/mai_questionmark.png", zoom=figure_zoom)
## 还没编辫子时的小麦（第一幕、第三幕编辫子之前）：惊慌／平静。
image mai anxious = Transform("images/figures/mai_anxious_sticker.png", zoom=figure_zoom)
image mai calm = Transform("images/figures/mai_calm_sticker.png", zoom=figure_zoom)

## 第六幕鹅群草地：盖住照片里原有的狗和鹅，所以各自单独定大小。
image dog run = Transform("images/figures/dog_run_sticker.png", zoom=0.312)
image geese flock = Transform("images/figures/geese_flock_sticker.png", zoom=0.456)
image goose single = Transform("images/figures/goose_single_sticker.png", zoom=0.228)

## 第三幕醒来时眼前的蝉。
image cicada dead = Transform("images/figures/cicada_deadbody_sticker.png", zoom=0.9)

## 第五幕：麦仔初次登场（站）、山顶送别（坐）；院子里的二妹和四弟。
image dog stand = Transform("images/figures/dog_sticker.png", zoom=0.45)
image dog sit = Transform("images/figures/dog_sit_sticker.png", zoom=0.38)
image kids stand = Transform("images/figures/kids_sticker.png", zoom=figure_zoom)

## 碎片一／碎片二：李子、洗澡的水管、裂屏手机（碎片二两个女孩一起看）。
## 手从画面顶端伸下来，所以站位的 y 取图高（figure_at(0.5, 0.545)）。
image plums hand = Transform("images/figures/plums_in_hand_sticker.png", zoom=0.7)
image hose = Transform("images/figures/hose_sticker.png", zoom=0.5)
image phone cracked = Transform("images/figures/cracked_phone_sticker.png", zoom=0.6)

## 第六幕玉米地：妈妈 → 二妹和四弟打闹 → 二妹躺进草丛，依次替换。
image mother = Transform("images/figures/mother_sticker.png", zoom=figure_zoom)
image kids fight = Transform("images/figures/kids_fight_sticker.png", zoom=figure_zoom)
image sister lying = Transform("images/figures/sister_lying_sticker.png", zoom=0.45)

## 第七幕雨夜：大叔的四种神情（同一个 tag，show 新的会替换旧的），不晃动。
## 是半身像，下沿贴屏幕底边（figure_at(0.68, 1.0)），切口藏在画面外。
image uncle fierce = Transform("images/figures/uncle_fierce_sticker.png", zoom=0.85)
image uncle surprised = Transform("images/figures/uncle_surprised_sticker.png", zoom=0.85)
image uncle tired = Transform("images/figures/uncle_tired_sticker.png", zoom=0.85)
image uncle sigh = Transform("images/figures/uncle_sigh_sticker.png", zoom=0.85)
## 救下麦仔后被抱回来（完好、断腿两种情况都用），不晃动。比屏幕还高，手臂伸出画面下沿（figure_at(0.5, 1.08)）。
image dog hurt = Transform("images/figures/dog_hurt_hug_in_hands_sticker.png", zoom=1.375)


## 站位：x 是脚底中心的横向位置（0 左，1 右），y 是脚底的纵向位置。
## 字幕框占下方约 330px（y > 0.69）。人物和狗可以被字幕挡住下面约 1/3：脚的 y ≈ (750 + 0.3 × 贴纸高) / 1080。
transform figure_at(x=0.5, y=1.02):
    xpos x xanchor 0.5
    ypos y yanchor 1.0


## 轻微缓慢的抖动：左右摇摆 + 上下起伏，一个周期 period 秒。
##   sway  左右摇摆的角度（度）
##   bob   上下起伏的距离（像素）
##   period 一个完整来回的秒数，越大越慢
## 只改 rotate / yoffset，不碰位置，所以可以叠在任何站位 transform 后面。
## 例：更明显的发抖 wobble(sway=2.5, bob=2, period=0.6)；呼吸般的起伏 wobble(sway=0, bob=6, period=4)
transform wobble(sway=0.8, bob=3, period=3.0):
    subpixel True
    block:
        easein period / 4 rotate sway yoffset -bob
        easeout period / 4 rotate 0 yoffset 0
        easein period / 4 rotate -sway yoffset -bob
        easeout period / 4 rotate 0 yoffset 0
        repeat
