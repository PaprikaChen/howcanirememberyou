﻿# 游戏标题英文。

translate english strings:

    # game/options.rpy:14
    old "我不知道该如何回忆你"
    new "I Don't Know How to Remember You"

