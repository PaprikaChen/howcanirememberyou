## 英文翻译。本文件由 tools/build_script.py 从 story/bilingual_script.md 自动生成，不要手改。
## 修改剧情：编辑主稿后运行 python tools/build_script.py。

# CW-020  〔新增〕
translate english CW_020:
    n "A few choices in this game are timed. In those moments you won't have much time to think, and that is part of the story. Turning timers off lets you choose at your own pace, but it may weaken the experience." nointeract

# COLD-010  〔改稿〕
translate english COLD_010:
    n "Many years later, I still remember that sweltering, rainy night."

# COLD-020  〔改稿〕
translate english COLD_020:
    n "Rain hammered on the classroom's tin roof. Someone was knocking on the window."

# COLD-030  〔改稿〕
translate english COLD_030:
    n "It was her. Soaked through, mud caked up to her knees, her braid plastered to her neck. Lightning flashed, and I saw a hair tie with a little yellow duck wound around the end of her braid."

# COLD-040  〔改稿〕
translate english COLD_040:
    n "Her hand was pressed against the glass."

# COLD-050  〔改稿〕
translate english COLD_050:
    unknown_girl "“Teacher, please. Please help me.”"

# INT-010  〔改稿〕
translate english INT_010:
    n "That summer, I had just finished my second year of college."

# INT-020  〔改稿〕
translate english INT_020:
    n "I grew up in Beijing and had hardly ever seen real mountains. Before summer break, I signed up with my university's volunteer teaching team to spend two months at a village primary school in southwestern China."

# INT-022  〔改稿〕
translate english INT_022:
    n "I told the team I wanted to make a documentary about that summer."

# INT-024  〔改稿〕
translate english INT_024:
    n "What I didn't say was that there was a student documentary festival in September, and I wanted to enter it."

# INT-040  〔新增〕
translate english INT_040:
    n "I thought it would just be a “summer camp,” only a bit rougher than most."

# PRO-010  〔L5〕
translate english PRO_010:
    n "Before we left, the volunteer teaching team collected everyone's nicknames in the group chat."

# PRO-020  〔L7〕
translate english PRO_020:
    team "“This is what the children will call us at school. Pick something easy for them to remember and say. It could be a food, a plant, or the weather—something like Ginger, Sunny, or Hazel.”"

# PRO-030  〔L9〕
translate english PRO_030:
    n "I looked at the names appearing on the list and found an empty line for mine."

# PRO-040  〔L13〕
translate english PRO_040:
    n "What should the children call me?"

# PRO-050  〔L15〕
translate english PRO_050:
    n "Enter a name, or choose: Ginger / Sunny / Hazel." nointeract

# PRO-070  〔L19〕
translate english PRO_070:
    n "I wrote my name on the list: [teacher_name]."

# PRO-080  〔L21〕
translate english PRO_080:
    n "Here, I would be Teacher [teacher_name]."

# PRO-090  〔改稿〕
translate english PRO_090:
    n "From the airport, we drove two hours toward the mountains, then caught a three-wheeled cart in town and bounced over ridge after ridge before we finally arrived."

# PRO-095  〔新增〕
translate english PRO_095:
    n "The corn along the road was still green, long silk trailing from the ears."

# A1-010  〔L26〕
translate english A1_010:
    n "The first time I saw her was in the classroom for the older students."

# A1-020  〔改稿〕
translate english A1_020:
    n "During break, a group of girls were laughing and playing together. One glanced over at us, then turned back to whisper in a friend's ear."

# A1-030  〔L30〕
translate english A1_030:
    girl_a "“Hey, did you smell that sour stink on Mai after PE today?”"

# A1-040  〔L32〕
translate english A1_040:
    girl_b "“Keep saying that and I'll tell her you want to sit next to her all summer!”"

# A1-050  〔L34〕
translate english A1_050:
    n "A few whispered remarks drifted over between bursts of laughter."

# A1-060  〔L36〕
translate english A1_060:
    n "With us teachers from beyond the mountains watching and joining in, they seemed to be trying hard to perform an ordinary day. I wondered whether they would act the same way if we weren't there."

# A1-070  〔L38〕
translate english A1_070:
    n "Just then, a girl's indignant voice came from farther down the corridor. Two or three boys who had been hanging around us earlier came running toward the classroom, shouting as they went."

# A1-080  〔L40〕
translate english A1_080:
    boys "“Mai's coming!”"

# A1-090  〔L42〕
translate english A1_090:
    n "A girl, skinny as a bamboo pole and dark from the sun, came stumbling through the back door after them."

# A1-100  〔L44〕
translate english A1_100:
    unknown_girl "“Teacher! He's been making things up about me again!”"

# A1-110  〔L46〕
translate english A1_110:
    n "She pointed at one of the boys who had just run past, still out of breath."

# A1-120  〔L48〕
translate english A1_120:
    n "Her eyelids had no crease, but her eyes were round and bright."

# A1-130  〔L48〕
translate english A1_130:
    n "Her hair was naturally curly, untended and frizzy. But in the evening sunlight coming through the window, it looked soft and fuzzy."

# A1-140  〔L50〕
translate english A1_140:
    n "As soon as she stopped, the other girls casually shifted a couple of steps toward the teacher's desk or the front door. It was as though an invisible boundary had suddenly been drawn around her."

# A1-150  〔L52〕
translate english A1_150:
    n "Their eyes crinkled as they glanced at one another, passing some unspoken joke between them."

# A1-160  〔L54〕
translate english A1_160:
    n "Oh. I thought I had worked it out. The girl with the curly hair was probably {=em}Mai{/=em}."

# A1-170  〔L56〕
translate english A1_170:
    n "She was still glaring at the boy, waiting for him to explain what he'd said. But I found myself looking again at the space that had opened up beside her."

# A1-180  〔L58〕
translate english A1_180:
    inner_teacher "Did she hear what they said? Should I ask what happened?"

# A1-190  〔L60〕
translate english A1_190:
    inner_visitor "We've only just arrived. I can't tell yet whether they're playing or someone has really been hurt."

# A1-200  〔L66〕
translate english A1_200:
    n "I walked over and bent down a little."

# A1-210  〔L68〕
translate english A1_210:
    me "“Your name's Mai, right? What did he say?”"

# A1-220  〔改稿〕
translate english A1_220:
    mei "“I was taking pictures of the clouds that day! He just happened to walk past the window!”"

# A1-230  〔改稿〕
translate english A1_230:
    me "“I see. I believe you.”"

# A1-235  〔改稿〕
translate english A1_235:
    n "I turned to the boys."

# A1-240  〔改稿〕
translate english A1_240:
    me "“Did you hear what she said?”"

# A1-242  〔改稿〕
translate english A1_242:
    n "They gave a half-hearted nod, then all scattered at once and ran out of the classroom."

# A1-244  〔改稿〕
translate english A1_244:
    n "All I could do was sigh and pat Mai on the shoulder."

# A1-246  〔改稿〕
translate english A1_246:
    n "She looked down at my hand, but she didn't pull away."

# A1-250  〔L78〕
translate english A1_250:
    me "“What were you saying just now? Why was she chasing you?”"

# A1-260  〔L80〕
translate english A1_260:
    boy "“Nothing, Teacher. We were only joking.”"

# A1-270  〔改稿〕
translate english A1_270:
    me "“It's only a joke if both people are laughing. Is she laughing?”"

# A1-280  〔改稿〕
translate english A1_280:
    n "The boys looked at one another, mumbled “Sorry,” and bolted. When I turned back, Mai was still standing there, watching me."

# A1-290  〔L88〕
translate english A1_290:
    me "“You're Mai, right? I'm one of the new teachers.”"

# A1-300  〔L90〕
translate english A1_300:
    n "She nodded, then asked my name."

# A1-310  〔L92〕
translate english A1_310:
    me "“[teacher_name]. You can call me Teacher [teacher_name].”"

# A1-320  〔L94〕
translate english A1_320:
    n "She repeated the name, then tried “Teacher [teacher_name]” and laughed."

# A1-325  〔改稿〕
translate english A1_325:
    n "The boys were still poking their heads in at the door. No one mentioned what had happened."

# A1-330  〔改稿〕
translate english A1_330:
    n "The bell rang. The children drifted back to their seats in twos and threes."

# A1-340  〔改稿〕
translate english A1_340:
    n "Mai sat near the middle of the back row. The seats on either side of her were empty."

# A1-350  〔改稿〕
translate english A1_350:
    n "The argument was over. But the invisible line hadn't gone away with the bell."

# A2-010  〔新增〕
translate english A2_010:
    n "There was a little restaurant beside the school. Before we even reached the door, the smell of pigs and their urine hit us."

# A2-020  〔新增〕
translate english A2_020:
    n "The couple who ran it welcomed us in with smiles. We arranged to eat there for the next two months. There weren't really any other options nearby."

# A2-030  〔新增〕
translate english A2_030:
    n "I had thought meals would at least be cheaper this far into the mountains. The menu wasn't much cheaper than Beijing."

# A2-040  〔新增〕
translate english A2_040:
    n "Especially the meat dishes. We talked it over with the menu in front of us and ordered a few anyway."

# A2-050  〔新增〕
translate english A2_050:
    n "When the dishes arrived, there were only scattered bits of meat among the vegetables. I turned one over with my chopsticks. Most of it was fat."

# A2-060  〔新增〕
translate english A2_060:
    n "The owner brought over another dish and urged us, smiling, to eat while it was hot. The smell hadn't gone away."

# A2-070  〔新增〕
translate english A2_070:
    n "Later, at lunchtime, a few children would always gather to watch us eat. They never reached for anything. They just watched the meat dishes on our table."

# A2-080  〔新增〕
translate english A2_080:
    n "Their lunch was a bowl of meatless noodles that cost one yuan. The same thing every day."

# A2-090  〔新增〕
translate english A2_090:
    n "We would share some of our meat with them. They took it and thanked us."

# A2-100  〔改稿〕
translate english A2_100:
    n "After dinner, someone said we needed to buy sheets for sleeping on the floor before the village shop closed."

# A2-110  〔改稿〕
translate english A2_110:
    n "There were no beds in the classroom. Tonight, we'd be sleeping on the concrete floor."

# A2-120  〔L125〕
translate english A2_120:
    n "The village shop was smaller than an ordinary bedroom in the city. A huge freezer by the entrance held three or four kinds of ice pops."

# A2-130  〔L125〕
translate english A2_130:
    n "A few deeply tanned older men sat outside on little wooden chairs, chatting and fanning themselves with palm-leaf fans. They watched our group of young women approach with friendly curiosity."

# A2-140  〔L127〕
translate english A2_140:
    n "I suddenly remembered accounts I'd read online before coming here, about young women volunteer teachers being harmed by local people."

# A2-150  〔L127〕
translate english A2_150:
    n "A little fear shot through my chest like electricity, then slowly faded in the warmth of my companions' shoulders on either side of me."

# A2-160  〔L129〕
translate english A2_160:
    n "But the men in front of us looked genuinely friendly, apparently just curious about our unexpected arrival."

# A2-170  〔L131〕
translate english A2_170:
    n "Should I say hello before going in?" nointeract

# A2-180  〔L137〕
translate english A2_180:
    me "“Good evening.”"

# A2-190  〔L139〕
translate english A2_190:
    n "They seemed surprised that we'd spoken first. After a moment, they smiled shyly and raised their hands in greeting."

# A2-200  〔L141〕
translate english A2_200:
    villager "“Come to buy something?”"

# A2-210  〔L145〕
translate english A2_210:
    n "I followed the others inside. The conversation behind us paused briefly, then started up again."

# A2-220  〔L147〕
translate english A2_220:
    n "There weren't many kinds of sheets. I stood in front of the shelf and chose one." nointeract

# A2-221  〔新增〕
translate english A2_221:
    n "I picked the pink Peppa Pig one. In a place this unfamiliar, I wanted something cute, something that could make me smile."

# A2-223  〔新增〕
translate english A2_223:
    n "I picked the pale blue fleecy one. The day had been exhausting enough. At least at night, I wanted something soft."

# A2-225  〔新增〕
translate english A2_225:
    n "I picked the plain light gray one. Unremarkable and hard to stain, it seemed the most practical choice out here."

# A2-227  〔新增〕
translate english A2_227:
    n "I picked the black one. It looked clean and simple, and it wouldn't show the dirt."

# A2-230  〔L159〕
translate english A2_230:
    n "Once we'd finished shopping, we returned to the classroom. For safety, more than twenty of us women teachers had decided to sleep together on the floor of a single room."

# A2-240  〔改稿〕
translate english A2_240:
    n "I spread my sheet on the concrete and tried lying down. The floor was hard, and it dug into my shoulders."

# A2-260  〔L169〕
translate english A2_260:
    n "The classroom had several large windows. With so many people inside, we had to open them, but the room was still as hot and muggy as a steamer."

# A2-270  〔L171〕
translate english A2_270:
    n "Dense mountain woodland stood just outside. The relentless cicadas sounded close to my ears. Very, very close—"

# A2-280  〔L175〕
translate english A2_280:
    n "Oh my God. They really were that close!"

# A2-290  〔L177〕
translate english A2_290:
    n "A plump cicada as long as my index finger fluttered up from the floor right in front of my face."

# A2-300  〔L177〕
translate english A2_300:
    n "Bugs of every shape and color were paying enthusiastic visits to my sheet. Against the pale fabric, I could see every single one."

# A2-310  〔改稿〕
translate english A2_310:
    n "I'd forgotten that bugs like bright colors best. Living in the city, it was something I'd never had to think about."

# A2-320  〔L183〕
translate english A2_320:
    n "Something suddenly fluttered near my feet. I looked down. A cicada as long as my index finger was struggling to turn itself over."

# A2-322  〔改稿〕
translate english A2_322:
    n "Good thing I'd chosen a dark one. The bugs didn't seem to like it much, and the few that did crawl on blended right into the fabric. I could barely see them."

# A2-330  〔L185〕
translate english A2_330:
    n "I was so, so tired. Resigned, I lay down."

# A2-332  〔改稿〕
translate english A2_332:
    n "The night was hot, and the cicadas never stopped."

# A2-334  〔改稿〕
translate english A2_334:
    n "Knock, knock. Someone was knocking on the window."

# A2-336  〔改稿〕
translate english A2_336:
    n "All twenty-odd of us went silent at once. In the dark, someone grabbed my wrist."

# A2-338  〔改稿〕
translate english A2_338:
    n "I thought of the things I'd read online before coming."

# A2-339  〔改稿〕
translate english A2_339:
    n "A shadow moved outside the window."

# A2-341  〔改稿〕
translate english A2_341:
    n "“You girls asleep?” It was the voice of one of the men from outside the village shop."

# A2-342  〔改稿〕
translate english A2_342:
    n "He set a coil of mosquito incense on the windowsill."

# A2-343  〔改稿〕
translate english A2_343:
    villager "“Figured you city girls have never met mountain mosquitoes. Light it.”"

# A2-344  〔改稿〕
translate english A2_344:
    n "Once it was lit, a faint smoky smell filled the room. That night, I slept better than I'd expected."

# A2-346  〔改稿〕
translate english A2_346:
    n "The shadow lingered outside for a while, said nothing, and left."

# A2-348  〔改稿〕
translate english A2_348:
    n "I lay awake until very late."

# A2-360  〔L197〕
translate english A2_360:
    n "Half asleep, I thought again of the girl called Mai."

# A2-370  〔L199〕
translate english A2_370:
    n "The way she'd looked at her classmates reminded me of the one little lamb that didn't fit into the flock."

# A2-380  〔L201〕
translate english A2_380:
    n "At least, that was how it seemed to me then."

# A3-010  〔改稿〕
translate english A3_010:
    n "When I woke, the coil on the windowsill had burned down to a ring of pale ash. The other teachers were already up and talking."

# A3-020  〔改稿〕
translate english A3_020:
    n "The next morning, there was a coil of mosquito incense on the windowsill. No one knew who had left it."

# A3-030  〔L214〕
translate english A3_030:
    n "Right in front of my face lay an enormous dead cicada."

# A3-040  〔L216〕
translate english A3_040:
    n "After a whole night's practice, I wasn't even startled by this particular roommate."

# A3-050  〔L218〕
translate english A3_050:
    n "We packed away our bedding and went back into the classroom."

# A3-060  〔L220〕
translate english A3_060:
    n "The first lesson hadn't started yet. Girls stood chatting in little groups. Some boys ran around inside; others played football outside."

# A3-070  〔L222〕
translate english A3_070:
    n "I spotted her immediately—Mai."

# A3-080  〔改稿〕
translate english A3_080:
    n "She sat near the middle of the back row, head lowered, looking at a phone by herself. Her hair was still a tangle."

# A3-082  〔改稿〕
translate english A3_082:
    n "It was a very old phone, its screen covered in a spiderweb of cracks, its case yellowed, a little wood ash stuck in the corners."

# A3-084  〔改稿〕
translate english A3_084:
    n "Her finger swiped across the screen. She was flipping through photos. Through the cracks I could just make out a patch of sky, a few chickens, and a small child's face."

# A3-086  〔改稿〕
translate english A3_086:
    inner_visitor "I wonder where she got it. Probably an old one her parents left her when they went off to work in the city."

# A3-088  〔改稿〕
translate english A3_088:
    n "I walked toward her. She noticed, quickly switched off the screen, and turned the phone face down on the desk. The tips of her ears went a little red."

# A3-090  〔改稿〕
translate english A3_090:
    n "When she saw it was me, her shoulders relaxed."

# A3-100  〔改稿〕
translate english A3_100:
    mei "“Teacher [teacher_name], that boy said sorry to me today.”"

# A3-110  〔改稿〕
translate english A3_110:
    n "She said it quickly, as if she'd been holding it in all morning, waiting to tell me."

# A3-120  〔L236〕
translate english A3_120:
    n "When she saw me, she glanced toward the door."

# A3-130  〔L238〕
translate english A3_130:
    mei "“Teacher [teacher_name], he isn't here yet today.”"

# A3-140  〔L240〕
translate english A3_140:
    n "I followed her gaze, then turned back and nodded."

# A3-150  〔L244〕
translate english A3_150:
    n "She looked up and hesitated, as if trying to remember."

# A3-160  〔L246〕
translate english A3_160:
    mei "“Teacher [teacher_name]?”"

# A3-170  〔L248〕
translate english A3_170:
    me "“That's right. You remembered.”"

# A3-180  〔L250〕
translate english A3_180:
    n "She smiled."

# A3-190  〔L252〕
translate english A3_190:
    n "Looking at her hair, I felt a sudden impulse."

# A3-200  〔L254〕
translate english A3_200:
    n "I remembered the other girls shifting away from her yesterday. Perhaps, just for today, I could help her feel a little different."

# A3-210  〔改稿〕
translate english A3_210:
    n "I crouched down beside her and pointed to my own braid."

# A3-220  〔L258〕
translate english A3_220:
    me "“Mai, do you like my braid? Would you like me to braid your hair?”"

# A3-230  〔L260〕
translate english A3_230:
    n "She looked at my braid, then touched her own hair."

# A3-240  〔L262〕
translate english A3_240:
    mei "“Now?”"

# A3-250  〔L264〕
translate english A3_250:
    me "“If you'd like.”"

# A3-260  〔L266〕
translate english A3_260:
    n "She put her phone away."

# A3-270  〔草案〕
translate english A3_270:
    n "She turned around and sat up straight with her back to me."

# A3-280  〔草案〕
translate english A3_280:
    n "Up close, her hair smelled of sunshine and woodsmoke. It looked fluffy but felt dry, and the comb caught in her curls the moment I tried it. I gave up on the comb and used my fingers to divide her hair, bit by bit, into three strands."

# A3-290  〔草案〕
translate english A3_290:
    n "She sat perfectly still, as if the slightest movement might undo the part I had already braided."

# A3-300  〔草案〕
translate english A3_300:
    me "“Does it hurt?”"

# A3-310  〔草案〕
translate english A3_310:
    mei "“No.” She paused. “Hurry up, Teacher [teacher_name]. Class is about to start.”"

# A3-315  〔新增〕
translate english A3_315:
    n "My fingers had barely started moving when someone in the classroom called for me."

# A3-318  〔改稿〕
translate english A3_318:
    n "Now I finally knew how exhausting it was to look after so many children at once. Still, I'd done all right."

# A3-319  〔改稿〕
translate english A3_319:
    n "Now I finally knew how exhausting it was to look after so many children at once. And still, I hadn't managed to look after them all."

# A3-420  〔草案〕
translate english A3_420:
    n "I finished the last section, slipped a hair tie with a little yellow duck on it off my wrist, and wound it twice around the end of the braid."

# A3-425  〔新增〕
translate english A3_425:
    n "When I came back from fixing the fan, she was still sitting perfectly still, and the part I'd braided had come a little loose. I redid it, slipped a hair tie with a little yellow duck on it off my wrist, and wound it twice around the end."

# A3-430  〔草案〕
translate english A3_430:
    me "“There.”"

# A3-440  〔草案〕
translate english A3_440:
    n "Mai reached back and felt the braid from top to bottom, then from top to bottom again."

# A3-442  〔新增〕
translate english A3_442:
    n "The two girls didn't come to me again all morning."

# A3-444  〔新增〕
translate english A3_444:
    n "The boy kept his head turned to the window for the whole lesson."

# A3-446  〔新增〕
translate english A3_446:
    n "Girl B kept her head down on the desk for a long time."

# A3-380  〔草案〕
translate english A3_380:
    inner_teacher "They're all my students. In those few minutes, who did I actually look after?"

# A3-390  〔草案〕
translate english A3_390:
    inner_visitor "It's only a braid. So what if I finish it today? In two months, who's going to braid her hair?"

# A3-490  〔草案〕
translate english A3_490:
    n "The bell rang. She pulled the braid forward over her shoulder and left it there for the whole lesson."

# A3-510  〔新增〕
translate english A3_510:
    n "At noon, we went back to the restaurant beside the school."

# A3-520  〔新增〕
translate english A3_520:
    n "A few children had finished their noodles and were still beside our table. When the owner came over with a dish, they stepped aside to let her through."

# A3-530  〔新增〕
translate english A3_530:
    me "“Don't you go home for lunch?”"

# A3-540  〔新增〕
translate english A3_540:
    n "“There's no time. We have class again this afternoon,” one child said."

# A3-550  〔新增〕
translate english A3_550:
    me "“Is your house far away?”"

# A3-560  〔新增〕
translate english A3_560:
    n "He nodded. “We walk along the highway.”"

# A3-570  〔新增〕
translate english A3_570:
    me "“The highway?”"

# A3-580  〔新增〕
translate english A3_580:
    n "He explained: they left home, climbed up to the highway, and walked along the shoulder at the edge for over an hour. Then they climbed back down."

# A3-590  〔新增〕
translate english A3_590:
    me "“And then you're at school?”"

# A3-600  〔新增〕
translate english A3_600:
    n "“Then it's another half hour on the mountain path.”"

# A3-610  〔新增〕
translate english A3_610:
    n "I asked what time they left home. Some said after four. Others said five."

# A3-620  〔新增〕
translate english A3_620:
    n "I later learned that many children in the class came that way. The school was already deep in the mountains. Their homes were farther still."

# A3-630  〔新增〕
translate english A3_630:
    n "I looked down and took a mouthful of rice. I'd only been wondering why they couldn't go home at noon. I hadn't thought about how they got here each morning."

# A4-010  〔草案〕
translate english A4_010:
    n "After school, the classroom emptied in minutes. Chairs scraped across the floor, laughter ran off with the footsteps, and then everything went quiet."

# A4-020  〔草案〕
translate english A4_020:
    n "Mai was still in her seat, pinching the end of her braid."

# A4-030  〔草案〕
translate english A4_030:
    n "I was packing my bag. Before we left, I had told everyone I wanted to make a documentary about this summer. But two days in, the camera was still sitting in my bag. I hadn't taken it out once."

# A4-040  〔草案〕
translate english A4_040:
    n "She spotted it first."

# A4-050  〔草案〕
translate english A4_050:
    mei "“Teacher [teacher_name], is that a camera? Are you going to film us?”"

# A4-060  〔草案〕
translate english A4_060:
    n "She leaned in, eyes bright, staring at the bit of lens poking out of the bag."

# A4-070  〔草案〕
translate english A4_070:
    inner_lens "The girl everyone leaves out, the setting sun, the fresh braid. If the whole film follows just one person, it should be her."

# A4-080  〔草案〕
translate english A4_080:
    inner_teacher "If I make her the star, will she feel she's finally been seen? Or will the other kids just think she's even more different?"

# A4-090  〔草案〕
translate english A4_090:
    me "“I want to make a film about this summer. Would you like to be the star?”"

# A4-100  〔草案〕
translate english A4_100:
    n "She looked almost startled, and then her eyes lit up."

# A4-110  〔草案〕
translate english A4_110:
    mei "“Me? You want to film me?”"

# A4-120  〔草案〕
translate english A4_120:
    n "She picked up her new braid and swung it back and forth while she thought."

# A4-130  〔草案〕
translate english A4_130:
    inner_visitor "Maybe it's not the right thing to say, but right now Mai is as sweet as an innocent little puppy wagging its tail."

# A4-140  〔草案〕
translate english A4_140:
    mei "“Okay! Film me—wait, wait, let me wash my face first.”"

# A4-150  〔草案〕
translate english A4_150:
    n "She really did run to the sink and wash her face. When she came back, the hair on her forehead was still dripping."

# A4-160  〔草案〕
translate english A4_160:
    n "I zipped up my bag."

# A4-170  〔草案〕
translate english A4_170:
    me "“It's just for filming the mountains.”"

# A4-180  〔草案〕
translate english A4_180:
    n "She glanced at the bag again and shrugged. “Oh.”"

# A4-190  〔草案〕
translate english A4_190:
    n "For the rest of that summer, the camera stayed in my bag."

# A4-200  〔草案〕
translate english A4_200:
    n "She got as far as the door, then turned back."

# A4-210  〔草案〕
translate english A4_210:
    mei "“Teacher [teacher_name], do you want to come over to my house on Saturday? We have a dog.”"

# A4-220  〔草案〕
translate english A4_220:
    mei "“Teacher [teacher_name], do you want to come film at my house on Saturday? We have a doggy.”"

# A4-230  〔草案〕
translate english A4_230:
    me "“Is your house far?”"

# A4-240  〔草案〕
translate english A4_240:
    n "She thought about it."

# A4-250  〔草案〕
translate english A4_250:
    mei "“Not that far, compared to the other kids' houses. It's just over a little hill.”"

# A5-010  〔草案〕
translate english A5_010:
    n "When Mai said “not far,” she meant not far for her."

# A5-020  〔草案〕
translate english A5_020:
    n "To get to her house, we first crossed a wooden bridge over a stream, then picked our way along the narrow, raised ridges between the rice paddies. On either side, green paddies stretched as far as I could see, bursting with life."

# A5-030  〔草案〕
translate english A5_030:
    n "At the far end of the fields rose a modest hill, with a dirt path zigzagging up its side. In her plastic sandals, she climbed as if she were walking on flat ground, stopping every few bends to wait for me."

# A5-035  〔新增〕
translate english A5_035:
    n "She had braided her own hair, a little crooked, the little yellow duck hair tie still at the end, bouncing against her back."

# A5-040  〔草案〕
translate english A5_040:
    n "The higher we went, the thicker the bamboo grew on both sides of the path. Most of the afternoon sun was caught by the bamboo leaves and scattered dizzily across the trail."

# A5-050  〔草案〕
translate english A5_050:
    n "The few soft beams that slipped through landed on the path as dapples of light, or settled on Mai's shoulders and hair, wrapping her in a thin veil of sunshine."

# A5-060  〔草案〕
translate english A5_060:
    mei "“Teacher [teacher_name], you're so slow.”"

# A5-070  〔草案〕
translate english A5_070:
    n "Panting, my vision swimming, I tried to keep up."

# A5-080  〔草案〕
translate english A5_080:
    me "“I'm not as young as you, you know.”"

# A5-090  〔草案〕
translate english A5_090:
    n "She laughed so hard she had to crouch on a rock, and for a long while she couldn't get back up."

# A5-100  〔草案〕
translate english A5_100:
    n "From the top, we could see the whole valley beyond. In the middle of the thick woods, a two-story white house rose up out of nowhere, not much to look at. A thin, winding path ran from the foot of the hill all the way to it."

# A5-110  〔草案〕
translate english A5_110:
    n "A yellow dog came charging up the path and threw herself against Mai's legs."

# A5-120  〔草案〕
translate english A5_120:
    mei "“This is Maizai.” Mai cupped the dog's face in her hands. “I named her. Because she's mine.”"

# A5-125  〔新增〕
translate english A5_125:
    n "I pressed the shutter. Mai was still holding the dog's face and didn't notice."

# A5-130  〔草案〕
translate english A5_130:
    n "Maizai sniffed all around my shoes, seemed to decide I was acceptable, and ran ahead of us with her tail wagging."

# A5-140  〔草案〕
translate english A5_140:
    mei "“She's really smart. Every morning she walks me to the top of the hill,” Mai said, “and every evening she waits for me there.”"

# A5-150  〔草案〕
translate english A5_150:
    n "Mai's house was at the very back of the valley. From the foot of the hill we walked into the woods, and behind a few plum and pear trees was a yard fenced in with branches."

# A5-160  〔草案〕
translate english A5_160:
    n "A flock of chickens was filing into the yard, clucking, pecking at the layer of last year's golden corn scattered over the ground, and swaggering right into the house."

# A5-170  〔草案〕
translate english A5_170:
    n "As we stepped onto the crunching kernels ourselves, two small figures darted out from behind the house."

# A5-180  〔草案〕
translate english A5_180:
    n "Looking closer, I saw two children of four or five. The girl was a little bigger than the boy. They were barefoot, and the mud on their feet ran up their spattered trouser legs to their pale, fraying vests. Even their round cheeks and little noses were smudged black."

# A5-190  〔草案〕
translate english A5_190:
    mei "“Teacher [teacher_name], this is my second sister, and my fourth brother.”"

# A5-200  〔草案〕
translate english A5_200:
    n "She was about to call them over to say hello, but the moment they saw a stranger in the yard, both of them ran to hide in the house, sneaking glances back at me as they went."

# A5-210  〔草案〕
translate english A5_210:
    n "So I followed Mai inside. It was a summer afternoon, yet somehow the house was dark. In the main room stood a bamboo bed, and an old man sat on it, barefoot too, with a blanket of no particular color over his legs."

# A5-220  〔草案〕
translate english A5_220:
    n "At some point Maizai had come in, and now she lay quietly at the old man's feet."

# A5-230  〔草案〕
translate english A5_230:
    mei "“This is my grandpa. His legs don't work anymore.” Mai said it the way you'd say it was hot today."

# A5-240  〔草案〕
translate english A5_240:
    n "The room had a heavy smell of bedding that hadn't been washed in a long time, and of urine. A few flies circled the bamboo bed."

# A5-250  〔草案〕
translate english A5_250:
    n "Mai didn't seem to notice the smell at all. She put down her schoolbag and, with practiced hands, propped up the pillow behind her grandpa."

# A5-260  〔草案〕
translate english A5_260:
    n "Grandpa asked something in the local dialect. When he opened his mouth, drool ran from the corner of his lips and dripped onto the concrete floor. He raised a hand to wipe it away, but a fresh thread of saliva caught on the back of his hand." nointeract

# A5-270  〔草案〕
translate english A5_270:
    n "I felt my pockets. I hadn't brought any tissues today."

# A5-280  〔草案〕
translate english A5_280:
    n "Apart from a table, the bamboo bed, and some odds and ends, there were no tissues or cloths anywhere in the room."

# A5-290  〔草案〕
translate english A5_290:
    n "Mai stepped forward and, as if it were nothing, wiped her grandpa's mouth with her own sleeve."

# A5-300  〔草案〕
translate english A5_300:
    mei "“He's asking if you're the new teacher.”"

# A5-310  〔草案〕
translate english A5_310:
    n "I smiled and nodded at Grandpa. He looked at me and kept nodding and nodding."

# A5-320  〔草案〕
translate english A5_320:
    n "The afternoon sun slanted in through the doorway, falling on Grandpa's hands, on the bamboo bed, on the floor."

# A5-330  〔草案〕
translate english A5_330:
    inner_lens "If I got this on film, the judges would never forget it..."

# A5-340  〔草案〕
translate english A5_340:
    inner_visitor "This smell... I really can't stay here. Let's just go."

# A5-350  〔草案〕
translate english A5_350:
    inner_teacher "Does he even know what a camera is? Would he want to be filmed like this? Could this end up hurting Mai?"

# A5-360  〔草案〕
translate english A5_360:
    n "I took out the camera and pressed record."

# A5-370  〔草案〕
translate english A5_370:
    n "Grandpa's cloudy eyes turned toward the precise little machine, and then he saw the tiny red light."

# A5-380  〔草案〕
translate english A5_380:
    n "He froze for a moment, then tried to pull the blanket up, but couldn't. Finally he turned his face to the wall and said something in dialect. Mai didn't translate."

# A5-390  〔草案〕
translate english A5_390:
    n "Mai looked at me, then down at the floor."

# A5-400  〔草案〕
translate english A5_400:
    n "The shot was beautiful. I knew it would be the best one in the whole film."

# A5-410  〔草案〕
translate english A5_410:
    n "I left the camera where it was and sat down on a little stool beside the bamboo bed."

# A5-420  〔草案〕
translate english A5_420:
    n "After a while, Grandpa pushed a basin of beans toward me. I copied him and started shelling them, much slower and clumsier than he was."

# A5-430  〔草案〕
translate english A5_430:
    n "He watched me for a while, then started to laugh."

# A5-440  〔草案〕
translate english A5_440:
    grandpa "“Stay for dinner.”"

# A5-450  〔草案〕
translate english A5_450:
    n "That much I understood. Mai grinned at me. It was the first time I'd seen her smile so hard her eyes turned into crescents."

# A5-460  〔草案〕
translate english A5_460:
    n "I sat down on a little stool beside the bamboo bed."

# A5-470  〔草案〕
translate english A5_470:
    grandpa "“Where are you from?”"

# A5-480  〔草案〕
translate english A5_480:
    n "Mai translated for him. I said, Beijing."

# A5-490  〔草案〕
translate english A5_490:
    grandpa "“Far, that.”"

# A5-500  〔草案〕
translate english A5_500:
    n "It didn't sound like a question. It sounded more like he was saying it would rain today."

# A5-510  〔草案〕
translate english A5_510:
    n "Then he asked whether Mai behaved at school. I said Mai was very bright. Grandpa nodded and went back to shelling beans."

# A5-520  〔草案〕
translate english A5_520:
    n "Then he asked whether Mai behaved at school. I said Mai was very bright. Grandpa nodded, bent his head, and started shelling a basin of beans."

# A5-530  〔草案〕
translate english A5_530:
    n "We didn't head back until evening. Maizai walked us to the top of the hill, then sat down, as if that were the edge of her world."

# F1-010  〔新增〕
translate english F1_010:
    n "After that, Mai followed me every day after school. When I went to fetch water, she fetched water too. When I graded homework, she leaned on the next desk and watched."

# F1-101  〔新增〕
translate english F1_101:
    n "One noon, on my way to lunch, I passed the classroom and saw Mai still sitting inside, holding two plums."

# F1-111  〔新增〕
translate english F1_111:
    me "“Aren't you going to have lunch?”"

# F1-121  〔新增〕
translate english F1_121:
    n "She held up the plums."

# F1-131  〔新增〕
translate english F1_131:
    mei "“This is lunch. I just picked them.”"

# F1-141  〔新增〕
translate english F1_141:
    me "“Just those two?”"

# F1-151  〔新增〕
translate english F1_151:
    n "She nodded and took a bite. That was when I learned that this was sometimes all she had for lunch."

# F1-161  〔新增〕
translate english F1_161:
    n "I asked what she ate at home. Pumpkin and potatoes, she said. They grew them themselves."

# F1-171  〔新增〕
translate english F1_171:
    n "“What about rice?” I asked. She shook her head. “We don't have the money for it.”"

# F1-181  〔新增〕
translate english F1_181:
    me "“Come on. Have lunch with me today.”"

# F1-191  〔新增〕
translate english F1_191:
    n "She came out of the classroom with me, still holding her plums."

# F1-012  〔新增〕
translate english F1_012:
    n "Back then, we all borrowed the bathroom at the village official's house to wash."

# F1-014  〔新增〕
translate english F1_014:
    n "“Washing” really meant a hose hooked up to a tap. The water ran hot, then cold, then a trickle, then a gush, just enough for a quick rinse. We were grateful all the same."

# F1-016  〔新增〕
translate english F1_016:
    n "Every time, I brought Mai along. I held the hose for her while she bent over and scrubbed her hair clean, bit by bit."

# F1-018  〔新增〕
translate english F1_018:
    n "Suds ran down her curls into the little gutter in the concrete floor. When she was done, she shook her head and sprayed me with water, and she was the first to laugh."

# F1-020  〔新增〕
translate english F1_020:
    n "One day, she slid that cracked phone across the desk to me."

# F1-030  〔新增〕
translate english F1_030:
    mei "“Teacher [teacher_name], look.”"

# F1-040  〔新增〕
translate english F1_040:
    n "The screen was full of clouds, one photo after another. Morning clouds, noon clouds, evening clouds. Through the cracks, each one looked cut into pieces."

# F1-050  〔新增〕
translate english F1_050:
    mei "“This one looks like Maizai.”"

# F1-060  〔新增〕
translate english F1_060:
    n "It was the first time she'd shown me the photos on her phone."

# A6-010  〔草案〕
translate english A6_010:
    n "Some time later, one day after school, Mai said her mother was working in the cornfield across the river, and asked if I wanted to come film her."

# A6-020  〔草案〕
translate english A6_020:
    n "Some time later, one day after school, Mai said her mother was working in the cornfield across the river. She was going to help, and asked if I wanted to come along."

# A6-030  〔草案〕
translate english A6_030:
    mei "“Teacher [teacher_name], are you coming?”"

# A6-040  〔草案〕
translate english A6_040:
    me "“Sure.”"

# A6-050  〔草案〕
translate english A6_050:
    n "We followed a low slope, and around a bend, a wide, flat meadow of lush green grass suddenly opened up on our right. A flock of fat geese was strolling across it without a care in the world."

# A6-060  〔草案〕
translate english A6_060:
    mei "“Maizai!”"

# A6-070  〔草案〕
translate english A6_070:
    n "I turned around just in time to see Mai fail to catch Maizai."

# A6-080  〔草案〕
translate english A6_080:
    n "Maizai shot into the meadow like a bullet, tumbling and scrambling straight for the geese. In the brilliant sunshine, the fat geese fled honking ahead of her, every one of them spreading angel-like wings and running belly-first."

# A6-090  〔草案〕
translate english A6_090:
    n "And behind them, never too close and never too far, one very happy yellow dog gave chase."

# A6-100  〔草案〕
translate english A6_100:
    inner_lens "Good thing I caught that on film. It looked like something out of heaven."

# A6-110  〔草案〕
translate english A6_110:
    n "Next we passed a river. The water was shallow and clear, and the stones on the bottom looked close enough to touch."

# A6-120  〔草案〕
translate english A6_120:
    n "At the bend, the river suddenly widened and the water became a deep, dark pool. She stopped and tossed a pebble into it."

# A6-130  〔草案〕
translate english A6_130:
    mei "“Teacher [teacher_name], did you know? This is where my third sister died.”"

# A6-140  〔草案〕
translate english A6_140:
    n "She said it the way you'd say “We wash our clothes here.” But it was as if that pebble had landed inside me. I was stunned, and I didn't know what to do."

# A6-150  〔草案〕
translate english A6_150:
    inner_teacher "Should I say something? Or give her a hug?"

# A6-160  〔草案〕
translate english A6_160:
    inner_visitor "This is her private business. Anything I say right now could be wrong."

# A6-170  〔草案〕
translate english A6_170:
    inner_lens "She's standing right where her sister drowned. If I ask her what happened that day and film it, that will be the heart of the whole film."

# A6-180  〔草案〕
translate english A6_180:
    n "I didn't say anything. We stood by the pool for a while, then walked on."

# A6-190  〔草案〕
translate english A6_190:
    n "We'd gone a long way before she spoke again."

# A6-200  〔草案〕
translate english A6_200:
    mei "“It rained really hard that day. She never came home.”"

# A6-210  〔草案〕
translate english A6_210:
    mei "“The next morning, some old men on their way to market found her by the river.”"

# A6-212  〔新增〕
translate english A6_212:
    n "When she finished, she said nothing more. I didn't ask."

# A6-214  〔新增〕
translate english A6_214:
    n "I thought of that pebble sinking. The water had closed over it so quickly, as if nothing had happened at all."

# A6-220  〔草案〕
translate english A6_220:
    me "“What happened that day?”"

# A6-230  〔草案〕
translate english A6_230:
    n "She walked on, running her hand over the wild grass by the path."

# A6-240  〔草案〕
translate english A6_240:
    mei "“It was raining really hard that night. It was the middle of the night and she still wasn't home. I ran and told Mom my little sister wasn't back yet. But she was so tired from the farm work. She said we'd go look when the rain stopped, and then she fell right back asleep.”"

# A6-250  〔草案〕
translate english A6_250:
    mei "“The next morning, some old men on their way to market saw her by the river. They ran to our house to tell us. That's how we found out.”"

# A6-260  〔草案〕
translate english A6_260:
    n "Then she said, “Let's go.”"

# A6-262  〔新增〕
translate english A6_262:
    inner_teacher "She ran to tell her mother. That night, she did everything a child could have done."

# A6-264  〔新增〕
translate english A6_264:
    n "I opened my mouth to say “It wasn't your fault,” but the words felt too light. In the end, I just followed her."

# A6-270  〔草案〕
translate english A6_270:
    n "Almost without thinking, I raised the camera."

# A6-280  〔草案〕
translate english A6_280:
    n "She saw the lens and was quiet for a moment."

# A6-290  〔草案〕
translate english A6_290:
    mei "“It was raining really hard that night. It was the middle of the night and she still wasn't home.”"

# A6-300  〔草案〕
translate english A6_300:
    n "“Forget it,” she said, and turned and walked on."

# A6-302  〔新增〕
translate english A6_302:
    n "I lowered the camera. On the screen, the red recording light was still blinking."

# A6-304  〔新增〕
translate english A6_304:
    n "I pressed stop. I never deleted those few seconds of footage."

# A6-306  〔新增〕
translate english A6_306:
    n "As we walked on, she was the bouncing, skipping Mai again, as if she had never said anything at all."

# A6-308  〔新增〕
translate english A6_308:
    n "But I couldn't shake it. The river beside us was still so clear that I could see every stone on the bottom."

# A6-310  〔草案〕
translate english A6_310:
    n "We crossed the river on a line of stepping stones. Mai hopped across without even looking at her feet. I could only inch my way from one stone to the next."

# A6-320  〔草案〕
translate english A6_320:
    n "Across the river was a cornfield. The corn grew almost twice my height, its leaves already turning yellow, and blocked out the sun completely."

# A6-330  〔改稿〕
translate english A6_330:
    n "Mai's mother was deep in the field, bent over, snapping off ears of corn. When she straightened up, I saw her belly, round and heavy under her shirt."

# A6-332  〔改稿〕
translate english A6_332:
    n "Her face was burned a deep brown by the sun, with two sunburned patches of red on her cheekbones. There were already fine lines at the corners of her eyes, and the fingers snapping off the corn were thick-knuckled, with dirt worked into the creases that would never wash out."

# A6-334  〔改稿〕
translate english A6_334:
    n "It was only when she smiled at us that I realized it: however finely the years and the weather had carved her, she was probably only just past thirty, just a few years older than my cousin back in Beijing."

# A6-340  〔草案〕
translate english A6_340:
    n "She pressed one hand to the small of her back."

# A6-350  〔草案〕
translate english A6_350:
    n "“Teacher [teacher_name]'s here,” Mai said, and went off to gather the picked corn into a pile. No one had asked her to."

# A6-355  〔改稿〕
translate english A6_355:
    mom "“This girl takes my phone to school every single day. The old man at the end of the village wanted to buy corn for his pigs and couldn't get through all day.”"

# A6-360  〔草案〕
translate english A6_360:
    me "“Where's Mai's father?”"

# A6-370  〔草案〕
translate english A6_370:
    n "She glanced at the dirt road in the distance."

# A6-380  〔草案〕
translate english A6_380:
    mom "“Him? He came home once for New Year. Since he left, I haven't been able to get through to him.”"

# A6-390  〔草案〕
translate english A6_390:
    n "Mai's mother patted her belly."

# A6-400  〔草案〕
translate english A6_400:
    mom "“This one's coming when the weather turns cool.”"

# A6-410  〔草案〕
translate english A6_410:
    mei "“Mom says this time it might be a fifth brother,” Mai said. “Or a fifth sister.”"

# A6-420  〔草案〕
translate english A6_420:
    n "I stood on the ridge between the fields, not knowing what to do with my hands."

# A6-430  〔草案〕
translate english A6_430:
    n "Just then, Mai's little sister and brother burst out of the corn. Shrieking and shoving, they ran for the grass nearby and rolled into it, where it stood half as tall as a grown-up."

# A6-440  〔草案〕
translate english A6_440:
    n "The girl climbed up and poked her head out to look at us. Seeing that nothing was happening, she rolled over and settled back into the grass."

# A6-450  〔草案〕
translate english A6_450:
    n "I thought of last year's kernels covering the yard at Mai's house and couldn't imagine how many days and nights of dull labor they meant. This woman, carrying a child, had delivered countless cornstalks with her own two hands, one autumn after another."

# A6-460  〔草案〕
translate english A6_460:
    n "Maybe, I thought, all this corn was the mountain's children. When the mountain slept, they pulled the meadows over themselves like blankets. When the mountain raged, the roaring rain swept them back into its belly."

# A6-470  〔草案〕
translate english A6_470:
    n "Spring, summer, autumn, winter. To bring forth grain takes only a season. When harvest comes, some kernels have grown well, and some have not."

# A6-480  〔草案〕
translate english A6_480:
    n "The new corn was already ripe."

# A6-490  〔草案〕
translate english A6_490:
    n "I couldn't tell whether this coming and going of life was some kind of Zen, or some kind of numbness."

# F2-010  〔新增〕
translate english F2_010:
    n "The days that were left went by faster and faster."

# F2-101  〔新增〕
translate english F2_101:
    n "One day during break, I asked the children where they planned to go for junior secondary school after finishing primary school."

# F2-111  〔新增〕
translate english F2_111:
    n "There was no junior secondary school in the village. Only one or two said they might try the school in town."

# F2-121  〔新增〕
translate english F2_121:
    n "The others hesitated and gave vague answers. Some said they didn't know yet. I couldn't make out any definite plans."

# F2-131  〔新增〕
translate english F2_131:
    n "I almost called Mai's name."

# F2-141  〔新增〕
translate english F2_141:
    n "I was afraid she would say she was going home to help her mother work the fields. So I didn't ask her."

# F2-012  〔新增〕
translate english F2_012:
    n "During break on another day, I noticed someone sitting in the seat next to Mai."

# F2-014  〔新增〕
translate english F2_014:
    n "It was one of the girls who had waited for a braid that morning. The two of them leaned close over the phone with its cracked screen, twittering like little birds as they looked through the photos."

# F2-015  〔新增〕
translate english F2_015:
    n "It was one of the girls who never got her braid that morning. The two of them had their heads together over that cracked phone."

# F2-016  〔新增〕
translate english F2_016:
    n "I didn't know which day it had started. I watched from beside the teacher's desk for a while and didn't go over."

# F2-020  〔新增〕
translate english F2_020:
    n "One evening, we went to the village shop for ice pops. The men on the little wooden chairs out front were talking."

# F2-030  〔新增〕
translate english F2_030:
    villager "“...Killed another one. Whose dog is that, anyway? Nobody ties it up.”"

# F2-040  〔新增〕
translate english F2_040:
    n "I couldn’t make out whose dog it was. But that was nothing unusual in the countryside. The ice pop was melting fast; I gave it a lick, then followed the others back."

# A7-010  〔草案〕
translate english A7_010:
    n "That night, a storm rolled in from over the mountains."

# A7-020  〔草案〕
translate english A7_020:
    n "Rain hammered on the classroom's tin roof. For all that rain, the room was still stiflingly hot."

# A7-030  〔草案〕
translate english A7_030:
    n "Someone was knocking on the window."

# A7-040  〔改稿〕
translate english A7_040:
    n "It was Mai. Soaked through, mud caked up to her knees, her braid plastered to her neck. Lightning flashed, and I saw a hair tie with a little yellow duck wound around the end of her braid."

# A7-042  〔改稿〕
translate english A7_042:
    n "It was the one I'd slipped off my wrist for her the day I braided her hair. It had faded almost white."

# A7-044  〔改稿〕
translate english A7_044:
    n "Her hand was pressed against the glass."

# A7-046  〔改稿〕
translate english A7_046:
    mei "“Teacher [teacher_name], please. Please help me.”"

# A7-050  〔草案〕
translate english A7_050:
    mei "“Maizai's gone. She waits for me on the hilltop every night, but not tonight.”"

# A7-060  〔草案〕
translate english A7_060:
    n "She had come over the hill alone, in the dark, in the rain."

# A7-070  〔草案〕
translate english A7_070:
    mei "“My mom says dogs come back on their own. She told me to hurry up and go to bed.”"

# A7-080  〔草案〕
translate english A7_080:
    inner_teacher "She came over the hill alone in the dark. She must be so worried about Maizai."

# A7-090  〔草案〕
translate english A7_090:
    inner_visitor "It's pouring out there, and the mountain paths are all mud. Even her own mother said to wait. Shouldn't I just bring her in out of the rain first?"

# A7-100  〔草案〕
translate english A7_100:
    n "Her face changed."

# A7-110  〔草案〕
translate english A7_110:
    mei "“That's what Mom said that day too.” Her voice was very quiet. “We'll go when the rain stops.”"

# A7-120  〔草案〕
translate english A7_120:
    n "Before I could say anything, she had turned and run back out into the rain. I grabbed a flashlight and went after her."

# A7-130  〔草案〕
translate english A7_130:
    n "The other teachers were already putting on their shoes. Someone handed out flashlights. Mai clutched my sleeve and walked out into the rain with us."

# A7-140  〔草案〕
translate english A7_140:
    n "We split up and searched the village, calling her name over and over. The rain swallowed our voices."

# A7-150  〔草案〕
translate english A7_150:
    n "Near the edge of the village, I heard a man shouting behind one of the houses. Then a dog yelped, sharp and short."

# A7-160  〔草案〕
translate english A7_160:
    n "I came around the corner of a chicken coop."

# A7-170  〔草案〕
translate english A7_170:
    n "Feathers were scattered in the mud. A chicken lay there, not moving. One man was gripping a stick; another held up a flashlight. On the ground between them, Maizai lay on her side, her belly heaving fast."

# A7-180  〔草案〕
translate english A7_180:
    n "The man with the stick was one of the men who sat on the little wooden chairs outside the village shop, fanning themselves."

# A7-185  〔改稿〕
translate english A7_185:
    n "I recognized him too. He was the man who had set the mosquito coil on our windowsill that first night."

# A7-190  〔建议〕
translate english A7_190:
    n "He recognized me and froze for a second."

# A7-200  〔建议〕
translate english A7_200:
    villager "“Teacher, stay out of this.”"

# A7-210  〔建议〕
translate english A7_210:
    n "His voice wasn't fierce. If anything, he sounded tired."

# A7-215  〔改稿〕
translate english A7_215:
    n "I didn't know him. Maybe he was the shadow outside our window that first night. I couldn't tell."

# A7-220  〔建议〕
translate english A7_220:
    n "He squinted into the beam of my flashlight."

# A7-230  〔建议〕
translate english A7_230:
    villager "“From the school? Mind your own business.”"

# A7-270  〔草案〕
translate english A7_270:
    n "The hand holding the stick was shaking. I couldn't tell if it was from the cold or something else."

# A7-280  〔草案〕
translate english A7_280:
    n "The other teachers were still behind me. It would be a few minutes before they caught up."

# A7-310  〔草案〕
translate english A7_310:
    inner_teacher "If I don't stop him now, she's going to die."

# A7-320  〔草案〕
translate english A7_320:
    inner_visitor "His chickens, their village, their rules. I'm leaving in a few days. Don't go looking for trouble now."

# A7-330  〔草案〕
translate english A7_330:
    inner_lens "Are you sure you want to miss this shot?"

# A7-332  〔改稿〕
translate english A7_332:
    n "I pulled my rain-soaked phone out of my pocket and shook it hard. One bar of signal, flickering in and out."

# A7-334  〔改稿〕
translate english A7_334:
    n "I thought of the road we'd come in on: several ridges from the nearest town, and no police station in the village at all. Even if I got through, who would cross the mountains in a storm like this over a quarrel about a dog?"

# A7-336  〔改稿〕
translate english A7_336:
    n "In the few seconds I spent looking at my phone, the stick came down. Maizai yelped, sharp and short."

# A7-340  〔草案〕
translate english A7_340:
    n "I shouted back the way I'd come, again and again."

# A7-350  〔草案〕
translate english A7_350:
    n "During those few minutes of waiting, I didn't look at what was happening. But I heard it."

# A7-W010  〔改稿〕
translate english A7_W010:
    n "Flashlight beams came swinging through the rain one after another. The other teachers had arrived, and together we stood between him and Maizai."

# A7-W020  〔改稿〕
translate english A7_W020:
    n "He looked at the row of us. He lowered the stick, but he stood up straighter."

# A7-W030  〔改稿〕
translate english A7_W030:
    villager "“That's the third one.” He wiped the rain off his face. “I went to their house twice. Told them to tie it up. Did they?”"

# A7-W110  〔改稿〕
translate english A7_W110:
    n "One of the teachers took out her wallet. Between us we scraped together a crumpled wad of cash and held it out."

# A7-W120  〔改稿〕
translate english A7_W120:
    n "He didn't take it. He looked at the money, then at us."

# A7-W130  〔改稿〕
translate english A7_W130:
    villager "“What's this supposed to mean? You think money makes this go away?”"

# A7-W140  〔改稿〕
translate english A7_W140:
    me "“Sir, what do you want to do?”"

# A7-W150  〔改稿〕
translate english A7_W150:
    n "He paused, as if he hadn't expected anyone to ask."

# A7-W160  〔改稿〕
translate english A7_W160:
    villager "“Those eggs were for my grandson. His parents are off working in the city. We don't get meat at home even once a month.”"

# A7-W170  〔改稿〕
translate english A7_W170:
    villager "“Once a dog's killed a chicken and tasted blood, it doesn't stop. I'm not out to make trouble for anybody.”"

# A7-W180  〔改稿〕
translate english A7_W180:
    villager "“What do I want? Like you could do anything about it?” He turned his face away. “What's the use telling you people any of this.”"

# A7-W190  〔改稿〕
translate english A7_W190:
    me "“I've already called the police.”"

# A7-W192  〔改稿〕
translate english A7_W192:
    n "Behind me, the other teachers froze and glanced at one another. Someone whispered, “When did you call?”"

# A7-W194  〔改稿〕
translate english A7_W194:
    n "He looked at me, then at them, and understood at once."

# A7-W196  〔改稿〕
translate english A7_W196:
    villager "“The police?” He gave a cold laugh. “You city people, that's all you know how to do.”"

# A7-W230  〔改稿〕
translate english A7_W230:
    villager "“Nothing to say?”"

# A7-W240  〔改稿〕
translate english A7_W240:
    villager "“You teachers will all be gone in a few days. When this dog comes back tomorrow, which of you will be here?”"

# A7-W250  〔改稿〕
translate english A7_W250:
    n "No one spoke. The rain was loud."

# A7-W310  〔改稿〕
translate english A7_W310:
    n "We held out the money we'd pooled. This time he looked at it for a long while, then took it."

# A7-W320  〔改稿〕
translate english A7_W320:
    villager "“It's not about the money.” He stuffed it in his pocket. “Keep that dog tied up.”"

# A7-W330  〔改稿〕
translate english A7_W330:
    n "One of the teachers took out her wallet. Between us we scraped together a crumpled wad of cash and held it out."

# A7-W332  〔改稿〕
translate english A7_W332:
    n "He didn't take it. He looked at the money, then at us."

# A7-W334  〔改稿〕
translate english A7_W334:
    villager "“What's this supposed to mean? You think money makes this go away?”"

# A7-W340  〔改稿〕
translate english A7_W340:
    me "“Sir, what do you want to do?”"

# A7-W350  〔改稿〕
translate english A7_W350:
    n "He paused, as if he hadn't expected anyone to ask."

# A7-W360  〔改稿〕
translate english A7_W360:
    villager "“Those eggs were for my grandson. His parents are off working in the city. We don't get meat at home even once a month.”"

# A7-W370  〔改稿〕
translate english A7_W370:
    villager "“Once a dog's killed a chicken and tasted blood, it doesn't stop. I'm not out to make trouble for anybody.”"

# A7-W380  〔改稿〕
translate english A7_W380:
    villager "“What do I want? Like you could do anything about it?” He turned his face away. “What's the use telling you people any of this.”"

# A7-W390  〔改稿〕
translate english A7_W390:
    me "“I've already called the police.”"

# A7-W392  〔改稿〕
translate english A7_W392:
    n "Behind me, the other teachers froze and glanced at one another. Someone whispered, “When did you call?”"

# A7-W394  〔改稿〕
translate english A7_W394:
    n "He looked at me, then at them, and understood at once."

# A7-W396  〔改稿〕
translate english A7_W396:
    villager "“The police?” He gave a cold laugh. “You city people, that's all you know how to do.”"

# A7-W430  〔改稿〕
translate english A7_W430:
    me "“We'll go to her house tomorrow, talk to her mother, and help tie the dog up. Until we leave, we'll check on her every day.”"

# A7-W440  〔改稿〕
translate english A7_W440:
    n "He stared at me for a moment."

# A7-W450  〔改稿〕
translate english A7_W450:
    villager "“You said it.”"

# A7-W460  〔改稿〕
translate english A7_W460:
    me "“We'll talk to her family.”"

# A7-W470  〔改稿〕
translate english A7_W470:
    villager "“You? And what good will that do? Last year's teachers said they'd build the village a basketball hoop, too.”"

# A7-W480  〔改稿〕
translate english A7_W480:
    me "“Mai's little sister... she drowned in that river. This dog is hers...”"

# A7-W490  〔改稿〕
translate english A7_W490:
    n "Halfway through, I felt the teachers beside me turn to look at me. They hadn't known."

# A7-W500  〔改稿〕
translate english A7_W500:
    n "He was quiet for a moment."

# A7-W510  〔改稿〕
translate english A7_W510:
    villager "“Everyone in the village knows what happened to that family.”"

# A7-W520  〔改稿〕
translate english A7_W520:
    n "His voice dropped, but he didn't lower the stick."

# A7-W530  〔改稿〕
translate english A7_W530:
    n "None of us moved. We stood in a row in the rain, our flashlights on the mud and feathers."

# A7-W540  〔改稿〕
translate english A7_W540:
    n "After a long standoff, he was the first to look away."

# A7-W610  〔改稿〕
translate english A7_W610:
    n "He leaned the stick against the wall of the coop."

# A7-W620  〔改稿〕
translate english A7_W620:
    villager "“I'll let it go this time.”"

# A7-W630  〔改稿〕
translate english A7_W630:
    n "He threw the stick down, turned, and left without a word."

# A7-400  〔草案〕
translate english A7_400:
    n "I rushed forward and put myself between him and Maizai."

# A7-R010  〔改稿〕
translate english A7_R010:
    n "The stick was still raised in his hand, rain dripping off it drop by drop. My legs were shaking."

# A7-R020  〔改稿〕
translate english A7_R020:
    villager "“Move.”"

# A7-R030  〔改稿〕
translate english A7_R030:
    villager "“That's the third one. I went to their house twice. Told them to tie it up. Did they?”"

# A7-R110  〔改稿〕
translate english A7_R110:
    n "I dug around in my pocket and came up with a few soggy bills, crumpled into a ball."

# A7-R112  〔改稿〕
translate english A7_R112:
    me "“The chicken... how much? I'll pay.”"

# A7-R114  〔改稿〕
translate english A7_R114:
    n "He looked down at the money in my hand and didn't take it."

# A7-R116  〔改稿〕
translate english A7_R116:
    villager "“What's that little bit going to do?”"

# A7-R150  〔改稿〕
translate english A7_R150:
    me "“Sir... what do you want to do?”"

# A7-R160  〔改稿〕
translate english A7_R160:
    n "The hand holding the stick stopped. It was a long while before he spoke."

# A7-R170  〔改稿〕
translate english A7_R170:
    villager "“My son and his wife work away from home. They come back once a year. The little one lives with me. Those eggs were for him.”"

# A7-R180  〔改稿〕
translate english A7_R180:
    villager "“I don't want to beat a dog either. But if she doesn't die today, she'll be back tomorrow.”"

# A7-R190  〔改稿〕
translate english A7_R190:
    villager "“You're just a girl from the school. What are you asking me that for?” He gripped the stick tighter. “Move.”"

# A7-R200  〔改稿〕
translate english A7_R200:
    me "“I... I've already called the police.”"

# A7-R202  〔改稿〕
translate english A7_R202:
    n "He looked at me for a long time. Then he laughed."

# A7-R204  〔改稿〕
translate english A7_R204:
    villager "“The police? Crossing three mountains over a dog?”"

# A7-R206  〔改稿〕
translate english A7_R206:
    n "He took a step forward."

# A7-R240  〔改稿〕
translate english A7_R240:
    villager "“Nothing to say?”"

# A7-R250  〔改稿〕
translate english A7_R250:
    villager "“And you? You'll be gone in a few days too. When she comes back tomorrow, will you be here?”"

# A7-R310  〔改稿〕
translate english A7_R310:
    n "I held out the wet bills again. He looked at them for a while, sighed, and took them."

# A7-R320  〔改稿〕
translate english A7_R320:
    villager "“It's not about the money. Keep that dog tied up.”"

# A7-R330  〔改稿〕
translate english A7_R330:
    n "I dug around in my pocket and came up with a few soggy bills, crumpled into a ball."

# A7-R332  〔改稿〕
translate english A7_R332:
    me "“The chicken... how much? I'll pay.”"

# A7-R334  〔改稿〕
translate english A7_R334:
    n "He looked down at the money in my hand and didn't take it."

# A7-R336  〔改稿〕
translate english A7_R336:
    villager "“What's that little bit going to do?”"

# A7-R340  〔改稿〕
translate english A7_R340:
    me "“Sir... what do you want to do?”"

# A7-R350  〔改稿〕
translate english A7_R350:
    n "The hand holding the stick stopped. It was a long while before he spoke."

# A7-R360  〔改稿〕
translate english A7_R360:
    villager "“My son and his wife work away from home. They come back once a year. The little one lives with me. Those eggs were for him.”"

# A7-R370  〔改稿〕
translate english A7_R370:
    villager "“I don't want to beat a dog either. But if she doesn't die today, she'll be back tomorrow.”"

# A7-R380  〔改稿〕
translate english A7_R380:
    villager "“You're just a girl from the school. What are you asking me that for?” He gripped the stick tighter. “Move.”"

# A7-R390  〔改稿〕
translate english A7_R390:
    me "“I... I've already called the police.”"

# A7-R392  〔改稿〕
translate english A7_R392:
    n "He looked at me for a long time. Then he laughed."

# A7-R394  〔改稿〕
translate english A7_R394:
    villager "“The police? Crossing three mountains over a dog?”"

# A7-R396  〔改稿〕
translate english A7_R396:
    n "He took a step forward."

# A7-R430  〔改稿〕
translate english A7_R430:
    me "“I'll keep an eye on her. Tomorrow I'll go to her house, help build a doghouse, and tie her up.”"

# A7-R440  〔改稿〕
translate english A7_R440:
    villager "“A girl like you. You'll keep your word?”"

# A7-R450  〔改稿〕
translate english A7_R450:
    me "“I will.”"

# A7-R460  〔改稿〕
translate english A7_R460:
    me "“I'll keep an eye on her.”"

# A7-R470  〔改稿〕
translate english A7_R470:
    villager "“A girl like you? You think you can?”"

# A7-R480  〔改稿〕
translate english A7_R480:
    me "“Mai's little sister drowned in the river. This dog... is hers.”"

# A7-R490  〔改稿〕
translate english A7_R490:
    n "His hand paused."

# A7-R500  〔改稿〕
translate english A7_R500:
    villager "“Everyone in the village knows what happened to that family.”"

# A7-R510  〔改稿〕
translate english A7_R510:
    n "He turned away and looked at the dead chicken on the ground."

# A7-R530  〔改稿〕
translate english A7_R530:
    n "I said nothing, and I didn't move aside. Rain ran from my hair into my eyes. I didn't wipe it away."

# A7-R540  〔改稿〕
translate english A7_R540:
    n "He stared at me, and I stared back."

# A7-R610  〔改稿〕
translate english A7_R610:
    n "He threw the stick down into the mud."

# A7-R620  〔改稿〕
translate english A7_R620:
    villager "“Tie her up. Next time, I won't care whether you're here or not.”"

# A7-450  〔草案〕
translate english A7_450:
    n "He turned and left, and the other man followed."

# A7-420  〔草案〕
translate english A7_420:
    villager "“You city girls are all so soft-hearted. Does a soft heart put food on the table?”"

# A7-430  〔草案〕
translate english A7_430:
    n "Then he threw the stick down into the mud."

# A7-440  〔草案〕
translate english A7_440:
    villager "“You can watch her for a day. You can't watch her forever.”"

# A7-R640  〔改稿〕
translate english A7_R640:
    n "He turned and left, and the other man followed."

# A7-480  〔草案〕
translate english A7_480:
    n "I stood in the dark by the corner of the coop and didn't move."

# A7-490  〔草案〕
translate english A7_490:
    n "The rain drowned out most of the sound."

# A7-500  〔草案〕
translate english A7_500:
    n "When it was over, he walked past me and paused, as if he wanted to say something. In the end, he said nothing."

# A7-510  〔草案〕
translate english A7_510:
    n "He didn't look back at the dog. Neither did I. It was as if I'd been nailed to the spot."

# A7-520  〔草案〕
translate english A7_520:
    n "I walked back through the rain to where Mai and the other teachers were waiting. She saw me and ran over."

# A7-530  〔草案〕
translate english A7_530:
    mei "“Did you find it?”" nointeract

# A7-540  〔草案〕
translate english A7_540:
    n "I told her."

# A7-550  〔草案〕
translate english A7_550:
    n "She didn't cry right away. She asked:"

# A7-560  〔草案〕
translate english A7_560:
    mei "“Was she in pain?”"

# A7-570  〔草案〕
translate english A7_570:
    n "I didn't know how to answer, so I told her that truthfully too."

# A7-580  〔草案〕
translate english A7_580:
    n "Then she cried. I stayed with her until the rain stopped."

# A7-590  〔草案〕
translate english A7_590:
    me "“We didn't find her. Maybe she ran off somewhere. Dogs come back on their own.”"

# A7-600  〔草案〕
translate english A7_600:
    n "Only after I'd said it did I realize those were exactly her mother's words."

# A7-610  〔草案〕
translate english A7_610:
    n "She nodded."

# A7-620  〔草案〕
translate english A7_620:
    mei "“She always comes back,” Mai said, looking toward the mountain."

# A7-700  〔新增〕
translate english A7_700:
    n "One of the teachers had kept Mai waiting under the eaves of the village shop. The moment she saw our flashlights, she ran out into the rain."

# A7-460  〔草案〕
translate english A7_460:
    n "I carried Maizai back to Mai. The dog was heavy and wouldn't stop trembling, but she lay quietly in my arms the whole way."

# A7-710  〔新增〕
translate english A7_710:
    n "Maizai knew Mai at once. Her tail thumped against Mai's arm, again and again, in the rain."

# A7-720  〔新增〕
translate english A7_720:
    n "We carried Maizai back slung in a raincoat. One of her back legs hung limp, and she whimpered whenever anyone touched her."

# A7-730  〔新增〕
translate english A7_730:
    n "She knew Mai and tried to stand, but her back leg gave way and she sank down again. In the end, she just rested her head on Mai's knee."

# A7-740  〔新增〕
translate english A7_740:
    n "Mai knelt in the mud and buried her face in Maizai's soaked fur, and for a long time she didn't look up."

# A7-750  〔新增〕
translate english A7_750:
    mei "“I knew you'd come back.”"

# A7-760  〔新增〕
translate english A7_760:
    n "She looked up at me. Water streamed down her face, and I couldn't tell which of it was rain."

# A7-770  〔新增〕
translate english A7_770:
    mei "“Thank you, Teacher [teacher_name].”"

# A7-780  〔新增〕
translate english A7_780:
    n "She said it very softly, as if speaking any louder might make Maizai disappear again."

# A7-790  〔新增〕
translate english A7_790:
    mei "“Her leg...”"

# A7-800  〔新增〕
translate english A7_800:
    me "“It'll get better.”"

# A7-810  〔新增〕
translate english A7_810:
    n "I didn't know if it would. But that night, it was all I could say."

# A7-380  〔草案〕
translate english A7_380:
    n "Maizai survived. One of her back legs was broken, and she would never race up to the hilltop the way she used to."

# A7-390  〔草案〕
translate english A7_390:
    n "When I ran into him on the road the next day, he nodded at me. Not exactly friendly, but he nodded."

# A7-470  〔草案〕
translate english A7_470:
    n "The next morning, as we passed the village shop, the men on the little wooden chairs all turned their faces away."

# A8-010  〔草案〕
translate english A8_010:
    n "After the last class, the children didn't leave right away. Someone pressed a candy into my hand. Someone drew a lopsided flower in my notebook."

# A8-012  〔新增〕
translate english A8_012:
    n "The boy who'd asked me to fix the fan that day didn't come over."

# A8-014  〔新增〕
translate english A8_014:
    n "The boy who'd asked me to fix the fan that day pushed a drawing into my hand: a whirring fan, with “Thank you, Teacher” scrawled beside it."

# A8-020  〔草案〕
translate english A8_020:
    n "Little by little, they drifted off. Mai was the last one left."

# A8-030  〔草案〕
translate english A8_030:
    n "She stood by the teacher's desk, picking at its wooden edge with one finger."

# A8-032  〔新增〕
translate english A8_032:
    mei "“Teacher [teacher_name], the thing about my little sister. Did you tell the other teachers?”"

# A8-034  〔新增〕
translate english A8_034:
    n "I nodded. She didn't ask anything else. She looked down and went on picking at the edge of the desk."

# A8-040  〔草案〕
translate english A8_040:
    mei "“Teacher [teacher_name], will you come back next year?”"

# A8-050  〔草案〕
translate english A8_050:
    inner_teacher "She's asking so seriously. I don't want to lie to such an honest child. But I don't want to hurt her either."

# A8-060  〔草案〕
translate english A8_060:
    inner_visitor "Next year? Once I leave, it's back to school. Every break after this will go to research or an internship. I'll probably... never come back here again..."

# A8-070  〔草案〕
translate english A8_070:
    n "I was quiet for a long time." nointeract

# A8-080  〔草案〕
translate english A8_080:
    n "She smiled, showing those lovely white teeth."

# A8-090  〔草案〕
translate english A8_090:
    mei "“It's a promise, then. I'll wait for you next year.”"

# A8-100  〔草案〕
translate english A8_100:
    n "She looked at me for a long time."

# A8-110  〔草案〕
translate english A8_110:
    mei "“Oh. That's what last year's teachers said too.”"

# A8-120  〔草案〕
translate english A8_120:
    n "She nodded."

# A8-130  〔草案〕
translate english A8_130:
    mei "“I know.”"

# A8-140  〔草案〕
translate english A8_140:
    n "She turned and looked out the window at the mountains."

# A8-150  〔草案〕
translate english A8_150:
    n "I opened my mouth, but nothing came out."

# A8-160  〔草案〕
translate english A8_160:
    n "She waited a moment, then said, “Bye, Teacher [teacher_name],” and turned and ran out of the classroom."

# A8-170  〔草案〕
translate english A8_170:
    n "That night, lying on my bedding on the classroom floor, I wondered whether I should leave her something." nointeract

# A8-180  〔草案〕
translate english A8_180:
    n "Anything I could give her, it seemed, would stop meaning much once I was gone."

# A8-190  〔草案〕
translate english A8_190:
    n "I had brought a few cheap children's cameras, meaning to teach a photography class, but I never got around to it. I put one in her desk with a note beside it: Take pictures of whatever you want."

# A8-200  〔草案〕
translate english A8_200:
    n "I slipped the last little yellow duck hair tie off my wrist, the twin of the one I had used on her braid that day, and put it in her desk."

# A8-210  〔草案〕
translate english A8_210:
    n "I wrote for a long time, writing and crossing out and writing again. Finally, I folded the letter and put it in her desk."

# A8-220  〔草案〕
translate english A8_220:
    n "Early the next morning, the three-wheeled cart was waiting under the old locust tree at the edge of the village, ready to carry us over the mountains to the nearest town."

# A8-225  〔新增〕
translate english A8_225:
    n "In every yard along the road, the newly harvested corn was spread out to dry."

# A8-230  〔草案〕
translate english A8_230:
    n "A few villagers were standing outside the village shop. One of the men pressed a bag of boiled eggs into my hands."

# A8-240  〔草案〕
translate english A8_240:
    villager "“For the road.”"

# A8-250  〔草案〕
translate english A8_250:
    n "The road was empty. The village shop's door was shut."

# A8-260  〔草案〕
translate english A8_260:
    n "As the cart pulled away, I saw her running after us, her braid swinging. She was long past catching up, and still she kept running."

# A8-270  〔草案〕
translate english A8_270:
    n "She stood at the edge of the village with her hand raised, waving and waving until the cart rounded the foot of the mountain."

# A8-280  〔草案〕
translate english A8_280:
    n "She didn't come out. I kept watching the road until the village disappeared behind the mountain."

# A8-290  〔草案〕
translate english A8_290:
    n "The cart started moving. I looked back. A few children were standing under the old locust tree. I couldn't make out whether she was one of them."

# EP-010  〔建议〕
translate english EP_010:
    chat_n "September."

# EP-012  〔改稿〕
translate english EP_012:
    chat_n "The night before the festival deadline, I loaded that summer's footage onto my computer."

# EP-014  〔改稿〕
translate english EP_014:
    chat_n "My phone lit up. It was from her."

# EP-020  〔建议〕
translate english EP_020:
    chat_mei "Teacher [teacher_name], are you home yet?" nointeract

# EP-021  〔新增〕
translate english EP_021:
    chat_me "Home now! How's school?"

# EP-023  〔新增〕
translate english EP_023:
    chat_me "I'm home. Bit busy lately, I'll talk to you later."

# EP-025  〔新增〕
translate english EP_025:
    chat_n "I turned my phone face down on the desk and told myself I'd reply later."

# EP-022  〔改稿〕
translate english EP_022:
    chat_n "The deadline was noon tomorrow." nointeract

# EP-024  〔新增〕
translate english EP_024:
    chat_n "I submitted the full cut. In November, it made the shortlist."

# EP-026  〔新增〕
translate english EP_026:
    chat_n "After the screening, someone in the audience raised a hand and asked, “How is that girl doing now?”"

# EP-028  〔新增〕
translate english EP_028:
    chat_n "I stood on the stage and couldn't answer."

# EP-032  〔新增〕
translate english EP_032:
    chat_n "I cut those shots and kept only the mountains and the clouds. The film was very clean."

# EP-034  〔新增〕
translate english EP_034:
    chat_n "It didn't make the shortlist. I knew the best shots were the ones I had cut."

# EP-036  〔新增〕
translate english EP_036:
    chat_n "I asked her whether a film with her in it could be shown to lots and lots of people."

# EP-038  〔新增〕
translate english EP_038:
    chat_mei "Sure!"

# EP-039  〔新增〕
translate english EP_039:
    chat_n "She answered right away. I sent the film in. I didn't know whether a child could understand what she'd just agreed to."

# EP-043  〔新增〕
translate english EP_043:
    chat_n "I shut the computer. The footage stayed on the hard drive."

# EP-045  〔新增〕
translate english EP_045:
    chat_n "I submitted it anyway. It was just a few empty shots of mountains, too thin to go anywhere, and I never heard back."

# EP-030  〔建议〕
translate english EP_030:
    chat_n "October."

# EP-040  〔建议〕
translate english EP_040:
    chat_mei "(photo) Maizai can walk now, just a little lame"

# EP-041  〔新增〕
translate english EP_041:
    chat_me "Does her leg still hurt? Take good care of her."

# EP-042  〔新增〕
translate english EP_042:
    chat_me "She looks so lively! Give her a pat for me."

# EP-050  〔新增〕
translate english EP_050:
    chat_n "October."

# EP-060  〔新增〕
translate english EP_060:
    chat_mei "(photo) Maizai walked me to the hilltop again today"

# EP-061  〔新增〕
translate english EP_061:
    chat_me "She looks so lively! Give her a pat for me."

# EP-062  〔新增〕
translate english EP_062:
    chat_me "That's wonderful. You take care too."

# EP-070  〔建议〕
translate english EP_070:
    chat_n "December."

# EP-080  〔建议〕
translate english EP_080:
    chat_mei "Teacher [teacher_name] what are you doing"

# EP-090  〔建议〕
translate english EP_090:
    chat_n "I didn't see that message until three days later."

# EP-091  〔新增〕
translate english EP_091:
    chat_me "Studying for finals. How about you?"

# EP-092  〔新增〕
translate english EP_092:
    chat_me "Just saw this. I've been so busy, sorry."

# EP-100  〔建议〕
translate english EP_100:
    chat_n "July, the next year."

# EP-110  〔建议〕
translate english EP_110:
    chat_mei "Teacher [teacher_name], when are you coming?"

# EP-111  〔新增〕
translate english EP_111:
    chat_me "I might not make it this year... I'm sorry."

# EP-112  〔新增〕
translate english EP_112:
    chat_me "Wait a little longer. I'll try."

# EP-130  〔草案〕
translate english EP_130:
    n "Many years later."

# EP-140  〔草案〕
translate english EP_140:
    n "One day, I received an envelope with no return address. Inside was a stack of photos: the cornfield, the river, a yellow dog with a lame leg. And one of me, standing in the classroom doorway, squinting into the sun. I don't remember when she took it."

# EP-150  〔新增〕
translate english EP_150:
    n "One day, I received an envelope with no return address. Inside was a stack of photos: the cornfield, the river, a yellow dog sitting on a hilltop. And one of me, standing in the classroom doorway, squinting into the sun. I don't remember when she took it."

# EP-160  〔新增〕
translate english EP_160:
    n "One day, I received an envelope with no return address. Inside was a stack of photos: the cornfield, the river, an empty hilltop. And one of me, standing in the classroom doorway, squinting into the sun. I don't remember when she took it."

# EP-170  〔草案〕
translate english EP_170:
    n "That autumn, I received a few photos. The cornfield. The sky above the hilltop. There were no people in them."

# EP-180  〔草案〕
translate english EP_180:
    n "Later, another teacher told me that when the new term began, the camera was still sitting on the teacher's desk. No one had taken it."

# EP-190  〔草案〕
translate english EP_190:
    n "I never found out when she read the letter, or what she was thinking when she did."

# EP-200  〔草案〕
translate english EP_200:
    n "Many years later, I still remember that rainy night, but I can no longer remember her voice."

# EP-210  〔草案〕
translate english EP_210:
    n "The footage I shot, though, I haven't lost a single frame of. I can still play it back again and again. But every time I watch it, it's like watching someone else's summer."

# EP-220  〔草案〕
translate english EP_220:
    n "What those two months meant to her, I don't know."

# EP-230  〔草案〕
translate english EP_230:
    n "I don't even know how I should remember you."

# EP-240  〔草案〕
translate english EP_240:
    n "The rest, I'll leave in that cornfield. Next autumn, she'll grow up well, I hope."

# CRD-005  〔新增〕
translate english CRD_005:
    centered "On a mountain path, a yellow dog comes charging up and throws herself against a girl's legs."

# CRD-010  〔草案〕
translate english CRD_010:
    centered "An old man tries to pull his blanket up, can't, and turns his face to the wall."

# CRD-015  〔新增〕
translate english CRD_015:
    centered "In the sunshine, a flock of fat geese flees with wings spread, and a yellow dog gives chase, never too close and never too far."

# CRD-020  〔草案〕
translate english CRD_020:
    centered "By a river, a girl stops halfway through what she is saying."

# CRD-030  〔草案〕
translate english CRD_030:
    centered "A few empty shots of the mountains. Nothing else."

# CRD-040  〔草案〕
translate english CRD_040:
    centered "I Don't Know How to Remember You"

# END-010  〔草案〕
translate english END_010:
    centered "The End"

translate english strings:

    # CW-C1A
    old "保留限时选择。"
    new "Keep timed choices."

    # CW-C1B
    old "关闭限时选择。"
    new "Turn timers off."

    # PRO-C1A
    old "自己取一个名字"
    new "Choose my own name"

    # PRO-C1B
    old "小姜"
    new "Ginger"

    # PRO-C1C
    old "小雨"
    new "Sunny"

    # PRO-C1D
    old "栗子"
    new "Hazel"

    # A1-C1A
    old "走到她身边，问问发生了什么。"
    new "Go over to her and ask what happened."

    # A1-C1B
    old "先问问那几个男孩。"
    new "Ask the boys first."

    # A1-C1C
    old "暂时不追问，先和她打个招呼。"
    new "Leave the questions for now and introduce myself."

    # A2-C2A
    old "当然。他们看起来很友善，也似乎对我们很好奇。"
    new "Of course. They look friendly, and they seem curious about us."

    # A2-C2B
    old "还是算了。我们主要在小学里教书，和他们未必会有多少交集，似乎也不一定要打招呼。"
    new "Better not. We'll mostly be teaching at the school and may not have much contact with them. Perhaps there's no need to say hello."

    # A2-C3A
    old "粉色的小猪佩奇床单。"
    new "A pink Peppa Pig sheet."

    # A2-C3B
    old "浅蓝色的毛绒床单。"
    new "A pale blue, fleecy sheet."

    # A2-C3C
    old "朴素的浅灰色床单。"
    new "A plain light gray sheet."

    # A2-C3D
    old "舒适的纯黑色床单。"
    new "A comfortable black sheet."

    # A4-C1A
    old "邀请她当纪录片的主角。"
    new "Invite her to be the star of the documentary."

    # A4-C1B
    old "不邀请她。"
    new "Don't invite her."

    # A5-C4A
    old "拍下这一刻。"
    new "Capture this moment."

    # A5-C4B
    old "只是看着。"
    new "Just watch."

    # A5-C1A
    old "找找口袋里有没有纸。"
    new "Check my pockets for a tissue."

    # A5-C1B
    old "看看屋里有没有可以用的东西。"
    new "Look around the room for something to use."

    # A5-C1C
    old "装作什么都没有看到，一切都很正常的样子。"
    new "Pretend I didn't see anything, as if everything were normal."

    # A5-C2A
    old "举起相机，拍下爷爷。"
    new "Raise the camera and film Grandpa."

    # A5-C2B
    old "把相机留在包里。"
    new "Leave the camera in my bag."

    # A6-C1A
    old "什么也不说，陪她站一会儿。"
    new "Say nothing. Stand with her for a while."

    # A6-C1B
    old "问她当时发生了什么。"
    new "Ask her what happened."

    # A6-C1C
    old "举起相机。"
    new "Raise the camera."

    # A7-C1A
    old "“等雨停了再去找吧，现在太危险了。”"
    new "“Let's look for it when the rain stops. It's too dangerous right now.”"

    # A7-C1B
    old "“我们现在就去。”"
    new "“We'll go right now.”"

    # A7-C2P
    old "打电话报警。"
    new "Call the police."

    # A7-C2A
    old "等待其他老师汇合，等大家一起上前。"
    new "Wait for the other teachers, then step in together."

    # A7-C2B
    old "等不了了，立刻冲上前拦住他。"
    new "There's no time. Rush in and stop him now."

    # A7-C2C
    old "站在原地，不插手。"
    new "Stay where I am. Don't interfere."

    # A7-CW1A
    old "赔他鸡钱。"
    new "Offer to pay for the chicken."

    # A7-CW1B
    old "先听他说。"
    new "Hear him out first."

    # A7-CW1C
    old "说我已经报警了。"
    new "Say I've already called the police."

    # A7-CW1D
    old "不说话。"
    new "Say nothing."

    # A7-CW2D
    old "承诺会让她家把狗拴好。"
    new "Promise her family will keep the dog tied up."

    # A7-CW2E
    old "讲小麦三妹的事。"
    new "Tell him about Mai's little sister."

    # A7-CW2F
    old "不说话，站着不走。"
    new "Say nothing, and don't move."

    # A7-C3A
    old "告诉她真相。"
    new "Tell her the truth."

    # A7-C3B
    old "告诉她麦仔可能只是跑远了。"
    new "Tell her Maizai probably just wandered off."

    # A8-C1A
    old "“会的。”"
    new "“I will.”"

    # A8-C1B
    old "“明年还会有很多有意思的老师们来的。”"
    new "“There'll be lots of fun new teachers coming next year.”"

    # A8-C1C
    old "“明年应该不会再来了，但是老师会很想念你们的。”"
    new "“I probably won't come back next year. But I'll miss you all very much.”"

    # A8-C1D
    old "沉默。"
    new "Say nothing."

    # A8-C2A
    old "什么也不留。"
    new "Leave nothing."

    # A8-C2B
    old "留下一台儿童相机。"
    new "Leave her a children's camera."

    # A8-C2C
    old "留下那根发绳。"
    new "Leave her the hair tie."

    # A8-C2D
    old "留下一封信。"
    new "Leave her a letter."

    # EP-C1A
    old "到啦！你在学校还好吗？"
    new "Home now! How's school?"

    # EP-C1B
    old "到了，最近有点忙，晚点跟你说。"
    new "I'm home. Bit busy lately, I'll talk to you later."

    # EP-C1C
    old "晚点再回。"
    new "Reply later."

    # EP-C2A
    old "投完整的版本。"
    new "Submit the full cut."

    # EP-C2B
    old "剪掉那些镜头再投。"
    new "Cut those shots, then submit."

    # EP-C2C
    old "先问问她。"
    new "Ask her first."

    # EP-C2D
    old "不投了。"
    new "Don't submit it."

    # EP-C3A
    old "腿还疼吗？要好好照顾它。"
    new "Does her leg still hurt? Take good care of her."

    # EP-C3B
    old "它看起来真精神！替我摸摸它。"
    new "She looks so lively! Give her a pat for me."

    # EP-C3C
    old "不回。"
    new "Don't reply."

    # EP-C4B
    old "真好。你也要好好的。"
    new "That's wonderful. You take care too."

    # EP-C5A
    old "在准备期末考试。你呢？"
    new "Studying for finals. How about you?"

    # EP-C5B
    old "刚看到，最近太忙了，对不起。"
    new "Just saw this. I've been so busy, sorry."

    # EP-C6A
    old "今年可能来不了了……对不起。"
    new "I might not make it this year... I'm sorry."

    # EP-C6B
    old "再等等，老师争取。"
    new "Wait a little longer. I'll try."

    # UI-010
    old "孩子们该怎么称呼我？"
    new "What should the children call me?"

    # UI-020
    old "只填名字，不用加‘老师’"
    new "Just the name. No need to add “Teacher.”"

    # UI-030
    old "确定"
    new "OK"

    # UI-040
    old "语言"
    new "Language"

    # UI-050
    old "剩余天数"
    new "Days left"

    # UI-300
    old "内容提示"
    new "Content Warning"

    # UI-310
    old "本片涉及虐待与暴力，并描写身体伤害及心理创伤。"
    new "This story involves abuse and violence, and depicts physical harm and psychological trauma."

    # UI-320
    old "点击继续"
    new "Click to continue"

    # UI-400
    old "小麦：“[teacher_name]老师你快点，要上课了。”"
    new "Mai: “Hurry up, Teacher [teacher_name]. Class is about to start.”"

    # UI-401
    old "她还一动不动地坐着。"
    new "She was still sitting perfectly still."

    # UI-402
    old "小麦：“嘶——”"
    new "Mai: “Ow—”"

    # UI-403
    old "她没有动，肩膀一下子绷紧了。"
    new "She didn't move, but her shoulders went tight."

    # UI-404
    old "两个女生"
    new "Two girls"

    # UI-405
    old "“[teacher_name]老师，也给我编一个！”"
    new "“Teacher [teacher_name], do one for me too!”"

    # UI-406
    old "“老师！电扇不转了！”"
    new "“Teacher! The fan's stopped working!”"

    # UI-407
    old "“老师，他拿了我的本子不还！”"
    new "“Teacher, he took my notebook and won't give it back!”"

    # UI-408
    old "她们站在旁边等着。"
    new "They stood beside me, waiting."

    # UI-409
    old "她们等到了。"
    new "They got their turn."

    # UI-410
    old "她们有点失落地走开了。"
    new "They walked off, a little disappointed."

    # UI-411
    old "她们嘟着嘴走开了。"
    new "They pouted and walked away."

    # UI-412
    old "你一直没有回应她们。"
    new "You never answered them."

    # UI-413
    old "他站在电扇底下等着。"
    new "He's waiting under the fan."

    # UI-414
    old "你去修电扇了……"
    new "You've gone to fix the fan..."

    # UI-415
    old "电扇又转起来了。"
    new "The fan's spinning again."

    # UI-416
    old "他等了半天，你也没过去。他闷闷不乐地回了座位。"
    new "He waited and waited, but you never came. He went back to his seat, glum."

    # UI-417
    old "“老师偏心！”他生气地走开了。"
    new "“You've got favorites!” He stomped off."

    # UI-418
    old "你一直没有回应他。"
    new "You never answered him."

    # UI-419
    old "本子要回来了。"
    new "She got her notebook back."

    # UI-420
    old "她闷闷地回到了座位上。"
    new "She went back to her seat, sulking."

    # UI-421
    old "她趴在桌上哭了。"
    new "She put her head down on the desk and cried."

    # UI-422
    old "你一直没有回应她。"
    new "You never answered her."

    # UI-423
    old "等我编完小麦的，就给你们编。"
    new "I'll do yours as soon as Mai's is done."

    # UI-424
    old "今天来不及了，明天吧。"
    new "There isn't time today. Tomorrow, okay?"

    # UI-425
    old "等我一下！"
    new "Just a second!"

    # UI-426
    old "过去帮忙"
    new "Go help"

    # UI-427
    old "阿杰，还给她。"
    new "A-Jie, give it back to her."

    # UI-428
    old "放学再说。"
    new "We'll sort it out after school."

    # UI-429
    old "编辫子"
    new "Braiding"

    # UI-430
    old "轮流点左边和右边的那股头发，让它跨过中间那股。也可以按键盘的 ← →。"
    new "Take turns clicking the left and right strands to cross them over the middle one. You can also use the ← → keys."

    # UI-431
    old "右边会有同学来找你。留意他们的耐心条，在它走完之前回应。"
    new "Other students will come to you on the right. Watch their patience bars and respond before they run out."

    # UI-432
    old "上课铃响之前，把辫子编完。"
    new "Finish the braid before the bell rings."

    # UI-433
    old "（限时已关闭：每点一下辫子算一格时间。）"
    new "(Timers are off: each click on the braid counts as one tick of time.)"

    # UI-434
    old "开始"
    new "Start"

    # UI-435
    old "上课铃"
    new "Bell"

    # UI-436
    old "左"
    new "Left"

    # UI-437
    old "中"
    new "Middle"

    # UI-438
    old "右"
    new "Right"

    # UI-439
    old "卷发缠住了，连点几下解开它。"
    new "Her curls are tangled. Click a few times to work them loose."

    # UI-440
    old "解开"
    new "Untangle"

    # UI-441
    old "辫子编好了。"
    new "The braid is done."

    # UI-442
    old "再来一次"
    new "Play again"

    # UI-443
    old "继续"
    new "Continue"

    # UI-444
    old "上课铃响了，辫子还没编完。"
    new "The bell rang, and the braid wasn't finished."

    # UI-445
    old "重来"
    new "Try again"

    # UI-500
    old "你以前的选择在这一帧的走向里留下了印记"
    new "Your earlier choices have left their mark on how this moment unfolds"

    # UI-100
    old "占位背景：出发之前"
    new "Placeholder: before leaving"

    # UI-110
    old "占位背景：出发前的名单"
    new "Placeholder: the name list"

    # UI-120
    old "占位背景：夕阳下的教室"
    new "Placeholder: classroom at sunset"

    # UI-130
    old "占位背景：废弃的旧宿舍"
    new "Placeholder: the old dormitory"

    # UI-140
    old "占位背景：村里的小卖部"
    new "Placeholder: the village shop"

    # UI-150
    old "占位背景：夜晚的教室"
    new "Placeholder: classroom at night"

    # UI-160
    old "占位背景：清晨的教室"
    new "Placeholder: classroom in the morning"

    # UI-170
    old "占位背景：翻山的竹林小路"
    new "Placeholder: bamboo path over the hill"

    # UI-180
    old "占位背景：撒着陈玉米的院子"
    new "Placeholder: the yard scattered with old corn"

    # UI-190
    old "占位背景：小麦家昏暗的客厅"
    new "Placeholder: Mai's dim main room"

    # UI-200
    old "占位背景：鹅群草地"
    new "Placeholder: the goose meadow"

    # UI-210
    old "占位背景：河湾"
    new "Placeholder: the river bend"

    # UI-220
    old "占位背景：河对岸的玉米地"
    new "Placeholder: the cornfield across the river"

    # UI-230
    old "占位背景：雨夜"
    new "Placeholder: rainy night"

    # UI-240
    old "占位背景：雨夜的鸡舍"
    new "Placeholder: the chicken coop in the rain"

    # UI-250
    old "占位背景：村口的老槐树"
    new "Placeholder: the old locust tree at the village edge"

    # UI-260
    old "占位背景：离开之后"
    new "Placeholder: after leaving"

    # UI-270
    old "占位背景：很多年以后"
    new "Placeholder: many years later"

    # UI-272
    old "占位背景：学校旁的小餐馆"
    new "Placeholder: the little restaurant beside the school"

    # UI-274
    old "占位背景：中午的教室"
    new "Placeholder: the classroom at noon"

    # UI-276
    old "占位背景：村干部家的厕所"
    new "Placeholder: the bathroom at the village official's house"

    # 名字栏 小麦
    old "小麦"
    new "Mai"

    # 名字栏 ？
    old "？"
    new "?"

    # 名字栏 女生甲
    old "女生甲"
    new "Girl A"

    # 名字栏 女生乙
    old "女生乙"
    new "Girl B"

    # 名字栏 男孩
    old "男孩"
    new "Boy"

    # 名字栏 男孩们
    old "男孩们"
    new "Boys"

    # 名字栏 支教队
    old "支教队"
    new "Volunteer team"

    # 名字栏 大叔
    old "大叔"
    new "Villager"

    # 名字栏 老师（心声）
    old "老师・心声"
    new "The Teacher (inner voice)"

    # 名字栏 过客（心声）
    old "过客・心声"
    new "The Passer-by (inner voice)"

    # 名字栏 摄影师（心声）
    old "摄影师・心声"
    new "The Lens (inner voice)"

    # 名字栏 女生
    old "女生"
    new "Girl"

    # 名字栏 爷爷
    old "爷爷"
    new "Grandpa"

    # 名字栏 小麦的妈妈
    old "小麦的妈妈"
    new "Mai's mother"
