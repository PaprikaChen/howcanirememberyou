﻿# 界面英文（由 renpy translate english 生成，按 SDK 自带中文模板反查英文后手工校对）。
# 剧情英文不在这里：见 story/bilingual_script.md 与 tl/english/story/prototype.rpy。

translate english strings:

    # game/screens.rpy:269
    old "回退"
    new "Back"

    # game/screens.rpy:270
    old "历史"
    new "History"

    # game/screens.rpy:271
    old "快进"
    new "Skip Mode"

    # game/screens.rpy:272
    old "自动"
    new "Auto"

    # game/screens.rpy:273
    old "保存"
    new "Save"

    # game/screens.rpy:274
    old "快存"
    new "Q.Save"

    # game/screens.rpy:275
    old "快读"
    new "Q.Load"

    # game/screens.rpy:276
    old "设置"
    new "Preferences"

    # game/screens.rpy:320
    old "开始游戏"
    new "Start"

    # game/screens.rpy:324
    old "调试跳转"
    new "Debug jump"

    # game/screens.rpy:332
    old "读取游戏"
    new "Load"

    # game/screens.rpy:338
    old "结束回放"
    new "End Replay"

    # game/screens.rpy:342
    old "标题菜单"
    new "Main Menu"

    # game/screens.rpy:344
    old "关于"
    new "About"

    # game/screens.rpy:349
    old "帮助"
    new "Help"

    # game/screens.rpy:354
    old "退出"
    new "Quit"

    # game/screens.rpy:497
    old "返回"
    new "Return"

    # game/screens.rpy:580
    old "版本 [config.version!t]\n"
    new "Version [config.version!t]\n"

    # game/screens.rpy:586
    old "引擎：{a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only]\n\n[renpy.license!t]"
    new "Made with {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"

    # game/screens.rpy:621
    old "第 {} 页"
    new "Page {}"

    # game/screens.rpy:621
    old "自动存档"
    new "Automatic saves"

    # game/screens.rpy:621
    old "快速存档"
    new "Quick saves"

    # game/screens.rpy:662
    old "{#file_time}%Y-%m-%d %H:%M"
    new "{#file_time}%A, %B %d %Y, %H:%M"

    # game/screens.rpy:662
    old "空存档位"
    new "empty slot"

    # game/screens.rpy:682
    old "<"
    new "<"

    # game/screens.rpy:686
    old "{#auto_page}A"
    new "{#auto_page}A"

    # game/screens.rpy:689
    old "{#quick_page}Q"
    new "{#quick_page}Q"

    # game/screens.rpy:695
    old ">"
    new ">"

    # game/screens.rpy:700
    old "上传同步"
    new "Upload Sync"

    # game/screens.rpy:704
    old "下载同步"
    new "Download Sync"

    # game/screens.rpy:763
    old "显示"
    new "Display"

    # game/screens.rpy:764
    old "窗口"
    new "Window"

    # game/screens.rpy:765
    old "全屏"
    new "Fullscreen"

    # game/screens.rpy:770
    old "未读文本"
    new "Unseen Text"

    # game/screens.rpy:771
    old "选项后继续"
    new "After Choices"

    # game/screens.rpy:772
    old "忽略转场"
    new "Transitions"

    # game/screens.rpy:792
    old "文字速度"
    new "Text Speed"

    # game/screens.rpy:796
    old "自动前进时间"
    new "Auto-Forward Time"

    # game/screens.rpy:803
    old "音乐音量"
    new "Music Volume"

    # game/screens.rpy:810
    old "音效音量"
    new "Sound Volume"

    # game/screens.rpy:816
    old "测试"
    new "Test"

    # game/screens.rpy:820
    old "语音音量"
    new "Voice Volume"

    # game/screens.rpy:831
    old "全部静音"
    new "Mute All"

    # game/screens.rpy:949
    old "尚无对话历史记录。"
    new "The dialogue history is empty."

    # game/screens.rpy:1016
    old "键盘"
    new "Keyboard"

    # game/screens.rpy:1017
    old "鼠标"
    new "Mouse"

    # game/screens.rpy:1020
    old "手柄"
    new "Gamepad"

    # game/screens.rpy:1033
    old "回车"
    new "Enter"

    # game/screens.rpy:1034
    old "推进对话并激活界面。"
    new "Advances dialogue and activates the interface."

    # game/screens.rpy:1037
    old "空格"
    new "Space"

    # game/screens.rpy:1038
    old "在没有选择的情况下推进对话。"
    new "Advances dialogue without selecting choices."

    # game/screens.rpy:1041
    old "方向键"
    new "Arrow Keys"

    # game/screens.rpy:1042
    old "导航界面。"
    new "Navigate the interface."

    # game/screens.rpy:1045
    old "Esc"
    new "Escape"

    # game/screens.rpy:1046
    old "访问游戏菜单。"
    new "Accesses the game menu."

    # game/screens.rpy:1050
    old "按住时快进对话。"
    new "Skips dialogue while held down."

    # game/screens.rpy:1053
    old "Tab"
    new "Tab"

    # game/screens.rpy:1054
    old "切换对话快进。"
    new "Toggles dialogue skipping."

    # game/screens.rpy:1057
    old "上一页"
    new "Previous"

    # game/screens.rpy:1058
    old "回退至先前的对话。"
    new "Rolls back to earlier dialogue."

    # game/screens.rpy:1061
    old "下一页"
    new "Next"

    # game/screens.rpy:1062
    old "向前至后来的对话。"
    new "Rolls forward to later dialogue."

    # game/screens.rpy:1066
    old "隐藏用户界面。"
    new "Hides the user interface."

    # game/screens.rpy:1070
    old "截图。"
    new "Takes a screenshot."

    # game/screens.rpy:1074
    old "切换辅助{a=https://doc.renpy.cn/zh-CN/self_voicing.html}机器朗读{/a}。"
    new "Toggles assistive {a=https://www.renpy.org/l/voicing}self-voicing{/a}."

    # game/screens.rpy:1078
    old "打开无障碍菜单。"
    new "Opens the accessibility menu."

    # game/screens.rpy:1084
    old "左键点击"
    new "Left Click"

    # game/screens.rpy:1088
    old "中键点击"
    new "Middle Click"

    # game/screens.rpy:1092
    old "右键点击"
    new "Right Click"

    # game/screens.rpy:1096
    old "鼠标滚轮上"
    new "Mouse Wheel Up"

    # game/screens.rpy:1100
    old "鼠标滚轮下"
    new "Mouse Wheel Down"

    # game/screens.rpy:1107
    old "右扳机键\nA/底键"
    new "Right Trigger\nA/Bottom Button"

    # game/screens.rpy:1111
    old "左扳机键\n左肩键"
    new "Left Trigger\nLeft Shoulder"

    # game/screens.rpy:1115
    old "右肩键"
    new "Right Shoulder"

    # game/screens.rpy:1119
    old "十字键，摇杆"
    new "D-Pad, Sticks"

    # game/screens.rpy:1123
    old "开始，向导，B/右键"
    new "Start, Guide, B/Right Button"

    # game/screens.rpy:1127
    old "Y/顶键"
    new "Y/Top Button"

    # game/screens.rpy:1130
    old "校准"
    new "Calibrate"

    # game/screens.rpy:1195
    old "取消"
    new "Cancel"

    # game/screens.rpy:1240
    old "正在快进"
    new "Skipping"

    # game/screens.rpy:1550
    old "菜单"
    new "Menu"

