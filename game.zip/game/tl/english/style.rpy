## 英文界面的字号（手写，不由生成脚本覆盖）。
## 英文句子比中文长，正文和选项略小一号，保证长段落一页放得下。
## 字体不变：SourceHanSansLite 同时包含中英文字形。

translate english python:
    gui.text_size = 38
    gui.choice_button_text_size = 38
