## 胶片相机：拍照小游戏、胶卷计数、冲洗 ##############################################
##
## 第四幕邀请小麦当照片的主角（camera = True）之后，剧情里值得拍的瞬间会出现“拍下这一刻”。
## 选了就举起相机：取景框贴近眼前，画面失焦；光圈一开一合，收到金色刻度里时按快门（点击、空格、回车）。
## 没对准可以重来一次；第二次还没对准，快门照样落下，这一张洗出来是糊的。
## 整卷只有 FILM_TOTAL 张，左上角常驻计数。拍完看不到照片，回城以后在暗房里才洗出来。
##
## 主稿里用〔小游戏〕`photo_shot("bamboo")` 调用，结束后写入：
##     photos   按拍摄顺序的拍摄点编号
##     blurred  其中糊掉的
## 第一次拍照选项前用〔调用〕`film_intro` 出一张说明卡。拍照选项的出现条件写 has_film(photos)，投稿选择看 has_people(photos)。
## 冲洗和片尾分别用〔调用〕`develop_photos`、`credits_photos`。
##
## 界面文字的中文必须与主稿 UI-600 起的条目完全一致，英文由 tools/build_script.py 写入翻译。
## 光圈与刻度的数值必须与 tools/gen_camera_ui.py 一致（刻度环是按这些数值画的）。

define FILM_TOTAL = 5

define PHOTO_TARGET = 0.32              # 规定刻度：光圈开合 0（最小）… 1（全开）
define PHOTO_TOLERANCE = (0.105, 0.18)   # 刻度半宽：（限时开，限时关）
define PHOTO_PERIOD = (1.8, 3.2)        # 光圈开合一个来回的秒数
define PHOTO_RAISE_TIME = 0.8           # 举起相机、取景框贴近的时间
define PHOTO_MISS_TIME = 0.9            # 没对准后停顿多久再来
define PHOTO_SHOT_TIME = 0.9            # 快门落下到放下相机
define PHOTO_BLUR_MAX = 26.0            # 离刻度最远时背景的模糊程度
define PHOTO_ZOOM = 1.12                # 举起相机后画面放大多少

define PHOTO_IRIS_FRAMES = 25
define PHOTO_WINDOW = (240, 60, 1440, 960)   # 取景窗（x, y, 宽, 高），照片按它裁切

## 有人物的拍摄点（投稿时“投有她的那张”只在拍了这些时出现）。
define PHOTO_PEOPLE = ("classroom", "bamboo", "grandpa", "river")

default photos = []
default blurred = []
default photo_run = None
default film_developed = False
default film_intro_seen = False

init python:

    import math

    def has_film(shots):
        return len(shots) < FILM_TOTAL

    def has_people(shots):
        return any(s in PHOTO_PEOPLE for s in shots)

    def on_chapter_cover():
        return any(renpy.showing("bg chapter_%02d" % i) for i in range(10))

    def film_left():
        return max(0, FILM_TOTAL - len(photos))


    class PhotoGame(object):
        """phase：raise 举起相机 ／ aim 对焦 ／ miss 没对准，停一下 ／ shot 快门落下 ／ done"""

        def __init__(self, timed):
            self.timed = bool(timed)
            mode = 0 if self.timed else 1
            self.period = PHOTO_PERIOD[mode]
            self.tolerance = PHOTO_TOLERANCE[mode]
            self.clock = 0.0
            self.phase = "raise"
            self.phase_at = 0.0
            self.aim_at = 0.0
            self.tries = 0
            self.sharp = None
            self.frozen = 1.0         # 按快门那一刻的光圈

        def enter(self, phase):
            self.phase = phase
            self.phase_at = self.clock

        def since(self):
            return self.clock - self.phase_at

        def aperture(self):
            if self.phase == "raise":
                return 1.0
            if self.phase == "aim":
                t = self.clock - self.aim_at
                return 0.5 + 0.5 * math.cos(2 * math.pi * t / self.period)
            return self.frozen

        def in_target(self):
            return abs(self.aperture() - PHOTO_TARGET) <= self.tolerance

        def blur(self):
            if self.phase == "raise":
                return PHOTO_BLUR_MAX * min(1.0, self.since() / PHOTO_RAISE_TIME)
            if self.phase == "shot" and self.sharp:
                return 0.0
            off = max(0.0, abs(self.aperture() - PHOTO_TARGET) - self.tolerance * 0.5)
            return PHOTO_BLUR_MAX * min(1.0, off / 0.45)

        def zoom(self):
            if self.phase == "raise":
                u = min(1.0, self.since() / PHOTO_RAISE_TIME)
                return 1.0 + (PHOTO_ZOOM - 1.0) * (1 - (1 - u) ** 3)
            return PHOTO_ZOOM

        def shake(self):
            """没对准时手一抖，其余时候是轻微的手持晃动。"""
            x = math.sin(self.clock * 1.7) * 3 + math.sin(self.clock * 2.9) * 2
            y = math.cos(self.clock * 1.3) * 3
            if self.phase == "miss":
                k = max(0.0, 1 - self.since() / 0.45)
                x += math.sin(self.since() * 70) * 16 * k
            return x, y

        def iris_frame(self):
            k = int(round(self.aperture() * (PHOTO_IRIS_FRAMES - 1)))
            return "images/camera/iris_%02d.png" % k

        def tick(self, dt):
            self.clock += dt
            if self.phase == "raise" and self.since() >= PHOTO_RAISE_TIME:
                self.enter("aim")
                self.aim_at = self.clock
            elif self.phase == "miss" and self.since() >= PHOTO_MISS_TIME:
                self.enter("aim")
                self.aim_at = self.clock
            elif self.phase == "shot" and self.since() >= PHOTO_SHOT_TIME:
                self.enter("done")
            renpy.restart_interaction()

        def press(self):
            if self.phase != "aim":
                return
            self.tries += 1
            hit = self.in_target()
            self.frozen = self.aperture()
            if hit or self.tries >= 2:
                self.sharp = hit
                self.enter("shot")
                renpy.sound.play(audio.shutter)
                renpy.sound.queue(audio.film_advance)
            else:
                self.enter("miss")
            renpy.restart_interaction()


    def photo_lens_fn(trans, st, at):
        g = store.photo_run
        if g is None:
            trans.zoom = 1.0
            trans.blur = None
            trans.xoffset = trans.yoffset = 0
            return 0
        trans.zoom = g.zoom()
        b = g.blur()
        trans.blur = b if b > 0.3 else None
        trans.xoffset, trans.yoffset = g.shake()
        return 0


    ## ------------------------------------------------------------ 洗出来的照片

    ## 每个拍摄点的画面：背景 + 当时的贴纸（与剧本里的站位一致，去掉抖动）。
    PHOTO_SCENES = {
        "classroom": ("bg dusk_classroom", [("mai calm", 0.5, 0.86)]),
        "classroom_empty": ("bg dusk_classroom", []),
        "bamboo":    ("bg mountain_path", [("mai back", 0.43, 0.87)]),
        "grandpa":   ("bg mei_house", []),
        "hilltop":   ("bg country_path", [("dog sit", 0.72, 0.785)]),
        "geese":     ("bg goose_meadow", [("geese flock", 0.638, 0.41), ("goose single", 0.398, 0.504), ("dog run", 0.143, 0.718)]),
        "river":     ("bg river_bend", [("mai back", 0.5, 0.87)]),
        "corn":      ("bg village_gate", []),
    }

    ## 冲洗时的旁白：（清晰，糊了）
    PHOTO_CAPTIONS = {
        "classroom": (_("傍晚的教室。她刚洗过脸，额前的头发还在滴水，冲着镜头笑。"),
                      _("傍晚的教室，糊成了一片橘色。可我记得，她额前的头发还在滴水。")),
        "classroom_empty": (_("傍晚空下来的教室。桌椅歪歪扭扭，窗外是一层金色的光。"),
                      _("糊成一片橘色的教室。桌椅只剩一些模糊的影子。")),
        "bamboo":    (_("竹林里的光斑，落在她的肩膀和辫子上。"),
                      _("糊掉的竹林，只剩一团一团的光。她的辫子在里面一跳一跳的。")),
        "grandpa":   (_("昏暗的屋子里，老人想把毯子往上拉。照片很清楚，清楚得让我不敢多看。"),
                      _("昏暗的屋子，一个模糊的人影把脸转向了墙。我竟然有点庆幸，它糊了。")),
        "hilltop":   (_("傍晚的山顶，麦仔坐在它世界的边界上。"),
                      _("山顶上一个模糊的小黄点。我知道那是麦仔，在等她回家。")),
        "geese":     (_("阳光下，一群大肥鹅张着翅膀逃窜，麦仔在后面不远不近地追。"),
                      _("满画面晃动的白翅膀和一道黄影。糊得厉害，却是最热闹的一张。")),
        "river":     (_("河湾。她背对着镜头，话说到一半就停住了。"),
                      _("河湾，一片模糊的深色水面。那天她说到一半，就不说了。")),
        "corn":      (_("院坝上铺满了新玉米，金灿灿的一片。那是我离开的早晨。"),
                      _("一片糊掉的金黄。那是我离开的早晨，车已经开动了。")),
    }

    PHOTO_MATRIX = TintMatrix("#ffe8c8") * SaturationMatrix(0.78) * ContrastMatrix(1.06)

    def photo_scene(spot):
        bg, figures = PHOTO_SCENES[spot]
        f = Fixed(xysize=(config.screen_width, config.screen_height))
        f.add(renpy.displayable(bg))
        for name, x, y in figures:
            f.add(Transform(renpy.displayable(name), xpos=x, xanchor=0.5, ypos=y, yanchor=1.0))
        return f

    def photo_print(spot, blurry=False):
        """一张带白边的照片，760×520。"""
        scene = photo_scene(spot)
        if blurry:
            scene = Transform(scene, blur=22)
        x, y, w, h = PHOTO_WINDOW
        pic = Transform(scene, crop=(x, y, w, h), size=(720, 480), matrixcolor=PHOTO_MATRIX)
        pic = Fixed(pic, "images/camera/grain.png", "images/camera/print_vignette.png", xysize=(720, 480))
        return Fixed(Solid("#f4efe4"), Transform(pic, pos=(20, 20)), xysize=(760, 520))

    def photo_caption(spot):
        sharp, blurry = PHOTO_CAPTIONS[spot]
        return __(blurry if spot in blurred else sharp)


## 举起相机：整个画面层放大、失焦、手持晃动（每帧读 photo_run）。
transform photo_lens:
    mesh True
    xanchor 0.5 yanchor 0.5 xpos 0.5 ypos 0.5
    function photo_lens_fn

transform photo_vf_raise:
    xalign 0.5 yalign 0.5
    zoom 1.6 alpha 0.0
    easein PHOTO_RAISE_TIME zoom 1.0 alpha 1.0

transform photo_flash:
    alpha 1.0
    linear 0.5 alpha 0.0

## 暗房：红色安全灯下，影像在白纸上慢慢浮出来。
transform photo_in_tray:
    xalign 0.5 yalign 0.42 rotate -1.5
    matrixcolor TintMatrix("#ff6a58") * BrightnessMatrix(-0.05)
    alpha 0.0
    linear 0.6 alpha 1.0

transform photo_emerge:
    alpha 0.0
    pause 0.6
    linear 3.5 alpha 1.0

## 开灯后晾在绳上的一排照片。
transform photo_on_line(i, n):
    zoom 0.4
    xanchor 0.5 yanchor 0.0
    xpos (i + 0.5) / max(n, 1) ypos 0.24
    rotate (-3, 2, -1.5, 3, -2)[i % 5]
    alpha 0.0
    pause 0.25 * i
    linear 0.5 alpha 1.0

transform photo_credits:
    xalign 0.5 yalign 0.45 zoom 1.1
    alpha 0.0
    linear 1.0 alpha 1.0
    pause 2.6
    linear 1.0 alpha 0.0


## 流程 ##########################################################################

label photo_shot(spot):
    ## 自动测试跳过小游戏，按“拍清楚了”记录。
    if renpy.is_in_test():
        $ photos = photos + [spot]
        return
    window hide
    $ calendar_hud_hidden = True
    $ _photo_quick_menu = quick_menu
    $ quick_menu = False
    $ _skipping = False
    $ photo_run = PhotoGame(timed_choices)
    camera at photo_lens
    call screen photo_viewfinder(photo_run)
    $ photos = photos + [spot]
    if not photo_run.sharp:
        $ blurred = blurred + [spot]
    $ photo_run = None
    camera
    with Dissolve(0.4)
    $ quick_menu = _photo_quick_menu
    $ _skipping = True
    $ calendar_hud_hidden = False
    $ renpy.block_rollback()
    return


## 第一次出现拍照机会前的说明卡（只出现一次）。
label film_intro:
    if renpy.is_in_test() or film_intro_seen:
        return
    $ film_intro_seen = True
    window hide
    $ calendar_hud_hidden = True
    call screen film_intro
    $ calendar_hud_hidden = False
    return


## 回城后的暗房：按拍摄顺序一张张显影，然后开灯，晾成一排。
label develop_photos:
    $ film_developed = True
    $ calendar_hud_hidden = True
    $ _dv_i = 0
    while _dv_i < len(photos):
        $ _dv_spot = photos[_dv_i]
        show expression Fixed(photo_print(_dv_spot, _dv_spot in blurred), xysize=(760, 520)) as photo_tray at photo_in_tray
        $ renpy.pause(0.8, hard=True)
        $ renpy.say(n, photo_caption(_dv_spot))
        hide photo_tray with dissolve
        $ _dv_i += 1
    if len(photos) < FILM_TOTAL:
        $ renpy.say(n, __("剩下的几格胶片，是空白的。"))
    scene bg darkroom_lit with dissolve
    $ _dv_i = 0
    while _dv_i < len(photos):
        $ _dv_spot = photos[_dv_i]
        $ renpy.show("photo_line_%d" % _dv_i, what=photo_print(_dv_spot, _dv_spot in blurred), at_list=[photo_on_line(_dv_i, len(photos))])
        $ _dv_i += 1
    $ renpy.pause(0.25 * len(photos) + 0.6, hard=True)
    return


## 片尾：洗出来的照片依次淡入淡出。
label credits_photos:
    $ _dv_i = 0
    while _dv_i < len(photos):
        $ _dv_spot = photos[_dv_i]
        show expression photo_print(_dv_spot, _dv_spot in blurred) as photo_credit at photo_credits
        $ renpy.pause(4.6)
        hide photo_credit
        $ _dv_i += 1
    return


## 界面 ##########################################################################

screen photo_viewfinder(game):
    modal True

    if game.phase != "done":
        timer 0.02 repeat True action Function(game.tick, 0.02)
    else:
        timer 0.01 action Return(game.sharp)

    key "K_SPACE" action Function(game.press)
    key "K_RETURN" action Function(game.press)
    key "K_KP_ENTER" action Function(game.press)
    button:
        xysize (config.screen_width, config.screen_height)
        background None
        action Function(game.press)

    add "images/camera/viewfinder.png" at photo_vf_raise

    if game.phase != "raise":
        add game.iris_frame() align (0.5, 0.5)
        add ("images/camera/target_ring.png" if game.timed else "images/camera/target_ring_wide.png") align (0.5, 0.5)

        if game.phase == "miss":
            text _("没对上焦。只能再试一次。") style "photo_warn"
        elif game.phase == "aim" and game.tries == 0:
            text _("光圈收进金色刻度里时，按下快门（点击或空格）。") style "photo_hint"
        elif game.phase == "aim":
            text _("最后一次。") style "photo_warn"

    ## 取景窗下沿的计数，像机身上的小窗
    text "[film_left()]" style "photo_counter"

    if game.phase in ("shot", "done"):
        add Solid("#fff") at photo_flash


screen film_intro():
    modal True
    add Solid("#1d1a17e6")
    vbox:
        align (0.5, 0.45)
        xmaximum 1300
        spacing 34
        hbox:
            xalign 0.5
            spacing 18
            add "images/camera/canister.png" yalign 0.5
            for i in range(FILM_TOTAL):
                add "images/camera/film_cell.png" zoom 1.4 yalign 0.5
        text _("五张胶片") style "content_warning_title"
        text _("你只有五张胶片。拍下的照片要等离开村子、回到城里，才能洗出来看。") style "content_warning_body"
        text _("遇到值得拍的瞬间，会出现“拍下这一刻”。请抓住你最想留下的瞬间。") style "content_warning_body"
        text _("举起相机后，等光圈收进金色刻度里，再按下快门。没对准可以重来一次。") style "content_warning_body"
        textbutton _("知道了") action Return() style "braid_button" xalign 0.5


## 左上角常驻的胶卷计数（叠加层），章节封面那一页不显示。
screen film_counter():
    zorder -10
    if camera and not film_developed and not left_village and current_day >= 1 and not calendar_hud_hidden and not main_menu and not on_chapter_cover():
        frame:
            style "film_hud"
            hbox:
                spacing 14
                add "images/camera/canister.png" yalign 0.5
                vbox:
                    spacing 6
                    text _("剩余胶卷") style "film_hud_text"
                    hbox:
                        spacing 4
                        for i in range(FILM_TOTAL):
                            add ("images/camera/film_cell_used.png" if i < len(photos) else "images/camera/film_cell.png")

init python:
    config.overlay_screens.append("film_counter")

style film_hud is empty:
    xpos 36 ypos 28
    background "#1d1a17cc"
    padding (16, 12, 18, 12)

style film_hud_text is default:
    size 20
    color "#f3eee8"

style photo_hint is default:
    size 32
    color "#f3eee8"
    outlines [(2, "#000000a0", 0, 0)]
    xalign 0.5 ypos 1048 yanchor 0.5

style photo_warn is photo_hint:
    color "#ffcf6a"

style photo_counter is default:
    size 30
    color "#ffb347"
    xpos 1640 ypos 1048 yanchor 0.5 xanchor 1.0
