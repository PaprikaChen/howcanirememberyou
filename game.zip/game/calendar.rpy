## 支教倒计时日历 ##################################################################
##
## 右上角的小日历显示“剩余天数”，由存档里的 current_day 算出，不靠动画记数：
##     剩余天数 = PROGRAM_DAYS - (current_day - 1)，第 1 天显示 60，第 2 天显示 59。
##
## 剧本（story/bilingual_script.md 的〔调用〕指令）只用两个 label：
##     call start_day(1)     到达学校、开始第一天，右上角出现日历；之后再调用且日期往后跳时，黑屏翻页。
##     call end_of_day(1)    第一天结束：闭眼转场 → 黑屏 → 日历翻页 60→59。
##
## 两者都把 current_day 设成“至少为某天”而不是加一，所以重进同一场景、回滚后重放、
## 调试跳转都不会重复扣天数；回滚到转场之前，current_day 随存档状态一起恢复。

define PROGRAM_DAYS = 60

## 0 表示还没到学校（开场、序幕），不显示日历。
default current_day = 0

## 转场和翻页时暂时隐藏右上角日历（写进存档，读档时状态一致）。
default calendar_hud_hidden = False

init python:

    def days_left(day=None):
        if day is None:
            day = current_day
        return max(0, PROGRAM_DAYS - (day - 1))

    config.overlay_screens.append("calendar_hud")


label start_day(day):
    ## 已在学校、且日期往后跳（如幕与幕之间隔了几天）：黑屏上翻一次日历。
    if current_day >= 1 and day > current_day:
        window hide
        $ calendar_hud_hidden = True
        scene black with dissolve
        $ calendar_flip_from = days_left()
        $ current_day = day
        call calendar_flip_play(calendar_flip_from, days_left())
        $ calendar_hud_hidden = False
    $ current_day = max(current_day, day)
    return


label end_of_day(day):
    ## 上一句台词已经由玩家点击读完；先收起对话框，不遮挡、不跳过任何文字。
    window hide

    ## 闭眼：上下眼睑慢慢合上，中途微微睁开一次，最后全黑。
    $ calendar_hud_hidden = True
    show eyelid_dim at eyelid_dim_in
    show eyelid_top at eyelid_top_close
    show eyelid_bottom at eyelid_bottom_close
    pause EYELID_TIME
    scene black

    ## 状态先更新，翻页动画只负责把旧数字翻过去，露出新数字。
    $ calendar_flip_from = days_left()
    $ current_day = max(current_day, day + 1)
    $ calendar_flip_to = days_left()

    if calendar_flip_to != calendar_flip_from:
        call calendar_flip_play(calendar_flip_from, calendar_flip_to)

    $ calendar_hud_hidden = False
    return


## 闭眼转场 ########################################################################

define EYELID_TIME = 3.6

image eyelid_top = Solid("#000", xsize=config.screen_width, ysize=640)
image eyelid_bottom = Solid("#000", xsize=config.screen_width, ysize=640)
image eyelid_dim = Solid("#000")

## 眼睑边缘做模糊，像眼皮而不是硬边黑条。
transform eyelid_top_close:
    xpos 0 ypos -700 blur 40
    easein 1.6 ypos -390
    ease 0.6 ypos -470
    easein 1.2 ypos -80

transform eyelid_bottom_close:
    xpos 0 ypos config.screen_height + 60 blur 40
    easein 1.6 ypos config.screen_height - 250
    ease 0.6 ypos config.screen_height - 170
    easein 1.2 ypos config.screen_height // 2 - 20

transform eyelid_dim_in:
    alpha 0.0
    linear 3.4 alpha 0.6


## 日历 ##########################################################################

define CALENDAR_FLIP_TIME = 2.6

## 一页日历：上方色条写“剩余天数”，下方是大号数字。文字随当前语言显示。
screen calendar_page(days):
    frame:
        style "calendar_page"
        vbox:
            frame:
                style "calendar_head"
                text _("剩余天数") style "calendar_head_text"
            text "[days]" style "calendar_number"

## 右上角常驻日历（叠加层，所有剧情界面都在其下方）。
screen calendar_hud():
    zorder -10
    if current_day >= 1 and not calendar_hud_hidden and not main_menu:
        fixed:
            xalign 1.0 xoffset -36 ypos 28 fit_first True
            use calendar_page(days_left())

## 黑屏上的放大日历：旧的一页向上翻起，露出新的一页。
## 不用 screen：Ren'Py 再次显示同名 screen 时会沿用上次的 transform 和子组件，
## 翻页会显示上一次的数字。这里每次都新建页面。
init python:

    def calendar_page_displayable(days):
        head = Window(Text(__("剩余天数"), style="calendar_head_text"), style="calendar_head")
        return Window(VBox(head, Text(str(days), style="calendar_number")), style="calendar_page")

    def calendar_flip_displayable(old, new):
        pages = Fixed(calendar_page_displayable(new),
                      At(calendar_page_displayable(old), calendar_page_turn),
                      fit_first=True)
        return At(pages, calendar_flip_appear)

label calendar_flip_play(old, new):
    pause 0.4
    show expression calendar_flip_displayable(old, new) as calendar_flip_page zorder 50 at calendar_flip_pos
    pause CALENDAR_FLIP_TIME
    hide calendar_flip_page
    with Dissolve(0.4)
    return

transform calendar_flip_pos:
    xalign 0.5 yalign 0.45

transform calendar_flip_appear:
    zoom 2.4 alpha 0.0
    linear 0.4 alpha 1.0

## 页面以顶边为轴往上翻：先停一下，再压扁并变暗，最后消失。
transform calendar_page_turn:
    yanchor 0.0 ypos 0 yzoom 1.0 matrixcolor BrightnessMatrix(0.0)
    pause 0.8
    easein 0.7 yzoom 0.0 matrixcolor BrightnessMatrix(-0.4)
    alpha 0.0

style calendar_page is empty:
    xsize 172
    background "#f7f3ec"
    padding (0, 0, 0, 10)

style calendar_head is empty:
    xfill True
    ysize 40
    background "#b5523b"

style calendar_head_text is default:
    align (0.5, 0.5)
    size 22
    color "#fff7ee"

style calendar_number is default:
    xalign 0.5
    size 76
    color "#3a3a3a"
    bold True


## 尾声聊天换时间点：清空 NVL 消息。
label chat_clear:
    nvl clear
    return
