﻿## 游戏入口 ######################################################################
##
## 剧情文本的唯一编辑入口是 story/bilingual_script.md。
## game/story/prototype.rpy 由 tools/build_script.py 生成，依次为
##     proto_warning → proto_cold_open → proto_intro → proto_prologue → proto_act1 … proto_act8（第五、六幕后各有碎片 proto_frag1／proto_frag2） → proto_epilogue → proto_credits → proto_end
## 播完片尾“完”后 return 回到标题菜单。

label start:
    ## 自动测试跳过内容提示页，并关闭限时选择，免得测试等待时超时。
    if renpy.is_in_test():
        $ timed_choices = False
        jump proto_cold_open
    jump proto_warning


## 开头的内容提示：标题和正文在同一页（screens.rpy 的 content_warning），点击继续。
label content_warning:
    window hide
    call screen content_warning
    return
