## 信任变化的反馈 ##################################################################
##
## 主稿里 trust 变化之后（或之后合适的时刻）写〔调用〕`trust_react`：
## 和上次提示时的 trust 比较，对话框上方浮出小麦的小头像和一行字；
## 她此刻正在台上时，立绘也换成对应的表情（不改位置）。
## 两次提示之间 trust 有多次变化，只按净变化提示一次。

default trust_shown = 0

label trust_react:
    $ trust_delta = trust - trust_shown
    $ trust_shown = trust
    if trust_delta == 0:
        return
    if renpy.showing("mai"):
        if trust_delta > 0:
            show mai calm
        else:
            show mai anxious
    $ renpy.hide_screen("trust_toast")
    $ renpy.show_screen("trust_toast", up=trust_delta > 0)
    return

transform trust_toast_up:
    alpha 0.0 yoffset 16
    easein 0.35 alpha 1.0 yoffset -10
    easeout 0.25 yoffset 0
    pause 2.6
    linear 1.0 alpha 0.0

transform trust_toast_down:
    alpha 0.0 yoffset -6
    easein 0.5 alpha 1.0 yoffset 10
    pause 2.6
    linear 1.0 alpha 0.0

image trust_mai_up = Transform("images/figures/mai_calm_sticker.png", fit="contain", xysize=(110, 110))
image trust_mai_down = Transform("images/figures/mai_anxious_sticker.png", fit="contain", xysize=(110, 110))

screen trust_toast(up):
    zorder 50
    hbox at (trust_toast_up if up else trust_toast_down):
        style "trust_toast_box"
        add ("trust_mai_up" if up else "trust_mai_down") yalign 0.5
        text (_("小麦对你的信任增加了") if up else _("小麦对你的信任减少了")) style "trust_toast_text"
    timer 4.6 action Hide("trust_toast")

## 与 choice_echo 同一位置：对话框（上沿 y=750）正上方居中。
style trust_toast_box is default:
    xalign 0.5
    ypos 738 yanchor 1.0
    spacing 14

style trust_toast_text is default:
    size 30
    color "#f3eee8"
    outlines [(2, "#00000088", 0, 0)]
    yalign 0.5
