## 第三幕编辫子小游戏 ##############################################################
##
## 左边编三股辫（进度 + 上课铃），右边同学陆续来找你，要在耐心条走完前回应。
## 铃响前没编完就重来；编完后可以选“再来一次”或“继续”，记录最后一次成功的那局。
## 限时关闭（timed_choices = False）时改成回合制：每点一下辫子算一格时间，过去帮忙算 6 格。
##
## 主稿里用〔小游戏〕`braid_minigame` 调用，结束后写入：
##     braid_left   是否中途放下小麦的辫子去帮忙
##     braid_upset  难过或生气走开的同学，元组，取值 "girls" ／ "boy" ／ "tattle"
##
## 界面文字的中文必须与主稿 UI-400 起的条目完全一致，英文由 tools/build_script.py 写入翻译。
## 数值都在下面，试玩后再调。

define BRAID_STEPS = 16                 # 编完一条辫子要跨几次
define BRAID_KNOTS = (5, 11)            # 编到这几节时卷发打结
define BRAID_KNOT_CLICKS = 3            # 解开一个结要点几下
define BRAID_CROSS_TIME = 0.6           # 跨一次的动作时间（秒），这期间手是忙的
define BRAID_STUN_TIME = 0.5            # 点错后手停多久（秒）
define BRAID_BELL = (33.0, 40)          # 上课铃：（秒，格）
define BRAID_HELP = (6.0, 6)            # 过去帮忙离开多久：（秒，格）
define BRAID_LOOSEN_EVERY = (2.0, 2)    # 离开时每隔多久松一节：（秒，格）
define BRAID_LOOSEN_MAX = 3             # 离开一次最多松几节
define BRAID_BARK_TIME = (2.5, 3)       # 小麦的反应显示多久：（秒，格）
define BRAID_HURRY_AT = (3.0, 3)        # 小麦催“老师你快点”的时间：（秒，格）

## 同学的请求：编号、出现的节数、出现的时间（秒，格），二者先到为准；耐心（秒，格）。
define BRAID_REQUESTS = (
    ("girls",  4, (6.0, 6),   (10.0, 10)),
    ("boy",    8, (13.0, 13), (9.0, 9)),
    ("tattle", 12, (20.0, 20), (8.0, 8)),
)
define BRAID_BOY_SOOTHE = (9.0, 9)      # 男孩被安抚后，耐心再续多久

init python:

    class BraidRequest(object):
        """一个同学的请求。state：
        hidden 还没出现 ／ active 等你回应 ／ soothed 男孩被安抚、等你过去 ／ helping 你正在帮他 ／
        waiting 女生在旁边等 ／ waited 等到了 ／ declined 婉拒 ／ sad 嘟着嘴走开 ／
        done 解决了 ／ letdown 安抚了却一直没去帮 ／ angry 生气走开 ／ mild 委屈 ／ cried 哭了 ／ ignored 一直没回应
        """

        def __init__(self, rid, at_step, at_time, patience):
            self.rid = rid
            self.at_step = at_step
            self.at_time = at_time
            self.patience = patience
            self.state = "hidden"
            self.left = 0.0
            self.full = 1.0

    BRAID_UPSET_STATES = {
        "girls": ("declined", "sad", "ignored"),
        "boy": ("angry", "letdown", "ignored"),
        "tattle": ("cried", "ignored"),
    }

    class BraidGame(object):

        def __init__(self, timed):
            self.timed = bool(timed)
            self.mode = 0 if self.timed else 1      # 数值表里取（秒，格）的哪一个
            self.progress = 0
            self.clock = 0.0
            self.busy = 0.0
            self.knot = 0
            self.knots_done = set()
            self.away = 0.0
            self.away_clock = 0.0
            self.loosened = 0
            self.left_mai = False
            self.repair_flash = False     # 回合制下帮忙一步就完成，只在画面上演一下修理动画
            self.bark = None
            self.bark_until = 0.0
            self.hurried = False
            self.over = False
            self.success = False
            self.requests = [BraidRequest(rid, step, t[self.mode], p[self.mode]) for rid, step, t, p in BRAID_REQUESTS]

        # ---------------------------------------------------------- 查询

        def v(self, pair):
            return pair[self.mode]

        def bell(self):
            return self.v(BRAID_BELL)

        def bell_left(self):
            return max(0.0, self.bell() - self.clock)

        def next_side(self):
            return "L" if self.progress % 2 == 0 else "R"

        def can_braid(self):
            return not self.over and self.away <= 0 and self.busy <= 0 and not self.knot and not self.repair_flash

        def bark_text(self):
            return self.bark if self.bark and self.clock < self.bark_until else None

        def request(self, rid):
            return next(r for r in self.requests if r.rid == rid)

        def upset(self):
            return tuple(r.rid for r in self.requests if r.state in BRAID_UPSET_STATES[r.rid])

        # ---------------------------------------------------------- 内部

        def say(self, text):
            self.bark = text
            self.bark_until = self.clock + self.v(BRAID_BARK_TIME)

        def spawn(self):
            for r in self.requests:
                if r.state == "hidden" and (self.progress >= r.at_step or self.clock >= r.at_time):
                    r.state = "active"
                    r.left = r.full = r.patience

        def finish(self, success):
            self.over = True
            self.success = success
            if success:
                for r in self.requests:
                    if r.state == "active":
                        r.state = "ignored"
                    elif r.state == "soothed":
                        r.state = "letdown"      # 安抚了却一直没过去帮忙：他也不开心
                    elif r.state == "waiting":
                        r.state = "waited"
            renpy.restart_interaction()

        def step_clock(self, dt):
            """时间过去 dt（限时模式为秒，回合制为格）。"""
            if self.over:
                return
            self.clock += dt
            if self.timed:
                self.busy = max(0.0, self.busy - dt)

            if not self.hurried and self.clock >= self.v(BRAID_HURRY_AT):
                self.hurried = True
                self.say(_("小麦：“[teacher_name]老师你快点，要上课了。”"))

            if self.away > 0:
                self.away -= dt
                self.away_clock += dt
                every = self.v(BRAID_LOOSEN_EVERY)
                while self.away_clock >= every:
                    self.away_clock -= every
                    if self.loosened < BRAID_LOOSEN_MAX and self.progress > 0:
                        self.loosened += 1
                        self.progress -= 1
                if self.away <= 0:
                    self.away = 0.0
                    self.request("boy").state = "done"
                    self.say(_("她还一动不动地坐着。"))

            for r in self.requests:
                if r.state in ("active", "soothed"):
                    r.left -= dt
                    if r.left <= 0:
                        r.left = 0.0
                        r.state = {"girls": "sad", "boy": "angry", "tattle": "cried"}[r.rid]

            self.spawn()
            if self.clock >= self.bell() and self.progress < BRAID_STEPS:
                self.finish(False)

        # ---------------------------------------------------------- 玩家操作

        def tick(self, dt):
            """限时模式下由界面的 timer 每 dt 秒调用一次。"""
            if self.timed:
                self.step_clock(dt)

        def press(self, side):
            if self.knot and not self.over and self.away <= 0:
                self.untangle()          # 打结时方向键也算在解结
                return
            if not self.can_braid():
                return
            if side == self.next_side():
                self.progress += 1
                self.busy = BRAID_CROSS_TIME if self.timed else 0.0
                if self.progress in BRAID_KNOTS and self.progress not in self.knots_done:
                    self.knot = BRAID_KNOT_CLICKS
                if self.progress >= BRAID_STEPS:
                    self.finish(True)
                    return
            else:
                self.progress = max(0, self.progress - 1)
                self.busy = BRAID_STUN_TIME if self.timed else 0.0
                self.say(_("小麦：“嘶——”"))
            self.spawn()
            if not self.timed:
                self.step_clock(1)

        def untangle(self):
            if self.over or not self.knot or self.away > 0:
                return
            self.knot -= 1
            if not self.knot:
                self.knots_done.add(self.progress)
            if not self.timed:
                self.step_clock(1)

        def reply(self, rid, choice):
            r = self.request(rid)
            if self.over:
                return
            if rid == "girls" and r.state == "active":
                r.state = "waiting" if choice == "wait" else "declined"
            elif rid == "boy" and r.state == "active" and choice == "soothe":
                r.state = "soothed"
                r.left = r.full = self.v(BRAID_BOY_SOOTHE)
            elif rid == "boy" and r.state == "soothed" and choice == "help" and self.away <= 0:
                r.state = "helping"
                self.left_mai = True
                self.away = self.v(BRAID_HELP)
                self.away_clock = 0.0
                self.loosened = 0
                self.say(_("她没有动，肩膀一下子绷紧了。"))
                if not self.timed:
                    self.repair_flash = True
                    for _i in range(int(self.away)):
                        self.step_clock(1)
            elif rid == "tattle" and r.state == "active":
                r.state = "done" if choice == "return" else "mild"

    def braid_name(rid):
        return {"girls": _("两个女生"), "boy": _("男孩"), "tattle": _("女生乙")}[rid]

    def braid_line(rid):
        return {
            "girls": _("“[teacher_name]老师，也给我编一个！”"),
            "boy": _("“老师！电扇不转了！”"),
            "tattle": _("“老师，他拿了我的本子不还！”"),
        }[rid]

    def braid_status(r):
        table = {
            "girls": {"waiting": _("她们站在旁边等着。"), "waited": _("她们等到了。"),
                      "declined": _("她们有点失落地走开了。"), "sad": _("她们嘟着嘴走开了。"),
                      "ignored": _("你一直没有回应她们。")},
            "boy": {"soothed": _("他站在电扇底下等着。"), "helping": _("你去修电扇了……"),
                    "done": _("电扇又转起来了。"), "letdown": _("他等了半天，你也没过去。他闷闷不乐地回了座位。"),
                    "angry": _("“老师偏心！”他生气地走开了。"), "ignored": _("你一直没有回应他。")},
            "tattle": {"done": _("本子要回来了。"), "mild": _("她闷闷地回到了座位上。"),
                       "cried": _("她趴在桌上哭了。"), "ignored": _("你一直没有回应她。")},
        }
        return table[r.rid].get(r.state, "")

    def braid_choices(r):
        """当前状态下的回复按钮：[(文字, 选项)]。"""
        if r.rid == "girls" and r.state == "active":
            return [(_("等我编完小麦的，就给你们编。"), "wait"), (_("今天来不及了，明天吧。"), "decline")]
        if r.rid == "boy" and r.state == "active":
            return [(_("等我一下！"), "soothe")]
        if r.rid == "boy" and r.state == "soothed":
            return [(_("过去帮忙"), "help")]
        if r.rid == "tattle" and r.state == "active":
            return [(_("阿杰，还给她。"), "return"), (_("放学再说。"), "later")]
        return []


## 流程 ##########################################################################

label braid_minigame:
    ## 自动测试跳过小游戏，按“编完、没离开、没人走开”记录。
    if renpy.is_in_test():
        $ braid_left = False
        $ braid_upset = ()
        return
    window hide
    $ calendar_hud_hidden = True
    $ _skipping = False
    call screen braid_intro(timed_choices)

label braid_minigame_play:
    $ braid_run = BraidGame(timed_choices)
    call screen braid_game(braid_run)
    call screen braid_result(braid_run)
    if _return != "continue":
        jump braid_minigame_play
    $ braid_left = braid_run.left_mai
    $ braid_upset = braid_run.upset()
    $ braid_run = None
    $ _skipping = True
    $ calendar_hud_hidden = False
    $ renpy.block_rollback()
    return


## 界面 ##########################################################################

## 美术（tools/gen_braid_art.py 生成的 SVG）#########################################
##
## 左边是暖色纸面上的小麦背影：辫子一节节往下长，下面是散开的三股和捏着外侧两股的手。
## 右边每张卡片上有一个粉笔火柴人。位置常量与生成脚本里的曲线对应，改了曲线要一起改。

define BRAID_ART = "images/braid/"
define BRAID_INK = "#2a1c13"
define BRAID_CX = 500            # 辫子中线（面板内坐标）
define BRAID_NAPE = 490          # 第一节辫子的上沿
define BRAID_STEP = 22           # 每节往下长多少（16 节加发尾要收在纸面里）
define BRAID_SEG_X = (-84, -20)  # 左节、右节相对中线的 x
define BRAID_STRAND_ANCHOR = 170 # 三股素材里汇合点的 x
define BRAID_STRAND_LEN = 330
define BRAID_FLOOR = 975         # 三股最多垂到这里
define BRAID_HAND = (66, 85)     # 手捏的位置：相对汇合点（x 取正负，y）
define BRAID_KNOT_AT = (94, 176) # 打结的位置

transform braid_seg_in:
    zoom 1.18 alpha 0.0
    easein 0.18 zoom 1.0 alpha 1.0

transform braid_pop:
    zoom 0.6 alpha 0.0
    easein_back 0.35 zoom 1.0 alpha 1.0

## 该点的那股外面的提示光：一直闪烁
transform braid_blink:
    alpha 0.3
    block:
        ease 0.4 alpha 1.0
        ease 0.4 alpha 0.3
        repeat

## 去修电扇时：遮罩淡入，电扇慢慢转，扳手来回拧
transform braid_fade_in:
    alpha 0.0
    ease 0.25 alpha 1.0

transform braid_spin:
    rotate 0
    linear 2.4 rotate 360
    repeat

transform braid_wrench:
    rotate -18
    block:
        ease 0.35 rotate 18
        ease 0.35 rotate -18
        repeat

transform braid_knot_wiggle:
    rotate -6
    block:
        ease 0.35 rotate 6
        ease 0.35 rotate -6
        repeat

transform braid_walk_in:
    xoffset 70 alpha 0.0
    easein 0.4 xoffset 0 alpha 1.0

transform braid_walk_out:
    easeout 0.7 xoffset -40 alpha 0.35

init python:

    def braid_figure(r):
        """卡片上的人物图：来找你、等着、满意、走开。"""
        pose = {"active": "raise", "soothed": "stand", "helping": "stand", "waiting": "stand",
                "waited": "happy", "done": "happy", "mild": "stand", "letdown": "sad"}.get(r.state, "upset")
        return BRAID_ART + "%s_%s.svg" % (r.rid, pose)

    BRAID_LEFT_STATES = ("declined", "sad", "angry", "letdown", "cried", "ignored")

    def braid_layout(progress):
        """当前进度下：三股的上端 y 和纵向缩放。"""
        wy = BRAID_NAPE + (progress - 1) * BRAID_STEP + 28
        return wy, max(0.12, min(1.0, (BRAID_FLOOR - wy) / float(BRAID_STRAND_LEN)))


style braid_card is empty:
    background Solid("#332d27")
    padding (22, 16)
    xfill True

style braid_ink is default:
    size 30
    color BRAID_INK

## 遮罩上的粉笔色文字
style braid_chalk is default:
    size 30
    color "#ece4d6"

style braid_chalk_big is braid_chalk:
    size 60

style braid_chalk_note is braid_chalk:
    size 22
    color "#a8a095"

style braid_chalk_bark is braid_chalk:
    size 27
    italic True

style braid_chalk_bar is bar:
    ysize 10
    left_bar Solid("#ece4d6")
    right_bar Solid("#6a6058")

style braid_ink_note is braid_ink:
    size 22
    color "#7a6a58"

style braid_bark is default:
    size 27
    color BRAID_INK
    italic True

style braid_name is default:
    size 30
    color "#e8c99a"

style braid_line is default:
    size 29
    color "#e8e2d8"

style braid_status is default:
    size 28
    color "#a8a095"

## 耐心条自己填色：界面的 gui/bar 图是 38px 高、上下透明的玉米粒轨道，缩到 12px 会整条看不见。
style braid_bar is bar:
    ysize 12
    left_bar Solid("#e8c99a")
    right_bar Solid("#5a5048")

style braid_ink_bar is bar:
    ysize 10
    left_bar Solid(BRAID_INK)
    right_bar Solid("#d3c4ac")

## 小游戏里的按钮：纯色块、浅色字，不用剧情选项那张渐变底图（缩小后发虚、字发灰）。
style braid_button is default:
    background Solid("#4a4038")
    hover_background Solid("#6b5a4a")
    insensitive_background Solid("#3a332d")
    padding (24, 11)

style braid_button_text is default:
    size 27
    color "#e8e2d8"
    hover_color "#ffffff"
    insensitive_color "#7a736a"


screen braid_intro(timed):
    modal True
    add Solid("#1d1a17")
    vbox:
        align (0.5, 0.45)
        xmaximum 1400
        spacing 36
        text _("编辫子") style "content_warning_title"
        text _("轮流点左边和右边的那股头发，让它跨过中间那股。也可以按键盘的 ← →。") style "content_warning_body"
        text _("右边会有同学来找你。留意他们的耐心条，在它走完之前回应。") style "content_warning_body"
        text _("上课铃响之前，把辫子编完。") style "content_warning_body"
        if not timed:
            text _("（限时已关闭：每点一下辫子算一格时间。）") style "content_warning_hint"
        textbutton _("开始") action Return() style "braid_button" xalign 0.5


## 左侧纸面：辫子、三股、手、打结、发绳。
screen braid_paper(game):
    $ p = game.progress
    $ wy, z = braid_layout(p)
    $ cx = BRAID_CX
    $ sx = cx - BRAID_STRAND_ANCHOR
    $ nxt = game.next_side()
    ## 每一步都在该点的那股上闪烁提示（跨股动作的一瞬间也不熄，免得一闪一闪地跳）
    $ hint = not game.over and game.away <= 0 and not game.knot

    add BRAID_ART + "back.svg"

    if game.success:
        ## 编完：发尾和小黄鸭发绳
        add BRAID_ART + "tail.svg" pos (cx - 70, BRAID_NAPE + (p - 1) * BRAID_STEP + 58)
    else:
        ## 散开的三股，从最后一节底下出来。该点的那股排在最上面、发亮。
        add BRAID_ART + "strand_m.svg" pos (sx, wy) yzoom z
        for side in (("r", "l") if nxt == "L" else ("l", "r")):
            $ img = BRAID_ART + "strand_%s.svg" % side
            $ lit = Fixed(BRAID_ART + "strand_%s_glow.svg" % side, img, fit_first=True)
            if hint and side.upper() == nxt:
                add (BRAID_ART + "strand_%s_glow.svg" % side) pos (sx, wy) yzoom z at braid_blink
            imagebutton:
                pos (sx, wy)
                at Transform(yzoom=z)
                idle img
                hover lit
                insensitive img
                focus_mask True
                action Function(game.press, side.upper())
                sensitive game.can_braid()

    ## 辫子：最上面一节“发根”从头发底下出来；后编的一节压在前一节上面
    add BRAID_ART + "seg_r_2.svg" anchor (0.5, 0.5) pos (cx + BRAID_SEG_X[1] + 52, BRAID_NAPE - BRAID_STEP + 40)
    for i in range(p):
        $ side = "l" if i % 2 == 0 else "r"
        $ seg = BRAID_ART + "seg_%s_%d.svg" % (side, i % 3)
        $ segpos = (cx + BRAID_SEG_X[0 if side == "l" else 1] + 52, BRAID_NAPE + i * BRAID_STEP + 40)
        if i == p - 1 and not game.success:
            add seg anchor (0.5, 0.5) pos segpos at braid_seg_in
        else:
            add seg anchor (0.5, 0.5) pos segpos

    if game.success:
        add BRAID_ART + "duck_tie.svg" anchor (0.5, 0.5) pos (cx, BRAID_NAPE + (p - 1) * BRAID_STEP + 66) at braid_pop
    elif game.away <= 0 and not game.repair_flash:
        ## 老师的手（离开去帮忙时不在）
        add BRAID_ART + "hand_l.svg" pos (cx - BRAID_HAND[0] - 45, wy + int(BRAID_HAND[1] * z) - 28)
        add BRAID_ART + "hand_r.svg" pos (cx + BRAID_HAND[0] - 45, wy + int(BRAID_HAND[1] * z) - 28)

    if game.knot and not game.over:
        imagebutton:
            anchor (0.5, 0.5)
            pos (cx + (-BRAID_KNOT_AT[0] if nxt == "L" else BRAID_KNOT_AT[0]), wy + int(BRAID_KNOT_AT[1] * z))
            at braid_knot_wiggle
            idle BRAID_ART + "knot.svg"
            hover BRAID_ART + "knot.svg"
            action Function(game.untangle)

    ## 去修电扇：盖一层半透明遮罩，上面是在动的修理标志，正下方是倒计时
    $ away = game.away > 0 or game.repair_flash
    if game.repair_flash:
        timer 1.5 action SetField(game, "repair_flash", False)
    if away:
        add BRAID_ART + "away_veil.svg" at braid_fade_in
        add BRAID_ART + "repair_fan.svg" anchor (0.5, 0.5) pos (455, 450) at braid_spin
        add BRAID_ART + "repair_wrench.svg" anchor (0.5, 0.5) pos (565, 475) at braid_wrench
        $ secs = int(game.away + 0.999)
        vbox:
            xalign 0.5
            ypos 600
            spacing 14
            text _("你去修电扇了……") style "braid_chalk" xalign 0.5
            if game.timed:
                bar value StaticValue(game.away, game.v(BRAID_HELP)) style "braid_chalk_bar" xsize 380 xalign 0.5
                text "[secs]" style "braid_chalk_big" xalign 0.5

    ## 上课铃、进度、小麦的反应、提示（遮罩上改用粉笔色）
    hbox:
        pos (60, 50)
        spacing 20
        text _("上课铃") style ("braid_chalk" if away else "braid_ink") yalign 0.5
        bar value StaticValue(game.bell_left(), game.bell()) style ("braid_chalk_bar" if away else "braid_ink_bar") xsize 600 yalign 0.5
    text "[game.progress] / [BRAID_STEPS]" style ("braid_chalk" if away else "braid_ink") pos (850, 34)
    $ bark = game.bark_text()
    ## 文字放在头部左边的空白里（头顶在 y≈170、x≈400 以右），太长就换行
    vbox:
        pos (60, 94)
        xmaximum 270
        spacing 6
        if game.knot and not game.over and not away:
            text _("卷发缠住了，连点几下解开它。") style "braid_bark"
        elif bark:
            text bark style ("braid_chalk_bark" if away else "braid_bark")
        if not game.timed:
            text _("（限时已关闭：每点一下辫子算一格时间。）") style ("braid_chalk_note" if away else "braid_ink_note")


screen braid_game(game):
    modal True

    key "K_LEFT" action Function(game.press, "L")
    key "K_RIGHT" action Function(game.press, "R")
    if game.timed and not game.over:
        timer 0.05 repeat True action Function(game.tick, 0.05)
    if game.over:
        timer (1.4 if game.success else 0.8) action Return(game.success)

    add Solid("#1d1a17")

    fixed:
        pos (50, 40)
        xysize (1000, 1000)
        use braid_paper(game)

    ## 右：同学（粉笔火柴人）
    vbox:
        xpos 1100 ypos 40 xsize 770
        spacing 16
        for r in game.requests:
            if r.state != "hidden":
                frame:
                    style "braid_card"
                    hbox:
                        spacing 18
                        if r.state in BRAID_LEFT_STATES:
                            add braid_figure(r) zoom 0.72 yalign 0.5 at braid_walk_out
                        else:
                            add braid_figure(r) zoom 0.72 yalign 0.5 at braid_walk_in
                        vbox:
                            spacing 9
                            yalign 0.5
                            text braid_name(r.rid) style "braid_name"
                            if r.state == "active":
                                text braid_line(r.rid) style "braid_line"
                            else:
                                text braid_status(r) style "braid_status"
                            if r.state in ("active", "soothed"):
                                bar value StaticValue(r.left, r.full) style "braid_bar" xsize 500
                                for cap, choice in braid_choices(r):
                                    textbutton cap action Function(game.reply, r.rid, choice) style "braid_button" sensitive (not game.over and not (choice == "help" and game.away > 0))


screen braid_result(game):
    modal True
    add Solid("#1d1a17")
    vbox:
        align (0.5, 0.45)
        xmaximum 1400
        spacing 30
        if game.success:
            text _("辫子编好了。") style "content_warning_title"
            for r in game.requests:
                if r.state != "hidden":
                    hbox:
                        xalign 0.5
                        spacing 20
                        add braid_figure(r) zoom 0.42 yalign 0.5
                        text braid_name(r.rid) style "braid_name" yalign 0.5
                        text braid_status(r) style "braid_line" yalign 0.5
            hbox:
                xalign 0.5
                spacing 40
                textbutton _("再来一次") action Return("again") style "braid_button"
                textbutton _("继续") action Return("continue") style "braid_button"
        else:
            text _("上课铃响了，辫子还没编完。") style "content_warning_title"
            textbutton _("重来") action Return("retry") style "braid_button" xalign 0.5
