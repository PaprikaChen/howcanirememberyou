## 本文件由 tools/build_script.py 从 story/bilingual_script.md 自动生成，不要手改。
## 修改剧情：编辑主稿后运行 python tools/build_script.py。


label proto_warning:

    scene black with dissolve
    call content_warning
    ## CW-C1 选择：timed_choices  〔改稿〕
    menu:
        ## CW-020  〔新增〕
        n "游戏中有几处选择带有时间限制。在那些时刻，你没有太多时间思考，这是故事体验的一部分。关闭限时可以让你从容地选择，但可能会削弱代入感。" id CW_020
        ## CW-C1A
        "保留限时选择。":
            $ timed_choices = True
        ## CW-C1B
        "关闭限时选择。":
            $ timed_choices = False


label proto_cold_open:

    scene bg rain_classroom with dissolve
    play ambient rain_roof volume 0.8 fadeout 2.0 fadein 2.0 if_changed
    ## COLD-010  〔改稿〕
    n "很多年以后，我还是记得那个闷热的雨夜。" id COLD_010
    play audio knock volume 0.8 fadein 0.3
    ## COLD-020  〔改稿〕
    n "雨点砸在教室的铁皮屋顶上。有人在敲窗户。" id COLD_020
    play sound thunder volume 0.6 fadein 0.3
    ## COLD-030  〔改稿〕
    n "是她。浑身湿透，泥一直糊到膝盖，辫子贴在脖子上。一道闪电亮起，我看见辫尾绑着一根小黄鸭发绳。" id COLD_030
    ## COLD-040  〔改稿〕
    n "她的手按在玻璃上。" id COLD_040
    ## COLD-050  〔改稿〕
    unknown_girl "“老师，求求你帮帮我。”" id COLD_050
    window hide

label proto_intro:

    scene bg intro with slowfade
    stop ambient fadeout 2.0
    stop sound fadeout 2.0
    ## INT-010  〔改稿〕
    n "那年夏天，我大二。" id INT_010
    ## INT-020  〔改稿〕
    n "我在北京长大，没怎么见过真正的山。放暑假前，我报名了学校的支教队，要去西南山区的一所村小待两个月。" id INT_020
    ## INT-022  〔改稿〕
    n "我跟队里说，我想拍一部关于这个夏天的纪录片。" id INT_022
    ## INT-024  〔改稿〕
    n "没说出口的是，九月有一个大学生纪录片影展，我想拿它去投。" id INT_024
    ## INT-040  〔新增〕
    n "我本以为，这只是一场条件比较艰苦的“夏令营”。" id INT_040

label proto_prologue:

    scene bg chapter_00 with dissolve
    pause
    scene bg prologue with dissolve
    ## PRO-010  〔L5〕
    n "出发前，支教队在群里收集大家的花名。" id PRO_010
    ## PRO-020  〔L7〕
    team "“到了学校，孩子们就这样叫我们。给自己取个他们容易记住、也方便叫的名字吧。可以是吃的、植物，或者天气，比如小姜、小雨、栗子。”" id PRO_020
    ## PRO-030  〔L9〕
    n "我看着名单上一个个新添的名字，也给自己留了一行。" id PRO_030
    ## PRO-040  〔L13〕
    n "孩子们该怎么称呼我？" id PRO_040
    ## PRO-C1 选择：teacher_name  〔L11〕
    menu:
        ## PRO-050  〔L15〕
        n "可以自己输入，也可以选择：小姜／小雨／栗子。" id PRO_050
        ## PRO-C1A
        "自己取一个名字":
            call ask_teacher_name
        ## PRO-C1B
        "小姜":
            $ teacher_name = TeacherName("小姜")
        ## PRO-C1C
        "小雨":
            $ teacher_name = TeacherName("小雨")
        ## PRO-C1D
        "栗子":
            $ teacher_name = TeacherName("栗子")

    ## PRO-070  〔L19〕
    n "我在名单上写下：[teacher_name]。" id PRO_070
    ## PRO-080  〔L21〕
    n "以后在这里，我就是[teacher_name]老师了。" id PRO_080
    ## PRO-090  〔改稿〕
    n "从机场出发，往山的方向开了两个小时，又在镇上搭了三轮车，翻过一个又一个山头，我们才终于到了。" id PRO_090
    ## PRO-095  〔新增〕
    n "路两边的玉米还是青绿的，穗子上垂着长长的须。" id PRO_095

label proto_act1:

    call start_day(1)
    scene bg chapter_01 with dissolve
    stop ambient fadeout 2.0
    pause
    scene bg dusk_classroom with dissolve
    $ play_crowd()
    ## A1-010  〔L26〕
    n "我第一次见到她，是在高年级班的教室里。" id A1_010
    ## A1-020  〔改稿〕
    n "课间，班里的女生嬉笑打闹成一团。有人朝我们这边看了一眼，又转回去，凑到同伴耳边说话。" id A1_020
    ## A1-030  〔L30〕
    girl_a "“欸，今天体育课之后你们有闻到小麦身上的酸臭味吗？”" id A1_030
    ## A1-040  〔L32〕
    girl_b "“你再这样说，小心我跟她说你这个暑假愿意当她的同桌啊~”" id A1_040
    ## A1-050  〔L34〕
    n "几句压低了声音的议论，夹在笑声里飘过来。" id A1_050
    ## A1-060  〔L36〕
    n "在我们这些山外来的老师的参与和注视下，她们似乎正努力表演一场平常的日子。我不知道，假如我们不在这里，她们会不会也是这个样子。" id A1_060
    ## A1-070  〔L38〕
    n "就在这时，一个女孩带着嗔怒的声音从走廊深处传来。紧接着，三两个刚才一直围着我们转的男孩一边大叫，一边往教室这边跑。" id A1_070
    ## A1-080  〔L40〕
    boys "“小麦来了！”" id A1_080
    show mai anxious at figure_at(0.5, 0.86), wobble
    ## A1-090  〔L42〕
    n "一个竹竿般干瘦、黝黑的女孩，追着他们从教室后门趔趄着跑进来。" id A1_090
    ## A1-100  〔L44〕
    unknown_girl "“老师！他又在外面到处造我的谣！”" id A1_100
    ## A1-110  〔L46〕
    n "她指着刚跑过去的一个男孩，气还没喘匀。" id A1_110
    ## A1-120  〔L48〕
    n "她是单眼皮，眼睛却又圆又亮." id A1_120
    ## A1-130  〔L48〕
    n "她的头发是很典型的自然卷，没有怎么打理，显得毛毛躁躁的。但夕阳透过窗户照在上面，又显得毛茸茸的。" id A1_130
    ## A1-140  〔L50〕
    n "她刚站定，其他几个女孩便装作漫不经心地，往讲台或教室前门挪了两步。仿佛以她为圆心，地上忽然划出了一道看不见的界线。" id A1_140
    ## A1-150  〔L52〕
    n "她们弯着眼角，移动时互相看着，像是有什么心照不宣的笑话，可以在眼波流转间传递。" id A1_150
    ## A1-160  〔L54〕
    n "噢，我感觉我知道了，那个自然卷的女孩，可能就叫{=em}小麦{/=em}。" id A1_160
    ## A1-170  〔L56〕
    n "她还在嗔怒着看着那个男孩，等着他为自己说过的话作个解释。我却忍不住又看了一眼她身旁空出来的位置。" id A1_170
    ## A1-180  〔L58〕
    inner_teacher "刚才那些话，她听见了吗？要不要先问问发生了什么？" id A1_180
    ## A1-190  〔L60〕
    inner_visitor "我们才刚来。我还分不清，他们是在玩闹，还是有人真的受了委屈。" id A1_190
    ## A1-C1 选择：first_contact  〔L62〕
    menu:
        ## A1-C1A
        "走到她身边，问问发生了什么。":
            $ first_contact = "listen"
            ## A1-200  〔L66〕
            n "我走过去，稍稍弯下腰。" id A1_200
            ## A1-210  〔L68〕
            me "“你叫小麦是吗？他说了什么？”" id A1_210
            ## A1-220  〔改稿〕
            mei "“我那天在拍天上的云！他刚好从窗户外面走过去！”" id A1_220
            ## A1-230  〔改稿〕
            me "“原来是这样。老师相信你。”" id A1_230
            ## A1-235  〔改稿〕
            n "我转过头，看向那几个男孩。" id A1_235
            ## A1-240  〔改稿〕
            me "“你们听见她说的了吗？”" id A1_240
            ## A1-242  〔改稿〕
            n "他们敷衍地点了点头，然后突然一哄而散，跑出了教室。" id A1_242
            show mai calm at figure_at(0.5, 0.86), wobble
            ## A1-244  〔改稿〕
            n "我只好叹了口气，拍了拍小麦的肩膀。" id A1_244
            ## A1-246  〔改稿〕
            n "她低头看了看我的手，没有躲开。" id A1_246
        ## A1-C1B
        "先问问那几个男孩。":
            $ first_contact = "boys"
            ## A1-250  〔L78〕
            me "“你们刚才在说什么？她为什么追着你们跑？”" id A1_250
            ## A1-260  〔L80〕
            boy "“没什么，老师，开玩笑的。”" id A1_260
            ## A1-270  〔改稿〕
            me "“开玩笑要两个人都笑才算。她笑了吗？”" id A1_270
            show mai calm at figure_at(0.5, 0.86), wobble
            ## A1-280  〔改稿〕
            n "男孩们互相看了看，嘀咕了一句“对不起”，一溜烟跑了。我再转过头时，小麦还站在原地，看着我。" id A1_280
        ## A1-C1C
        "暂时不追问，先和她打个招呼。":
            $ first_contact = "introduce"
            ## A1-290  〔L88〕
            me "“你叫小麦，对吗？我是新来的老师。”" id A1_290
            show mai calm at figure_at(0.5, 0.86), wobble
            ## A1-300  〔L90〕
            n "她点点头，又问了我的名字。" id A1_300
            ## A1-310  〔L92〕
            me "“[teacher_name]。叫我[teacher_name]老师就好。”" id A1_310
            ## A1-320  〔L94〕
            n "她把这个名字念了一遍，又叫了一声“[teacher_name]老师”，自己先笑了。" id A1_320
            ## A1-325  〔改稿〕
            n "门口那几个男孩还在探头探脑。没有人再提刚才的事。" id A1_325

    play sound school_bell volume 0.3 fadein 0.3
    hide mai
    ## A1-330  〔改稿〕
    n "上课铃响了。孩子们三三两两回到座位上。" id A1_330
    ## A1-340  〔改稿〕
    n "小麦坐在最后一排靠中间的位置。她旁边的两个座位都空着。" id A1_340
    ## A1-350  〔改稿〕
    n "吵架结束了。但那道看不见的线，并没有跟着铃声一起消失。" id A1_350

label proto_act2:

    scene bg chapter_02 with dissolve
    stop ambient fadeout 2.0
    stop crowd fadeout 2.0
    pause
    scene bg village_restaurant with dissolve
    ## A2-010  〔新增〕
    n "学校旁边有一家小餐馆。还没走到门口，一股猪骚味就迎面扑了过来。" id A2_010
    ## A2-020  〔新增〕
    n "老板和老板娘笑着招呼我们进去。我们跟他们说好，这两个月都在这里吃。附近也没有什么别的选择。" id A2_020
    ## A2-030  〔新增〕
    n "我以为进了这么深的山，吃饭总该便宜些。看过菜单才知道，和北京也没差多少。" id A2_030
    ## A2-040  〔新增〕
    n "尤其是肉菜。我们对着菜单商量了一会儿，还是点了几道。" id A2_040
    ## A2-050  〔新增〕
    n "菜端上来，肉零零星星地散在里面。夹起一块翻过来，大半是肥的。" id A2_050
    ## A2-060  〔新增〕
    n "老板娘又端来一盘菜，笑着叫我们趁热吃。那股猪骚味一直没有散。" id A2_060
    ## A2-070  〔新增〕
    n "后来，每到中午，总有几个孩子围过来看我们吃饭。他们不伸手，只是看着桌上的肉菜。" id A2_070
    ## A2-080  〔新增〕
    n "他们吃的是一块钱一碗的素面，里面没有肉。每天都是。" id A2_080
    ## A2-090  〔新增〕
    n "我们会从盘里分些肉给他们。几个孩子接过去，说谢谢老师。" id A2_090
    scene bg night_classroom with dissolve
    play ambient crickets volume 0.6 fadeout 2.0 fadein 2.0 if_changed
    ## A2-100  〔改稿〕
    n "晚饭后，同事说，得趁村里的小卖部关门前，去买打地铺用的被单。" id A2_100
    ## A2-110  〔改稿〕
    n "教室里没有床。今晚，我们要睡在水泥地上。" id A2_110
    scene bg shop with dissolve
    play ambient crickets volume 0.6 fadeout 2.0 fadein 2.0 if_changed
    ## A2-120  〔L125〕
    n "村里的小卖部，还没有城市里一间普通卧室大。门口放着一个巨大的冰柜，里面有三四种冰棍。" id A2_120
    ## A2-130  〔L125〕
    n "几个晒得黝黑的大叔坐在小木椅上，扇着蒲扇聊天。看见我们几个年轻姑娘结伴过来，他们投来好奇而友善的目光。" id A2_130
    ## A2-140  〔L127〕
    n "我忽然想起，来之前曾在网上读过一些年轻支教女老师遭到当地人侵害的讲述。" id A2_140
    ## A2-150  〔L127〕
    n "一点害怕从心口像电流一样蹿过，又被两侧同伴肩膀上传来的体温慢慢捂散了。" id A2_150
    ## A2-160  〔L129〕
    n "而眼前这几位大叔，神情实在友善，似乎只是对突然出现的我们感到好奇。" id A2_160
    ## A2-C2 选择：greeted_villagers  〔L133〕
    menu:
        ## A2-170  〔L131〕
        n "进小卖部前，要打个招呼吗？" id A2_170
        ## A2-C2A
        "当然。他们看起来很友善，也似乎对我们很好奇。":
            $ greeted_villagers = True
            ## A2-180  〔L137〕
            me "“叔叔好。”" id A2_180
            ## A2-190  〔L139〕
            n "他们像是没想到我们会先开口，愣了一下，随后腼腆地笑着举了举手。" id A2_190
            ## A2-200  〔L141〕
            villager "“来买东西啊？”" id A2_200
        ## A2-C2B
        "还是算了。我们主要在小学里教书，和他们未必会有多少交集，似乎也不一定要打招呼。":
            $ greeted_villagers = False
            ## A2-210  〔L145〕
            n "我跟着同伴走进店里。身后的聊天声停了一会儿，很快又继续了。" id A2_210

    ## A2-C3 选择：sheet_choice  〔L149〕
    menu:
        ## A2-220  〔L147〕
        n "店里的被单没有多少种。我站在货架前，挑了起来。" id A2_220
        ## A2-C3A
        "粉色的小猪佩奇床单。":
            $ sheet_choice = "pink"
            ## A2-221  〔新增〕
            n "我挑了粉色的小猪佩奇。在这个陌生的地方，我想要一点可爱的、能让自己笑出来的东西。" id A2_221
        ## A2-C3B
        "浅蓝色的毛绒床单。":
            $ sheet_choice = "blue"
            ## A2-223  〔新增〕
            n "我挑了浅蓝色的毛绒床单。今天已经够累了，至少晚上，我想睡得软一点。" id A2_223
        ## A2-C3C
        "朴素的浅灰色床单。":
            $ sheet_choice = "gray"
            ## A2-225  〔新增〕
            n "我挑了朴素的浅灰色。不起眼，也耐脏，在这里大概最实用。" id A2_225
        ## A2-C3D
        "舒适的纯黑色床单。":
            $ sheet_choice = "black"
            ## A2-227  〔新增〕
            n "我挑了纯黑色。看起来干净利落，脏了也不显。" id A2_227

    scene bg night_classroom with dissolve
    play ambient crickets volume 0.6 fadeout 2.0 fadein 2.0 if_changed
    ## A2-230  〔L159〕
    n "买完东西，我们回到教室。出于安全考虑，二十几位女老师决定一起在一间教室里打地铺。" id A2_230
    ## A2-240  〔改稿〕
    n "我在水泥地上铺开被单，试着躺了一下。水泥地很硬，硌得肩膀发疼。" id A2_240
    ## A2-260  〔L169〕
    n "教室里有几扇很大的窗户。人太多，只能把窗户打开，屋里却依旧像蒸笼一样闷热。" id A2_260
    ## A2-270  〔L171〕
    n "窗外就是茂盛的山林。喋喋不休的蝉鸣，似乎离耳朵很近，很近——" id A2_270
    ## A2-K2 条件分支：sheet_choice  〔L173–183〕
    ## A2-K2a 【如果选择粉色或浅蓝色床单】
    if sheet_choice in ("pink", "blue"):
        ## A2-280  〔L175〕
        n "哦，天哪，是真的很近！" id A2_280
        ## A2-290  〔L177〕
        n "一只有食指那么长、肥美的蝉，从地板上扑腾到了眼前。" id A2_290
        ## A2-300  〔L177〕
        n "还有各种形状、各种颜色的小虫子，热情地造访了我的床单。在浅色的底布上，每一只都显得格外清楚。" id A2_300
        ## A2-310  〔改稿〕
        n "我忘了，虫子更喜欢亮色。这是在城市里生活的我从来不用考虑的事。" id A2_310
    ## A2-K2b 【如果选择浅灰色或黑色床单】
    elif sheet_choice in ("gray", "black"):
        ## A2-320  〔L183〕
        n "脚边忽然响起一阵扑腾声。我低头一看，一只有食指那么长的蝉正挣扎着翻身。" id A2_320
        ## A2-322  〔改稿〕
        n "幸好我选了深色。虫子们似乎并不怎么喜欢它，就算有几只爬了上来，也和床单的颜色融成一片，几乎看不见。" id A2_322

    ## A2-330  〔L185〕
    n "今天已经很累，很累了。我认命地躺下。" id A2_330
    ## A2-332  〔改稿〕
    n "夜里很热，蝉声一直没停。" id A2_332
    play audio knock volume 0.8 fadein 0.3
    ## A2-334  〔改稿〕
    n "叩，叩。有人在敲窗户。" id A2_334
    ## A2-336  〔改稿〕
    n "二十几个人一下子都安静了。黑暗里，不知道是谁抓住了我的手腕。" id A2_336
    ## A2-338  〔改稿〕
    n "我想起了来之前在网上读到的那些事。" id A2_338
    ## A2-339  〔改稿〕
    n "窗外的人影晃了一下。" id A2_339
    ## A2-K3 条件分支：greeted_villagers  〔改稿〕
    ## A2-K3a 【如果打过招呼】
    if greeted_villagers:
        $ choice_echo()
        ## A2-341  〔改稿〕
        n "“睡了没？”是小卖部门口那位大叔的声音。" id A2_341
        ## A2-342  〔改稿〕
        n "他把一盘蚊香搁在窗台上。" id A2_342
        ## A2-343  〔改稿〕
        villager "“晓得你们城里小姑娘没见识过山里的毒蚊子。点上。”" id A2_343
        ## A2-344  〔改稿〕
        n "蚊香点起来，屋里有了一股淡淡的烟味。那天晚上，我居然睡得比想象中好。" id A2_344
    ## A2-K3b 【如果没打招呼】
    elif not greeted_villagers:
        $ choice_echo()
        ## A2-346  〔改稿〕
        n "人影在窗外停了一会儿，什么也没说，走了。" id A2_346
        ## A2-348  〔改稿〕
        n "我睁着眼睛躺到很晚。" id A2_348

    ## A2-360  〔L197〕
    n "半梦半醒间，我又想起那个叫小麦的女孩。" id A2_360
    ## A2-370  〔L199〕
    n "她看向同学们的眼神，让我想起一群小羊里最不合群的那一只。" id A2_370
    ## A2-380  〔L201〕
    n "至少，在当时的我看来，是这样的。" id A2_380
    call end_of_day(1)

label proto_act3:

    scene bg chapter_03 with dissolve
    stop ambient fadeout 2.0
    stop crowd fadeout 2.0
    pause
    scene bg plain with dissolve
    play ambient cicadas volume 0.4 fadeout 2.0 fadein 2.0 if_changed
    ## A3-K1 条件分支：greeted_villagers  〔改稿〕
    ## A3-K1a 【如果第二幕打过招呼】
    if greeted_villagers:
        ## A3-010  〔改稿〕
        n "醒来时，窗台上的蚊香已经烧成了一圈灰白的灰。其他老师已经在起床交谈了。" id A3_010
    ## A3-K1b 【如果第二幕没打招呼】
    elif not greeted_villagers:
        ## A3-020  〔改稿〕
        n "第二天早上，窗台上放着一盘蚊香。没有人知道是谁放的。" id A3_020

    show cicada dead at figure_at(0.5, 0.64)
    ## A3-030  〔L214〕
    n "映入眼帘的，是一具近在咫尺、硕大的蝉的尸体。" id A3_030
    ## A3-040  〔L216〕
    n "经过一整晚的磨砺，这一次，我竟然没有被这位室友吓到。" id A3_040
    ## A3-050  〔L218〕
    n "收拾完地铺，我们再次走进教室。" id A3_050
    scene bg morning_classroom with dissolve
    $ play_crowd()
    ## A3-060  〔L220〕
    n "第一节课还没开始。女生们三三两两围在一起聊天，男生们有的在教室里跑来跑去，有的在外面踢球。" id A3_060
    ## A3-070  〔L222〕
    n "我一眼又看到了她——小麦。" id A3_070
    ## A3-080  〔改稿〕
    n "她坐在教室后面靠中间的位置，低着头，一个人看手机。头发依旧乱糟糟的。" id A3_080
    ## A3-082  〔改稿〕
    n "那是一部很旧的手机，屏幕上全是蛛网一样的裂痕，手机壳已经发黄，边角上沾着一点柴灰。" id A3_082
    ## A3-084  〔改稿〕
    n "她的手指在屏幕上划来划去，在翻照片。隔着那些裂痕，我依稀看见一片天空，几只鸡，还有小孩的脸。" id A3_084
    ## A3-086  〔改稿〕
    inner_visitor "不知道这是她从哪儿弄来的。是在城里打工的爸妈用旧了，留给她的吧。" id A3_086
    show mai anxious at figure_at(0.5, 0.86), wobble
    ## A3-088  〔改稿〕
    n "我朝她走过去。她察觉到了，飞快地按灭屏幕，把手机扣在桌上，耳朵尖有点红。" id A3_088
    ## A3-K2 条件分支：first_contact  〔L226–250〕
    ## A3-K2a 【如果昨天先听她解释】
    if first_contact == "listen":
        $ choice_echo()
        show mai calm at figure_at(0.5, 0.86), wobble
        ## A3-090  〔改稿〕
        n "她看见是我，肩膀松了下来。" id A3_090
        ## A3-100  〔改稿〕
        mei "“[teacher_name]老师，那个男生今天跟我说对不起了。”" id A3_100
        ## A3-110  〔改稿〕
        n "她说得很快，像是憋了一早上，就等着告诉我。" id A3_110
    ## A3-K2b 【如果昨天先问男孩】
    elif first_contact == "boys":
        $ choice_echo()
        show mai calm at figure_at(0.5, 0.86), wobble
        ## A3-120  〔L236〕
        n "她看见我，先朝门口望了一眼。" id A3_120
        ## A3-130  〔L238〕
        mei "“[teacher_name]老师，他今天还没来。”" id A3_130
        ## A3-140  〔L240〕
        n "我顺着她的视线看过去，又转回来，对她点了点头。" id A3_140
    ## A3-K2c 【如果昨天先介绍自己】
    elif first_contact == "introduce":
        $ choice_echo()
        show mai calm at figure_at(0.5, 0.86), wobble
        ## A3-150  〔L244〕
        n "她抬起头，像是在回忆，试探着叫了一声：" id A3_150
        ## A3-160  〔L246〕
        mei "“[teacher_name]老师？”" id A3_160
        ## A3-170  〔L248〕
        me "“对，你记住了。”" id A3_170
        ## A3-180  〔L250〕
        n "她笑了一下。" id A3_180

    ## A3-190  〔L252〕
    n "我看着她的头发，心底忽然涌起一股冲动。" id A3_190
    ## A3-200  〔L254〕
    n "昨天那几个女孩挪开的脚步又浮现在眼前。也许，至少今天，我能让她有一点不一样的心情。" id A3_200
    ## A3-210  〔改稿〕
    n "我在她旁边蹲下来，指了指自己的辫子。" id A3_210
    ## A3-220  〔L258〕
    me "“小麦，你喜欢老师这样的麻花辫吗？我可以帮你扎一个吗？”" id A3_220
    ## A3-230  〔L260〕
    n "她看了看我的辫子，又摸了摸自己的头发。" id A3_230
    ## A3-240  〔L262〕
    mei "“现在吗？”" id A3_240
    ## A3-250  〔L264〕
    me "“你愿意的话。”" id A3_250
    ## A3-260  〔L266〕
    n "她把手机收了起来。" id A3_260
    hide mai
    ## A3-270  〔草案〕
    n "她转过身，背对着我坐好。" id A3_270
    ## A3-280  〔草案〕
    n "离得近了，她的头发里有一股太阳和柴火烟的味道。看着蓬松，摸上去却很干，梳子一下去就被卷发缠住。我只好放下梳子，用手指一点点把头发分成三股。" id A3_280
    ## A3-290  〔草案〕
    n "她坐得笔直，一动不动，好像稍微动一下，刚编好的部分就会散开。" id A3_290
    ## A3-300  〔草案〕
    me "“疼吗？”" id A3_300
    ## A3-310  〔草案〕
    mei "“不疼。”她顿了顿，“[teacher_name]老师你快点，要上课了。”" id A3_310
    ## A3-315  〔新增〕
    n "我的手指刚动起来，教室里就有人叫我了。" id A3_315
    call braid_minigame
    ## A3-K8 条件分支：braid_upset  〔改稿〕
    ## A3-K8a 【如果没有同学走开】
    if not braid_upset:
        ## A3-318  〔改稿〕
        n "现在我终于知道，要同时应付这么多孩子有多累了。还好，我做得还不错。" id A3_318
    ## A3-K8b 【如果有同学难过或生气地走开】
    elif braid_upset:
        ## A3-319  〔改稿〕
        n "现在我终于知道，要同时应付这么多孩子有多累了。可我还是没能顾上所有人。" id A3_319

    ## A3-K4 条件分支：braid_left  〔新增〕
    ## A3-K4a 【如果一直没有离开小麦】
    if not braid_left:
        $ trust += 1
        ## A3-420  〔草案〕
        n "我编完最后一节，从手腕上褪下一根小黄鸭发绳，在辫尾绕了两圈。" id A3_420
    ## A3-K4b 【如果中途去修了电扇】
    elif braid_left:
        ## A3-425  〔新增〕
        n "等我修好电扇回来，她还一动不动地坐着，刚编好的那一截已经松开了一点。我重新编好，从手腕上褪下一根小黄鸭发绳，在辫尾绕了两圈。" id A3_425

    ## A3-430  〔草案〕
    me "“好了。”" id A3_430
    ## A3-440  〔草案〕
    n "小麦伸手往后摸了摸辫子，从上摸到下，又从上摸到下。" id A3_440
    ## A3-K5 条件分支：braid_upset  〔新增〕
    ## A3-K5a 【如果两个女生难过地走开了】
    if "girls" in braid_upset:
        ## A3-442  〔新增〕
        n "那两个女生一整个早上都没再来找我。" id A3_442
    ## A3-K5b 【否则】不播放
    elif "girls" not in braid_upset:
        pass

    ## A3-K6 条件分支：braid_upset  〔新增〕
    ## A3-K6a 【如果男孩生气地走开了】
    if "boy" in braid_upset:
        ## A3-444  〔新增〕
        n "那个男孩一整节课都把头扭向窗外。" id A3_444
    ## A3-K6b 【否则】不播放
    elif "boy" not in braid_upset:
        pass

    ## A3-K7 条件分支：braid_upset  〔新增〕
    ## A3-K7a 【如果告状的女生哭了】
    if "tattle" in braid_upset:
        ## A3-446  〔新增〕
        n "女生乙趴在桌上，好久都没有抬头。" id A3_446
    ## A3-K7b 【否则】不播放
    elif "tattle" not in braid_upset:
        pass

    ## A3-380  〔草案〕
    inner_teacher "她们也都是我的学生。刚才那几分钟里，我到底顾上了谁？" id A3_380
    ## A3-390  〔草案〕
    inner_visitor "不过是一根辫子。今天编完了又怎样？两个月以后，谁来给她编？" id A3_390
    play sound school_bell volume 0.3 fadein 0.3
    ## A3-490  〔草案〕
    n "上课铃响了。她把辫子拨到胸前，一整节课都没有再拨回去。" id A3_490
    scene bg village_restaurant with dissolve
    stop crowd fadeout 2.0
    ## A3-510  〔新增〕
    n "中午，我们又去了学校旁边的餐馆。" id A3_510
    ## A3-520  〔新增〕
    n "几个孩子吃完了面，还在桌边待着。老板娘端菜过来，他们就往旁边让一让。" id A3_520
    ## A3-530  〔新增〕
    me "“你们中午不回家吗？”" id A3_530
    ## A3-540  〔新增〕
    n "“回不去。下午还要上课。”一个孩子说。" id A3_540
    ## A3-550  〔新增〕
    me "“你家很远？”" id A3_550
    ## A3-560  〔新增〕
    n "他点点头：“走高速过来。”" id A3_560
    ## A3-570  〔新增〕
    me "“高速公路？”" id A3_570
    ## A3-580  〔新增〕
    n "他说，先从家里出来，爬上高速公路，沿着最边上的应急车道走一个多小时，再翻下来。" id A3_580
    ## A3-590  〔新增〕
    me "“下来就到学校了？”" id A3_590
    ## A3-600  〔新增〕
    n "“还要走半个小时山路。”" id A3_600
    ## A3-610  〔新增〕
    n "我问他们早上几点出门。有的说四点多，有的说五点。" id A3_610
    ## A3-620  〔新增〕
    n "后来才知道，班里不少孩子都是这样来的。学校已经在山里，他们的家还在更远的山里。" id A3_620
    ## A3-630  〔新增〕
    n "我低头扒了一口饭。刚才只想到他们中午回不去，没有想到他们每天早上是怎么来的。" id A3_630

label proto_act4:

    scene bg chapter_04 with dissolve
    stop ambient fadeout 2.0
    stop crowd fadeout 2.0
    pause
    scene bg dusk_classroom with dissolve
    play ambient cicadas volume 0.4 fadeout 2.0 fadein 2.0 if_changed
    ## A4-010  〔草案〕
    n "放学后，教室几分钟就空了。椅子刮过地面，嬉笑声随着脚步声跑远，然后一切安静下来。" id A4_010
    ## A4-020  〔草案〕
    n "小麦还坐在座位上，捏着辫梢。" id A4_020
    ## A4-030  〔草案〕
    n "我在收拾背包。出发前我跟大家说过，想拍一部关于这个夏天的纪录片。可来了两天，相机一直躺在包里，我一次都没拿出来。" id A4_030
    ## A4-040  〔草案〕
    n "她先看见了。" id A4_040
    ## A4-050  〔草案〕
    mei "“[teacher_name]老师，那是相机吗？你要拍我们吗？”" id A4_050
    ## A4-060  〔草案〕
    n "她凑过来，盯着包口露出来的那截镜头，眼睛亮亮的。" id A4_060
    ## A4-070  〔草案〕
    inner_lens "被排挤的女孩，夕阳，刚编好的辫子。如果整部片子只跟拍一个人，就该是她。" id A4_070
    ## A4-080  〔草案〕
    inner_teacher "让她当主角，她会觉得自己终于被看见了吗？还是会让其他孩子更觉得她特殊？" id A4_080
    ## A4-C1 选择：camera  〔草案〕
    menu:
        ## A4-C1A
        "邀请她当纪录片的主角。":
            $ camera = True
            ## A4-090  〔草案〕
            me "“老师想拍一部关于这个夏天的片子。你愿意当主角吗？”" id A4_090
            ## A4-100  〔草案〕
            n "她有些受宠若惊，眼睛一下子亮了起来。" id A4_100
            ## A4-110  〔草案〕
            mei "“我吗？要拍我吗？”" id A4_110
            ## A4-120  〔草案〕
            n "她捏起刚编好的麻花辫，一边思考一边摇了几下。" id A4_120
            ## A4-130  〔草案〕
            inner_visitor "虽然这么说可能不太合适，但是此刻的小麦就像摇着尾巴的天真无邪的小狗一样可爱。" id A4_130
            ## A4-140  〔草案〕
            mei "“好呀！就来拍我吧——等等啊，我先去洗个脸。”" id A4_140
            ## A4-150  〔草案〕
            n "她真的跑到水池边洗了把脸，回来时额前的头发还在滴水。" id A4_150
        ## A4-C1B
        "不邀请她。":
            $ camera = False
            ## A4-160  〔草案〕
            n "我把背包拉链拉上。" id A4_160
            ## A4-170  〔草案〕
            me "“就是拍拍山上的风景。”" id A4_170
            ## A4-180  〔草案〕
            n "她又看了背包一眼，耸耸肩：“哦。”" id A4_180
            ## A4-190  〔草案〕
            n "那个夏天剩下的日子里，相机一直待在包里。" id A4_190

    ## A4-200  〔草案〕
    n "她走到门口，又折回来。" id A4_200
    ## A4-K1 条件分支：camera  〔草案〕
    ## A4-K1a 【如果 camera = False】
    if not camera:
        ## A4-210  〔草案〕
        mei "“[teacher_name]老师，周六你要不要来我家里玩？我家有狗。”" id A4_210
    ## A4-K1b 【如果 camera = True】
    elif camera:
        ## A4-220  〔草案〕
        mei "“[teacher_name]老师，周六你要不要来我家里拍摄？我家里有小狗。”" id A4_220

    ## A4-230  〔草案〕
    me "“你家远吗？”" id A4_230
    ## A4-240  〔草案〕
    n "她想了想：" id A4_240
    ## A4-250  〔草案〕
    mei "“跟别的同学家比起来不算远吧。翻过一座小山就到了。”" id A4_250

label proto_act5:

    call start_day(6)
    scene bg chapter_05 with dissolve
    stop ambient fadeout 2.0
    pause
    scene bg country_path with dissolve
    play ambient wind volume 0.5 fadeout 2.0 fadein 2.0 if_changed
    show mai back at figure_at(0.43, 0.87), wobble
    ## A5-010  〔草案〕
    n "小麦说的“不远”，是对她自己来说的。" id A5_010
    ## A5-020  〔草案〕
    n "去她家要先通过一条小溪上方的木桥，然后小心翼翼地穿过几个水稻田之间的细细高高的田埂。田埂两侧，是一望无际的翠绿的稻田，生意盎然。" id A5_020
    ## A5-030  〔草案〕
    n "田野的尽头是一个不高不矮的小山坡。有一条之字形的土路，顺着山坡往上绕。她穿着塑料凉鞋，走得像在平地上，每拐几个弯就停下来等我。" id A5_030
    ## A5-035  〔新增〕
    n "她的辫子是自己编的，有点歪，辫尾还绑着那根小黄鸭发绳，在背后一跳一跳的。" id A5_035
    scene bg mountain_path with dissolve
    play ambient wind volume 0.5 fadeout 2.0 fadein 2.0 if_changed
    ## A5-040  〔草案〕
    n "越往后走，土路两侧开始长出细细密密的竹林。午后的阳光透过密密麻麻的竹林，大部分的光线都被竹叶挡住了，晕头转向地在这条小路上散开来。" id A5_040
    ## A5-050  〔草案〕
    n "为数不多的细软的光照进来，有的落在了路上变成光斑，有的栖息在小麦的肩膀和头发上，给她笼上一层阳光罩子。" id A5_050
    ## A5-060  〔草案〕
    mei "“[teacher_name]老师，你走得好慢。”" id A5_060
    ## A5-070  〔草案〕
    n "我气喘吁吁两眼昏花地企图跟上。" id A5_070
    ## A5-080  〔草案〕
    me "“老师不像你那么年轻了。”" id A5_080
    ## A5-090  〔草案〕
    n "她笑得蹲在一块石头上，半天站不起来。" id A5_090
    ## A5-100  〔草案〕
    n "到了山顶，能看见后面的整片山谷。在茂盛的树林中央，非常突兀地耸起了一座实在算不上太美观的白房子，有两层楼。一条细细弯弯的小路从山脚一直通向了房子。" id A5_100
    show dog stand at figure_at(0.68, 0.785), wobble
    play sound bark volume 0.5 fadein 0.3
    ## A5-110  〔草案〕
    n "一条黄狗顺着山路冲上来，一头扑到小麦腿上。" id A5_110
    ## A5-120  〔草案〕
    mei "“它叫麦仔。”小麦捧着它的脸，“我取的名字。因为它是我的。”" id A5_120
    ## A5-K4 条件分支：camera  〔新增〕
    ## A5-K4a 【如果 camera = True】
    if camera:
        ## A5-C4 选择：maizai_shot  〔新增〕
        menu (timer=5):
            ## A5-C4A
            "拍下这一刻。":
                $ maizai_shot = True
                ## A5-125  〔新增〕
                n "我按下了快门。小麦还捧着它的脸，没有发现。" id A5_125
            ## A5-C4B
            "只是看着。":
                pass

    ## A5-K4b 【如果 camera = False】不播放
    elif not camera:
        pass

    ## A5-130  〔草案〕
    n "麦仔把我的鞋闻了一圈，好像认定我还算可以，摇着尾巴跑在我们前面。" id A5_130
    ## A5-140  〔草案〕
    mei "“它很通人性的，每天早上送我到山顶，”小麦说，“晚上就在山顶等我回来。”" id A5_140
    scene bg mei_yard with dissolve
    play ambient chickens volume 0.5 fadeout 2.0 fadein 2.0 if_changed
    ## A5-150  〔草案〕
    n "小麦的家在山谷最里面。我们从山脚出发往林子里走，在几棵李子树和梨子树后面有一个用一些树枝围起来的院子。" id A5_150
    ## A5-160  〔草案〕
    n "一大群鸡正咕咕咕地往院子里鱼贯而入，啄着地上撒开的一层黄澄澄的陈玉米，大摇大摆地往屋里去了。" id A5_160
    ## A5-170  〔草案〕
    n "当我们也踩上那层咯吱作响的玉米粒时，从屋子后方突然窜出来两个小小的身影。" id A5_170
    show kids stand at figure_at(0.68, 0.82), wobble
    ## A5-180  〔草案〕
    n "我定睛一看，是两个四五岁的小孩子，其中的女孩比男孩要高大一些。他们没有穿鞋，脚上的泥巴顺着沾满泥点的裤脚一路向上延伸到浅色的脱线背心上，甚至圆圆的脸颊和小小的鼻头上也都黑乎乎的。" id A5_180
    ## A5-190  〔草案〕
    mei "“[teacher_name]老师，这是我的二妹和四弟。”" id A5_190
    ## A5-200  〔草案〕
    n "她正想要招呼弟弟妹妹来给我打招呼，结果两个小孩看到院子里出现了陌生人，不约而同地往屋里躲去，边跑还一边回头偷瞄我。" id A5_200
    scene bg mei_house with dissolve
    ## A5-210  〔草案〕
    n "我于是跟小麦一起往屋里走去。明明是夏日的午后，屋里不知道为何却黑黢黢的。客厅里放了一张竹床，一位老人坐在上面，脚上也没有穿鞋，腿上盖着一条看不出颜色的毯子。" id A5_210
    ## A5-220  〔草案〕
    n "麦仔不知道何时进了屋，乖乖地趴在老人脚边。" id A5_220
    ## A5-230  〔草案〕
    mei "“这是爷爷。爷爷的腿不能走了。”小麦说，语气就像在说今天天气很热。" id A5_230
    ## A5-240  〔草案〕
    n "屋里有一股很重的气味，是很久没有换洗的被褥和尿的味道。几只苍蝇在竹床边上绕来绕去。" id A5_240
    ## A5-250  〔草案〕
    n "小麦像是什么都没闻到。她放下书包，熟练地把爷爷身后的枕头垫高了一点。" id A5_250
    ## A5-C1 选择：pass  〔草案〕
    $ loop_A5_C1 = ()
    while "break" not in loop_A5_C1:
        menu:
            ## A5-260  〔草案〕
            n "爷爷用方言问了句什么。他张嘴的时候，口水从嘴角流淌出来，一直掉在了水泥地上。他抬起手想擦掉，但是手背又沾上了新的口水丝。" id A5_260
            ## A5-C1A
            "找找口袋里有没有纸。" (greyed="A5-C1A" in loop_A5_C1):
                $ loop_A5_C1 += ("A5-C1A",)
                ## A5-270  〔草案〕
                n "我摸了摸口袋，发现今天并没有带纸。" id A5_270
            ## A5-C1B
            "看看屋里有没有可以用的东西。" (greyed="A5-C1B" in loop_A5_C1):
                $ loop_A5_C1 += ("A5-C1B",)
                ## A5-280  〔草案〕
                n "客厅里除了一张桌子、一张竹床和一些杂物外，并没有看到抽纸或者别的布。" id A5_280
            ## A5-C1C
            "装作什么都没有看到，一切都很正常的样子。":
                $ loop_A5_C1 += ("break",)

    ## A5-290  〔草案〕
    n "小麦走上前去，很自然地用自己的袖子替爷爷擦掉口水。" id A5_290
    ## A5-300  〔草案〕
    mei "“他问你是不是新来的老师。”" id A5_300
    ## A5-310  〔草案〕
    n "我向爷爷笑着点点头。爷爷看着我，一直不住地点头。" id A5_310
    ## A5-320  〔草案〕
    n "下午的阳光从门口斜照进来，落在爷爷的手上，落在竹床上，落在地上。" id A5_320
    ## A5-K1 条件分支：camera  〔草案〕
    ## A5-K1a 【如果 camera = True】
    if camera:
        ## A5-330  〔草案〕
        inner_lens "这样的场景如果拍下来了，评委一定会记住这个镜头……" id A5_330
        ## A5-340  〔草案〕
        inner_visitor "这股味道……我真的待不下去了。赶紧走吧。" id A5_340
        ## A5-350  〔草案〕
        inner_teacher "他知道相机是什么吗？他会愿意现在的样子被拍下来吗？这样做以后会伤害到小麦吗？" id A5_350
        ## A5-C2 选择：footage  〔草案〕
        menu:
            ## A5-C2A
            "举起相机，拍下爷爷。":
                $ footage.append("grandpa")
                ## A5-360  〔草案〕
                n "我拿出相机，按下录制键。" id A5_360
                ## A5-370  〔草案〕
                n "爷爷浑浊的眼睛看向那个精密的机器，然后他看见了那个小小的红点。" id A5_370
                ## A5-380  〔草案〕
                n "他愣了一会，想把毯子往上拉，又拉不动。最后，他把脸转向了墙，用方言说了一句话。小麦没有翻译。" id A5_380
                ## A5-390  〔草案〕
                n "小麦看了看我，又低头看着地面。" id A5_390
                ## A5-400  〔草案〕
                n "画面很美。我知道，这会是整部片子里最好的一个镜头。" id A5_400
            ## A5-C2B
            "把相机留在包里。":
                pass
                ## A5-410  〔草案〕
                n "我没有拿相机，在竹床边的小板凳上坐了下来。" id A5_410
                ## A5-420  〔草案〕
                n "过了一会儿，爷爷把身边一盆豆子推到我面前。我学着他的样子剥豆子，比他慢得多，也笨得多。" id A5_420
                ## A5-430  〔草案〕
                n "他看了我一会儿，笑了起来。" id A5_430
                ## A5-440  〔草案〕
                grandpa "“留下吃饭。”" id A5_440
                ## A5-450  〔草案〕
                n "这句我听懂了。小麦冲我咧嘴笑。那是我第一次看见她笑得一双眼睛都眯起来了。" id A5_450

    ## A5-K1b 【如果 camera = False】
    elif not camera:
        ## A5-460  〔草案〕
        n "我在竹床边的小板凳上坐下。" id A5_460

    ## A5-K2 条件分支：footage  〔草案〕
    ## A5-K2a 【如果拍下了爷爷】不播放
    if "grandpa" in footage:
        pass
    ## A5-K2b 【如果没有拍爷爷】
    elif "grandpa" not in footage:
        ## A5-470  〔草案〕
        grandpa "“你是哪里来的？”" id A5_470
        ## A5-480  〔草案〕
        n "小麦在旁边帮着翻译。我说，北京。" id A5_480
        ## A5-490  〔草案〕
        grandpa "“远哦。”" id A5_490
        ## A5-500  〔草案〕
        n "不像是问句，倒像在说今天会下雨。" id A5_500
        ## A5-K3 条件分支：camera  〔草案〕
        ## A5-K3a 【如果前面选了“把相机留在包里”】
        if camera:
            ## A5-510  〔草案〕
            n "他又问小麦在学校乖不乖。我说小麦很聪明。爷爷点点头，继续低头剥着豆子。" id A5_510
        ## A5-K3b 【如果 camera = False】
        elif not camera:
            ## A5-520  〔草案〕
            n "他又问小麦在学校乖不乖。我说小麦很聪明。爷爷点点头，开始低头剥一盆豆子。" id A5_520


    scene bg country_path with dissolve
    play ambient wind volume 0.5 fadeout 2.0 fadein 2.0 if_changed
    show mai back at figure_at(0.43, 0.87), wobble
    show dog sit at figure_at(0.72, 0.785), wobble
    ## A5-530  〔草案〕
    n "我们傍晚才往回走。麦仔把我们送到山顶，然后坐了下来，好像那里就是它世界的边界。" id A5_530

label proto_frag1:

    call start_day(20)
    scene bg dusk_classroom with dissolve
    play ambient cicadas volume 0.4 fadeout 2.0 fadein 2.0 if_changed
    ## F1-010  〔新增〕
    n "那之后，小麦每天放学都跟在我后面。我去打水，她也去打水；我改作业，她就趴在旁边的桌子上看。" id F1_010
    scene bg noon_classroom with dissolve
    play ambient cicadas volume 0.4 fadeout 2.0 fadein 2.0 if_changed
    show plums hand at figure_at(0.5, 0.545), wobble
    ## F1-101  〔新增〕
    n "有一天中午，我去吃饭，经过教室，看见小麦还坐在里面，手里拿着两个李子。" id F1_101
    ## F1-111  〔新增〕
    me "“怎么还不去吃饭？”" id F1_111
    ## F1-121  〔新增〕
    n "她把手里的李子举给我看。" id F1_121
    ## F1-131  〔新增〕
    mei "“吃这个。我刚摘的。”" id F1_131
    ## F1-141  〔新增〕
    me "“就这两个？”" id F1_141
    ## F1-151  〔新增〕
    n "她点点头，咬了一口。那时候我才知道，她有时中午就这样吃。" id F1_151
    ## F1-161  〔新增〕
    n "我问她在家吃什么。她说南瓜、土豆，都是自家种的。" id F1_161
    ## F1-171  〔新增〕
    n "“米饭呢？”我问。她摇摇头：“没钱买米。”" id F1_171
    ## F1-181  〔新增〕
    me "“走，今天跟老师一起吃。”" id F1_181
    ## F1-191  〔新增〕
    n "她拿着剩下的李子，跟我出了教室。" id F1_191
    scene bg bathroom with dissolve
    ## F1-012  〔新增〕
    n "那段时间，我们洗澡都借用村干部家的厕所。" id F1_012
    show hose at figure_at(0.5, 0.64), wobble
    play sound hose volume 0.6 fadein 0.3
    ## F1-014  〔新增〕
    n "说是洗澡，其实只是一根水管接在水龙头上。水忽冷忽热，忽大忽小，只够简单冲一冲。可我们还是很感激。" id F1_014
    ## F1-016  〔新增〕
    n "每次去，我都会带上小麦。我帮她举着水管，她弯下腰，把头发一点一点搓干净。" id F1_016
    ## F1-018  〔新增〕
    n "泡沫顺着她的卷发流下来，流进水泥地上的小沟里。洗完了，她甩甩头，水珠溅了我一身，她自己先笑了起来。" id F1_018
    scene bg dusk_classroom with dissolve
    show phone cracked at figure_at(0.5, 0.66), wobble
    ## F1-020  〔新增〕
    n "有一天，她把那部裂了屏的手机推到我面前。" id F1_020
    ## F1-030  〔新增〕
    mei "“[teacher_name]老师，你看。”" id F1_030
    ## F1-040  〔新增〕
    n "屏幕上是一张又一张的云。早上的，中午的，傍晚的。隔着那些裂痕，每一朵都像被切成了好几块。" id F1_040
    ## F1-050  〔新增〕
    mei "“这朵像麦仔。”" id F1_050
    ## F1-060  〔新增〕
    n "那是她第一次把手机里的照片翻给我看。" id F1_060

label proto_act6:

    call start_day(35)
    scene bg chapter_06 with dissolve
    stop ambient fadeout 2.0
    pause
    scene bg dusk_classroom with dissolve
    play ambient cicadas volume 0.4 fadeout 2.0 fadein 2.0 if_changed
    ## A6-K1 条件分支：camera  〔草案〕
    ## A6-K1a 【如果 camera = True】
    if camera:
        ## A6-010  〔草案〕
        n "又过了些日子，一天放学后，小麦说她妈妈在河对岸的玉米地里干活，问我想不想去拍她妈妈。" id A6_010
    ## A6-K1b 【如果 camera = False】
    elif not camera:
        ## A6-020  〔草案〕
        n "又过了些日子，一天放学后，小麦说她妈妈在河对岸的玉米地里干活，她要去帮忙，问我想不想一起。" id A6_020

    ## A6-030  〔草案〕
    mei "“[teacher_name]老师，你要一起去吗？”" id A6_030
    ## A6-040  〔草案〕
    me "“好呀。”" id A6_040
    scene bg goose_meadow with dissolve
    play ambient wind volume 0.5 fadeout 2.0 fadein 2.0 if_changed
    show geese flock at figure_at(0.638, 0.41), wobble(sway=1.5, bob=3, period=1.4)
    show goose single at figure_at(0.398, 0.504), wobble(sway=2, bob=2, period=1.1)
    ## A6-050  〔草案〕
    n "我们沿着一个小山坡走，拐过一个弯之后，右侧突然出现了一大片绿油油的平坦草地。一群大肥鹅在上面悠哉游哉地散步。" id A6_050
    ## A6-060  〔草案〕
    mei "“麦仔！”" id A6_060
    show dog run at figure_at(0.143, 0.718), wobble(sway=3, bob=6, period=0.5)
    ## A6-070  〔草案〕
    n "我回头，看到小麦没来得及拦住麦仔。" id A6_070
    play sound geese volume 0.6 fadein 0.3
    play audio bark volume 0.5 fadein 0.3
    ## A6-080  〔草案〕
    n "麦仔像一颗子弹一样连滚带爬地钻进草地，直奔鹅群而去。在灿烂的阳光下，一群大肥鹅在前面嘎嘎嘎地逃窜，一个个都张开天使似的翅膀顶着肚子往前跑。" id A6_080
    ## A6-090  〔草案〕
    n "而一只开心的大黄狗在后面不远不近地追逐。" id A6_090
    ## A6-K2 条件分支：camera  〔草案〕
    ## A6-K2a 【如果 camera = True】
    if camera:
        ## A6-C2 选择：geese_shot  〔新增〕
        menu (timer=5):
            ## A6-C2A
            "拍下这一刻。":
                $ geese_shot = True
                ## A6-100  〔草案〕
                inner_lens "幸好这一幕被拍下来了，好像在天堂一样美好的一幕。" id A6_100
            ## A6-C2B
            "只是看着。":
                pass

    ## A6-K2b 【如果 camera = False】不播放
    elif not camera:
        pass

    scene bg river_bend with dissolve
    play ambient stream volume 0.6 fadeout 2.0 fadein 2.0 if_changed
    stop sound fadeout 2.0
    ## A6-110  〔草案〕
    n "我们接着路过一条河流。水很浅，也很清，水底的石头看上去伸手就能摸到。" id A6_110
    play sound splash volume 0.7 fadein 0.3
    ## A6-120  〔草案〕
    n "走到河湾，河面忽然变宽，水变成了深深的一潭。她突然停下来，往水里扔了一颗石子。" id A6_120
    ## A6-130  〔草案〕
    mei "“[teacher_name]老师你知道吗？我三妹就是在这里没的。”" id A6_130
    ## A6-140  〔草案〕
    n "她说这句话的语气，就像在说“我们在这里洗衣服”。但那颗石头好像扔到了我心里，震惊之余，我手足无措。" id A6_140
    ## A6-150  〔草案〕
    inner_teacher "我该说点什么吗？还是抱抱她？" id A6_150
    ## A6-160  〔草案〕
    inner_visitor "这是她的私事。我此刻说什么都可能是错的。" id A6_160
    ## A6-K3 条件分支：camera  〔草案〕
    ## A6-K3a 【如果 camera = True】
    if camera:
        ## A6-170  〔草案〕
        inner_lens "她就站在妹妹溺水的地方。如果现在问她那天发生了什么并且拍下来，这会是整部片子的核心。" id A6_170
    ## A6-K3b 【如果 camera = False】不播放
    elif not camera:
        pass

    ## A6-C1 选择：trust／footage  〔草案〕
    menu:
        ## A6-C1A
        "什么也不说，陪她站一会儿。":
            $ trust += 1
            ## A6-180  〔草案〕
            n "我什么都没有说。我们在潭边站了一会儿，然后继续往前走。" id A6_180
            ## A6-190  〔草案〕
            n "走出去很远，她才又开口。" id A6_190
            ## A6-200  〔草案〕
            mei "“那天下了很大的雨。她一直没回来。”" id A6_200
            ## A6-210  〔草案〕
            mei "“第二天早上，去赶集的大爷们在河边看见了她。”" id A6_210
            ## A6-212  〔新增〕
            n "她说完，就不再说了。我也没有追问。" id A6_212
            ## A6-214  〔新增〕
            n "我想起刚才那颗石子沉下去的样子。水面合拢得那么快，好像什么都没有发生过。" id A6_214
        ## A6-C1B
        "问她当时发生了什么。":
            pass
            ## A6-220  〔草案〕
            me "“那天是怎么回事？”" id A6_220
            ## A6-230  〔草案〕
            n "她边走边抚摸着路边的野草。" id A6_230
            ## A6-240  〔草案〕
            mei "“那天夜里雨下的特别大，半夜了也没见她回来。我跑去跟妈说，三妹儿还没回来。但是她干农活太累，说等雨停了再去找，没说两句就又睡着了。”" id A6_240
            ## A6-250  〔草案〕
            mei "“等到第二天早上，去赶集的大爷们在河边看见她了，赶忙跑来我们家，我们才知道。”" id A6_250
            ## A6-260  〔草案〕
            n "然后她说：“我们走吧。”" id A6_260
            ## A6-262  〔新增〕
            inner_teacher "她跑去告诉妈妈了。那天夜里，一个孩子能做的，她都做了。" id A6_262
            ## A6-264  〔新增〕
            n "我张了张嘴，想说“这不是你的错”，又觉得这句话太轻了。最后，我只是跟上了她。" id A6_264
        ## A6-C1C
        "举起相机。" if camera:
            $ footage.append("river")
            ## A6-270  〔草案〕
            n "我几乎是下意识地举起了相机。" id A6_270
            ## A6-280  〔草案〕
            n "她看见镜头，沉默了一会。" id A6_280
            ## A6-290  〔草案〕
            mei "“那天夜里雨下的特别大，半夜了也没见她回来。”" id A6_290
            ## A6-300  〔草案〕
            n "“算了。”她说，转身往前走。" id A6_300
            ## A6-302  〔新增〕
            n "我放下相机。屏幕上，录制的红点还在一闪一闪。" id A6_302
            ## A6-304  〔新增〕
            n "我按了停止。那几秒钟的画面，我后来一次都没有删。" id A6_304

    $ sister_memory = True
    ## A6-306  〔新增〕
    n "往前走的路上，她又变回了那个蹦蹦跳跳的小麦，好像刚才什么都没有说过。" id A6_306
    ## A6-308  〔新增〕
    n "我却一直没缓过来。脚下的河水还是那么清，清得能看见底下每一颗石头。" id A6_308
    scene bg cornfield with dissolve
    play ambient wind volume 0.5 fadeout 2.0 fadein 2.0 if_changed
    ## A6-310  〔草案〕
    n "我们踩着一排石头过河。小麦一跳一跳地过去，看都不看脚下。我只能一块一块地挪。" id A6_310
    ## A6-320  〔草案〕
    n "河对岸是一片玉米地，这里的玉米长得快有两个我那么高，叶子已经开始发黄，把太阳遮得严严实实的。" id A6_320
    show mother at figure_at(0.62, 0.865), wobble
    ## A6-330  〔改稿〕
    n "小麦的妈妈在玉米地深处，弯着腰掰玉米。她直起身时，我看见了她的肚子，圆圆的，沉沉地坠在衬衫下面。" id A6_330
    ## A6-332  〔改稿〕
    n "她的脸被太阳晒成了深褐色，颧骨上有两块晒伤的红。眼角已经有了细纹，掰玉米的手指关节粗大，指缝里嵌着洗不掉的泥。" id A6_332
    ## A6-334  〔改稿〕
    n "她冲我们笑的时候，我才意识到，即使岁月和风霜细细地雕刻了她，她看起来大概也就三十出头，只比我在北京的表姐大几岁。" id A6_334
    ## A6-340  〔草案〕
    n "她一只手撑着后腰。" id A6_340
    ## A6-350  〔草案〕
    n "“[teacher_name]老师来了。”小麦说完，就自己去把掰下来的玉米抱到一起，没人叫她做。" id A6_350
    ## A6-355  〔改稿〕
    mom "“这女娃，天天揣着我的手机往学校跑。村头大爷要买玉米喂猪，打了一天都打不通。”" id A6_355
    ## A6-360  〔草案〕
    me "“小麦的爸爸呢？”" id A6_360
    ## A6-370  〔草案〕
    n "她往远处的土路上看了一眼。" id A6_370
    ## A6-380  〔草案〕
    mom "“他啊。过年回来过一趟，走了以后，电话就再没打通过。”" id A6_380
    ## A6-390  〔草案〕
    n "小麦的妈妈拍了拍肚子：" id A6_390
    ## A6-400  〔草案〕
    mom "“这个，等天凉了就生。”" id A6_400
    ## A6-410  〔草案〕
    mei "“妈说这次可能是五弟，”小麦说，“也可能是五妹。”" id A6_410
    ## A6-420  〔草案〕
    n "我站在田埂上，不知道手该往哪里放。" id A6_420
    hide mother
    show kids fight at figure_at(0.62, 0.815), wobble
    ## A6-430  〔草案〕
    n "此时，小麦的二妹和四弟突然从一旁的玉米丛里钻了出来。他们互相尖叫打闹着冲向一旁的草地，然后翻身滚进了半人高的草丛里。" id A6_430
    hide kids
    show sister lying at figure_at(0.60, 0.765), wobble(sway=0, bob=3, period=4.0)
    ## A6-440  〔草案〕
    n "二妹从草丛里爬起来，伸出脑袋看了看我们，见没什么事发生，又安心地翻了个身躺进草丛里了。" id A6_440
    hide sister
    ## A6-450  〔草案〕
    n "我想起了小麦家的院子里那一地去年的玉米粒，无法想象那是多少个日夜的枯燥劳作。这个怀着孩子的女人就这样用双手为无数根玉米秆接生，度过一个又一个秋。" id A6_450
    ## A6-460  〔草案〕
    n "我想，这些玉米大概都是大山的孩子。大山沉睡的时候，它们就扯过草地当被子；大山震怒的时候，它们就被咆哮的雨水又卷回了大山的肚子里。" id A6_460
    ## A6-470  〔草案〕
    n "春夏秋冬，孕育麦子，只需要季度之长。等到收获的季节时，有的麦粒长得很好，有的麦粒却没有。" id A6_470
    ## A6-480  〔草案〕
    n "新的玉米已经成熟了。" id A6_480
    ## A6-490  〔草案〕
    n "我分不清，这种生命的来去更迭，是一种禅意，还是一种麻木？" id A6_490

label proto_frag2:

    call start_day(45)
    scene bg dusk_classroom with dissolve
    play ambient cicadas volume 0.4 fadeout 2.0 fadein 2.0 if_changed
    ## F2-010  〔新增〕
    n "剩下的日子，一天比一天过得快。" id F2_010
    ## F2-101  〔新增〕
    n "有一天课间，我问起班里的孩子，小学毕业以后，准备去哪里读初中。" id F2_101
    ## F2-111  〔新增〕
    n "村里没有初中。只有一两个孩子说，去镇上的学校看看。" id F2_111
    ## F2-121  〔新增〕
    n "其余的支支吾吾，有的说还不知道。我没听出什么明确的打算。" id F2_121
    ## F2-131  〔新增〕
    n "我差一点就叫到了小麦的名字。" id F2_131
    ## F2-141  〔新增〕
    n "我怕她说，要回家帮妈妈干农活。所以我不敢问她。" id F2_141
    ## F2-012  〔新增〕
    n "另一天课间，我发现小麦旁边的座位上有一个女孩。" id F2_012
    show phone cracked at figure_at(0.5, 0.66), wobble
    ## F2-K1 条件分支：braid_upset  〔新增〕
    ## F2-K1a 【如果编辫子时两个女生等到了】
    if "girls" not in braid_upset:
        $ choice_echo()
        ## F2-014  〔新增〕
        n "是那天在旁边等着编辫子的女生。两个人头凑在一起叽叽喳喳的，在看那部屏幕裂了的手机里的照片。" id F2_014
    ## F2-K1b 【如果编辫子时两个女生难过地走开了】
    elif "girls" in braid_upset:
        $ choice_echo()
        ## F2-015  〔新增〕
        n "是那天没等到我给她编辫子的女生。两个人头凑在一起，在看那部屏幕裂了的手机。" id F2_015

    ## F2-016  〔新增〕
    n "我不知道是从哪一天开始的。我站在讲台边看了一会儿，没有过去打扰。" id F2_016
    scene bg shop with dissolve
    ## F2-020  〔新增〕
    n "有天傍晚，我们去小卖部买冰棍。门口小木椅上的大叔们正在说话。" id F2_020
    ## F2-030  〔新增〕
    villager "“……又咬死一只。哪家的狗嘛，也不拴。”" id F2_030
    ## F2-040  〔新增〕
    n "我没听清是谁家的狗。不过这在乡村里并不是什么新鲜事。冰棍化得很快，我舔了一口，就跟着大家往回走了。" id F2_040

label proto_act7:

    call start_day(53)
    scene bg chapter_07 with dissolve
    stop ambient fadeout 2.0
    pause
    scene bg rain_classroom with dissolve
    play ambient rain_roof volume 0.8 fadeout 2.0 fadein 2.0 if_changed
    ## A7-010  〔草案〕
    n "那天夜里，暴雨从山那边压了过来。" id A7_010
    ## A7-020  〔草案〕
    n "雨点砸在教室的铁皮屋顶上。雨下得那么大，屋里却还是闷得透不过气。" id A7_020
    play audio knock volume 0.8 fadein 0.3
    ## A7-030  〔草案〕
    n "有人在敲窗户。" id A7_030
    play sound thunder volume 0.6 fadein 0.3
    ## A7-040  〔改稿〕
    n "是小麦。浑身湿透，泥一直糊到膝盖，辫子贴在脖子上。一道闪电亮起，我看见辫尾绑着一根小黄鸭发绳。" id A7_040
    ## A7-042  〔改稿〕
    n "是编辫子那天，我从手腕上褪下来给她的那根。已经旧得发白了。" id A7_042
    ## A7-044  〔改稿〕
    n "她的手按在玻璃上。" id A7_044
    ## A7-046  〔改稿〕
    mei "“[teacher_name]老师，求求你帮帮我。”" id A7_046
    ## A7-050  〔草案〕
    mei "“麦仔不见了。它每天晚上都在山顶等我，今天没有。”" id A7_050
    ## A7-060  〔草案〕
    n "她是一个人，摸黑，冒着雨翻山过来的。" id A7_060
    ## A7-070  〔草案〕
    mei "“我妈说狗会自己回来，让我快去睡觉。”" id A7_070
    ## A7-080  〔草案〕
    inner_teacher "她一个人摸黑翻山过来的。她一定很担心麦仔。" id A7_080
    ## A7-090  〔草案〕
    inner_visitor "外面雨很大，山路全是泥。连她妈妈都说再等等，先让她进来躲躲雨？" id A7_090
    ## A7-C1 选择：trust  〔草案〕
    menu:
        ## A7-C1A
        "“等雨停了再去找吧，现在太危险了。”":
            $ trust -= 2
            ## A7-100  〔草案〕
            n "她的脸色变了。" id A7_100
            ## A7-110  〔草案〕
            mei "“那天妈妈也是这么说的。”她的声音很轻，“等雨停了再去。”" id A7_110
            ## A7-120  〔草案〕
            n "我还没来得及开口，她已经转身冲回了雨里。我抓起手电筒追了出去。" id A7_120
        ## A7-C1B
        "“我们现在就去。”":
            pass
            ## A7-130  〔草案〕
            n "其他老师已经在穿鞋了。有人把手电筒分给大家。小麦攥着我的袖子，跟我们一起走进雨里。" id A7_130

    scene bg rain_night with dissolve
    play ambient storm volume 0.7 fadeout 2.0 fadein 2.0 if_changed
    ## A7-140  〔草案〕
    n "我们分头在村子里找，一遍遍喊它的名字。雨声把我们的声音吞掉了。" id A7_140
    scene bg chicken_coop with dissolve
    play audio bark volume 0.35 fadein 0.3
    ## A7-150  〔草案〕
    n "快到村边时，我听见一户人家后面有男人在吼。然后是一声狗叫，又尖又短。" id A7_150
    ## A7-160  〔草案〕
    n "我拐过鸡舍的墙角。" id A7_160
    show uncle fierce at figure_at(0.68, 1.0)
    ## A7-170  〔草案〕
    n "泥里散着羽毛。一只鸡躺在那里，不动了。一个男人手里握着一根棍子，另一个举着手电筒。他们中间的地上，麦仔侧躺着，肚子起伏得很快。" id A7_170
    ## A7-180  〔草案〕
    n "握棍子的人，是小卖部门口坐小木椅、扇蒲扇的大叔之一。" id A7_180
    ## A7-K1 条件分支：greeted_villagers  〔草案〕
    ## A7-K1a 【如果第二幕打过招呼】
    if greeted_villagers:
        $ choice_echo()
        ## A7-185  〔改稿〕
        n "我也认出了他。是那天夜里，把蚊香搁在窗台上的大叔。" id A7_185
        show uncle surprised at figure_at(0.68, 1.0)
        ## A7-190  〔建议〕
        n "他认出了我，愣了一下。" id A7_190
        show uncle tired at figure_at(0.68, 1.0)
        ## A7-200  〔建议〕
        villager "“老师，这事你别管。”" id A7_200
        ## A7-210  〔建议〕
        n "他的声音不凶，倒像是很累。" id A7_210
    ## A7-K1b 【如果第二幕没打招呼】
    elif not greeted_villagers:
        $ choice_echo()
        ## A7-215  〔改稿〕
        n "我不认识他。也许那天夜里窗外的人影就是他，我不知道。" id A7_215
        ## A7-220  〔建议〕
        n "他眯着眼看了看我的手电筒光。" id A7_220
        ## A7-230  〔建议〕
        villager "“学校的？别多管闲事。”" id A7_230

    ## A7-270  〔草案〕
    n "他握着棍子的手在抖。不知道是因为冷，还是因为别的。" id A7_270
    ## A7-280  〔草案〕
    n "其他老师还在后面，要几分钟才能赶到。" id A7_280
    ## A7-310  〔草案〕
    inner_teacher "再不拦住他，它会死的。" id A7_310
    ## A7-320  〔草案〕
    inner_visitor "这是他的鸡，他们的村子，他们的规矩。我过几天就走了，别在这时候惹上麻烦。" id A7_320
    ## A7-K2 条件分支：camera  〔草案〕
    ## A7-K2a 【如果 camera = True】
    if camera:
        ## A7-330  〔草案〕
        inner_lens "你确定你真的要错过这段画面吗？" id A7_330
    ## A7-K2b 【如果 camera = False】不播放
    elif not camera:
        pass

    ## A7-C2 选择：action  〔改稿〕
    menu (timer=9):
        ## A7-C2P
        "打电话报警。":
            $ called_police = True
            ## A7-332  〔改稿〕
            n "我掏出口袋里泡了雨水的手机，使劲甩了甩，屏幕上只有一格信号，时有时无。" id A7_332
            ## A7-334  〔改稿〕
            n "我想起来时的路：从最近的镇上过来要翻好几个山头，村里根本没有派出所。这么大的雨，就算打通了，谁会为了一条狗的纠纷冒着暴雨翻山越岭过来？" id A7_334
            ## A7-336  〔改稿〕
            n "就在我低头看手机的这几秒里，棍子落了下去。麦仔叫了一声，又尖又短。" id A7_336
        ## A7-C2A
        "等待其他老师汇合，等大家一起上前。":
            $ action = "wait"
        ## A7-C2B
        "等不了了，立刻冲上前拦住他。":
            $ action = "rush"
        ## A7-C2C
        "站在原地，不插手。":
            $ action = "stay"

    ## A7-K3 条件分支：called_police  〔改稿〕
    ## A7-K3a 【如果报警失败】
    if called_police and action is None:
        ## A7-C4 选择：action  〔改稿〕
        menu (timer=9):
            ## A7-C4A
            "等待其他老师汇合，等大家一起上前。":
                $ action = "wait"
            ## A7-C4B
            "等不了了，立刻冲上前拦住他。":
                $ action = "rush"
            ## A7-C4C
            "站在原地，不插手。":
                $ action = "stay"

    ## A7-K3b 【其他】不播放
    elif not (called_police and action is None):
        pass

    ## A7-K4 条件分支：action  〔改稿〕
    ## A7-K4a 【如果等其他老师】
    if action == "wait":
        $ trust += 1; dog = "lame"
        ## A7-340  〔草案〕
        n "我朝来的方向大喊，一遍又一遍。" id A7_340
        ## A7-350  〔草案〕
        n "等待的那几分钟里，我没有去看发生了什么。但我听见了。" id A7_350
        ## A7-W010  〔改稿〕
        n "手电筒的光一束束从雨里晃过来。其他老师赶到了，我们一起站到了他和麦仔中间。" id A7_W010
        show uncle tired at figure_at(0.68, 1.0)
        ## A7-W020  〔改稿〕
        n "他看了看我们这一排人，手里的棍子放低了，人却站得更直了。" id A7_W020
        ## A7-W030  〔改稿〕
        villager "“第三只了。”他抹了一把脸上的雨，“去她家说了两回，说拴，拴了吗？”" id A7_W030
        ## A7-CW1 选择：attitude  〔改稿〕
        menu (timer=9):
            ## A7-CW1A
            "赔他鸡钱。":
                $ paid = True
                ## A7-W110  〔改稿〕
                n "有个老师掏出钱包，我们几个凑了凑，凑出一沓皱巴巴的钱，递了过去。" id A7_W110
                ## A7-W120  〔改稿〕
                n "他没有接，看看那沓钱，又看看我们。" id A7_W120
                show uncle fierce at figure_at(0.68, 1.0)
                ## A7-W130  〔改稿〕
                villager "“你们这是啥意思？拿钱来打发我？”" id A7_W130
            ## A7-CW1B
            "先听他说。":
                $ listened = True
                ## A7-W140  〔改稿〕
                me "“叔叔，您想怎么办？”" id A7_W140
                ## A7-KW1 条件分支：greeted_villagers  〔改稿〕
                ## A7-KW1a 【如果第二幕打过招呼】
                if greeted_villagers:
                    $ choice_echo()
                    $ attitude += 2
                    show uncle surprised at figure_at(0.68, 1.0)
                    ## A7-W150  〔改稿〕
                    n "他愣了一下，好像没想到会有人问他这个。" id A7_W150
                    show uncle tired at figure_at(0.68, 1.0)
                    ## A7-W160  〔改稿〕
                    villager "“那几个蛋是留给我孙子的。他爸妈在外面打工，屋头一个月吃不上一回肉。”" id A7_W160
                    ## A7-W170  〔改稿〕
                    villager "“狗咬过鸡，尝过血，改不了的。我不是要跟哪个过不去。”" id A7_W170
                ## A7-KW1b 【如果第二幕没打招呼】
                elif not greeted_villagers:
                    $ choice_echo()
                    show uncle fierce at figure_at(0.68, 1.0)
                    ## A7-W180  〔改稿〕
                    villager "“我想咋办？我想咋办你们管得了？”他别过脸，“跟你们说这些有啥用。”" id A7_W180

            ## A7-CW1C
            "说我已经报警了。" if called_police:
                $ bluffed = True; attitude -= 2
                ## A7-W190  〔改稿〕
                me "“我已经报警了。”" id A7_W190
                ## A7-W192  〔改稿〕
                n "身后的老师们愣住了，互相看了一眼。有人小声问：“你啥时候打的？”" id A7_W192
                ## A7-W194  〔改稿〕
                n "他看看我，又看看她们，一下就明白了。" id A7_W194
                show uncle fierce at figure_at(0.68, 1.0)
                ## A7-W196  〔改稿〕
                villager "“报警？”他冷笑了一声，“你们城里来的，就会这一套。”" id A7_W196
            ## A7-CW1D
            "不说话。":
                pass
                show uncle fierce at figure_at(0.68, 1.0)
                ## A7-W230  〔改稿〕
                villager "“不说话？”" id A7_W230

        show uncle tired at figure_at(0.68, 1.0)
        ## A7-W240  〔改稿〕
        villager "“你们这些老师，过几天就全都走了。这狗明天再来，你们哪个在？”" id A7_W240
        ## A7-W250  〔改稿〕
        n "没有人说话。雨声很大。" id A7_W250
        ## A7-CW2 选择：attitude  〔改稿〕
        menu (timer=9):
            ## A7-CW2A
            "赔他鸡钱。" if not paid:
                $ paid = True
                ## A7-KW2 条件分支：listened  〔改稿〕
                ## A7-KW2a 【如果听他说过】
                if listened:
                    $ attitude += 1
                    show uncle sigh at figure_at(0.68, 1.0)
                    ## A7-W310  〔改稿〕
                    n "我们把凑好的钱递过去。这一次，他看了很久，接了。" id A7_W310
                    ## A7-W320  〔改稿〕
                    villager "“钱不是这个事。”他把钱揣进兜里，“把狗拴好。”" id A7_W320
                ## A7-KW2b 【如果没听他说过】
                elif not listened:
                    ## A7-W330  〔改稿〕
                    n "有个老师掏出钱包，我们几个凑了凑，凑出一沓皱巴巴的钱，递了过去。" id A7_W330
                    ## A7-W332  〔改稿〕
                    n "他没有接，看看那沓钱，又看看我们。" id A7_W332
                    show uncle fierce at figure_at(0.68, 1.0)
                    ## A7-W334  〔改稿〕
                    villager "“你们这是啥意思？拿钱来打发我？”" id A7_W334

            ## A7-CW2B
            "先听他说。" if not listened:
                $ listened = True
                ## A7-W340  〔改稿〕
                me "“叔叔，您想怎么办？”" id A7_W340
                ## A7-KW3 条件分支：greeted_villagers  〔改稿〕
                ## A7-KW3a 【如果第二幕打过招呼】
                if greeted_villagers:
                    $ choice_echo()
                    $ attitude += 2
                    show uncle surprised at figure_at(0.68, 1.0)
                    ## A7-W350  〔改稿〕
                    n "他愣了一下，好像没想到会有人问他这个。" id A7_W350
                    show uncle tired at figure_at(0.68, 1.0)
                    ## A7-W360  〔改稿〕
                    villager "“那几个蛋是留给我孙子的。他爸妈在外面打工，屋头一个月吃不上一回肉。”" id A7_W360
                    ## A7-W370  〔改稿〕
                    villager "“狗咬过鸡，尝过血，改不了的。我不是要跟哪个过不去。”" id A7_W370
                ## A7-KW3b 【如果第二幕没打招呼】
                elif not greeted_villagers:
                    $ choice_echo()
                    show uncle fierce at figure_at(0.68, 1.0)
                    ## A7-W380  〔改稿〕
                    villager "“我想咋办？我想咋办你们管得了？”他别过脸，“跟你们说这些有啥用。”" id A7_W380

            ## A7-CW2C
            "说我已经报警了。" if called_police and not bluffed:
                $ bluffed = True; attitude -= 2
                ## A7-W390  〔改稿〕
                me "“我已经报警了。”" id A7_W390
                ## A7-W392  〔改稿〕
                n "身后的老师们愣住了，互相看了一眼。有人小声问：“你啥时候打的？”" id A7_W392
                ## A7-W394  〔改稿〕
                n "他看看我，又看看她们，一下就明白了。" id A7_W394
                show uncle fierce at figure_at(0.68, 1.0)
                ## A7-W396  〔改稿〕
                villager "“报警？”他冷笑了一声，“你们城里来的，就会这一套。”" id A7_W396
            ## A7-CW2D
            "承诺会让她家把狗拴好。":
                pass
                ## A7-KW4 条件分支：listened  〔改稿〕
                ## A7-KW4a 【如果听他说过】
                if listened:
                    $ attitude += 1
                    ## A7-W430  〔改稿〕
                    me "“我们明天就去她家，跟她妈妈说，帮着把狗拴好。走之前，我们每天都会去看一眼。”" id A7_W430
                    show uncle tired at figure_at(0.68, 1.0)
                    ## A7-W440  〔改稿〕
                    n "他盯着我看了一会儿。" id A7_W440
                    ## A7-W450  〔改稿〕
                    villager "“你们说的。”" id A7_W450
                ## A7-KW4b 【如果没听他说过】
                elif not listened:
                    ## A7-W460  〔改稿〕
                    me "“我们会去跟她家说的。”" id A7_W460
                    show uncle sigh at figure_at(0.68, 1.0)
                    ## A7-W470  〔改稿〕
                    villager "“你们？说了又咋样。去年那拨老师也说要给村里修个篮球架。”" id A7_W470

            ## A7-CW2E
            "讲小麦三妹的事。" if sister_memory:
                $ told_secret = True
                ## A7-W480  〔改稿〕
                me "“小麦的三妹……就是在那条河里没的。这条狗是她的……”" id A7_W480
                ## A7-W490  〔改稿〕
                n "我说到一半，感觉到身边几个老师都转过头来看我。她们不知道这件事。" id A7_W490
                show uncle tired at figure_at(0.68, 1.0)
                ## A7-W500  〔改稿〕
                n "大叔沉默了一会儿。" id A7_W500
                ## A7-W510  〔改稿〕
                villager "“村里哪个不晓得她家的事。”" id A7_W510
                ## A7-W520  〔改稿〕
                n "他的声音低了下去，可手里的棍子没有放下。" id A7_W520
            ## A7-CW2F
            "不说话，站着不走。":
                pass
                ## A7-W530  〔改稿〕
                n "我们谁都没有动。一排人站在雨里，手电筒的光照着地上的泥和羽毛。" id A7_W530
                show uncle tired at figure_at(0.68, 1.0)
                ## A7-W540  〔改稿〕
                n "僵了很久，他先移开了目光。" id A7_W540

        ## A7-KW9 条件分支：attitude  〔改稿〕
        ## A7-KW9a 【如果大叔的态度 ≥ 1】
        if attitude >= 1:
            $ trust += 1; village = "intact"
            show uncle sigh at figure_at(0.68, 1.0)
            ## A7-W610  〔改稿〕
            n "他把棍子靠在鸡舍墙上。" id A7_W610
            ## A7-W620  〔改稿〕
            villager "“这回就算了。”" id A7_W620
        ## A7-KW9b 【如果大叔的态度 ≤ 0】
        elif attitude <= 0:
            $ village = "cold"
            show uncle fierce at figure_at(0.68, 1.0)
            ## A7-W630  〔改稿〕
            n "他把棍子扔在地上，转身走了，一句话也没留下。" id A7_W630
            hide uncle

    ## A7-K4b 【如果立刻冲上去】
    elif action == "rush":
        $ trust += 1; dog = "fine"
        ## A7-400  〔草案〕
        n "我冲上去，挡在了麦仔前面。" id A7_400
        ## A7-R010  〔改稿〕
        n "他手里的棍子还举着，雨水顺着棍子一滴一滴往下掉。我的腿在发抖。" id A7_R010
        ## A7-R020  〔改稿〕
        villager "“让开。”" id A7_R020
        ## A7-R030  〔改稿〕
        villager "“第三只了。去她家说了两回，说拴，拴了吗？”" id A7_R030
        ## A7-CR1 选择：attitude  〔改稿〕
        menu (timer=9):
            ## A7-CR1A
            "赔他鸡钱。":
                $ paid = True
                ## A7-R110  〔改稿〕
                n "我在口袋里摸了半天，摸出几张泡湿的零钱，皱成一团。" id A7_R110
                ## A7-R112  〔改稿〕
                me "“鸡……多少钱，我赔。”" id A7_R112
                ## A7-R114  〔改稿〕
                n "他低头看着我手里那几张钱，没有接。" id A7_R114
                show uncle sigh at figure_at(0.68, 1.0)
                ## A7-R116  〔改稿〕
                villager "“你这点钱，够干啥？”" id A7_R116
            ## A7-CR1B
            "先听他说。":
                $ listened = True
                ## A7-R150  〔改稿〕
                me "“叔叔……您想怎么办？”" id A7_R150
                ## A7-KR1 条件分支：greeted_villagers  〔改稿〕
                ## A7-KR1a 【如果第二幕打过招呼】
                if greeted_villagers:
                    $ choice_echo()
                    $ attitude += 2
                    show uncle surprised at figure_at(0.68, 1.0)
                    ## A7-R160  〔改稿〕
                    n "他举着棍子的手停住了。过了好一会儿，他才开口。" id A7_R160
                    show uncle tired at figure_at(0.68, 1.0)
                    ## A7-R170  〔改稿〕
                    villager "“我儿子儿媳在外头打工，一年回来一趟。娃娃跟着我，那几个蛋是留给他的。”" id A7_R170
                    ## A7-R180  〔改稿〕
                    villager "“我也不想打狗。可它今天不死，明天还来。”" id A7_R180
                ## A7-KR1b 【如果第二幕没打招呼】
                elif not greeted_villagers:
                    $ choice_echo()
                    show uncle fierce at figure_at(0.68, 1.0)
                    ## A7-R190  〔改稿〕
                    villager "“你一个学校的女娃娃，问这些做啥？”他把棍子握得更紧了，“让开。”" id A7_R190

            ## A7-CR1C
            "说我已经报警了。" if called_police:
                $ bluffed = True; attitude -= 2
                ## A7-R200  〔改稿〕
                me "“我……我已经报警了。”" id A7_R200
                show uncle fierce at figure_at(0.68, 1.0)
                ## A7-R202  〔改稿〕
                n "他看着我，看了很久。然后笑了一声。" id A7_R202
                ## A7-R204  〔改稿〕
                villager "“警察？翻三座山来管一条狗？”" id A7_R204
                ## A7-R206  〔改稿〕
                n "他往前走了一步。" id A7_R206
            ## A7-CR1D
            "不说话。":
                pass
                show uncle fierce at figure_at(0.68, 1.0)
                ## A7-R240  〔改稿〕
                villager "“不说话？”" id A7_R240

        show uncle tired at figure_at(0.68, 1.0)
        ## A7-R250  〔改稿〕
        villager "“你呢？你过几天也走了。它明天再来，你在吗？”" id A7_R250
        ## A7-CR2 选择：attitude  〔改稿〕
        menu (timer=9):
            ## A7-CR2A
            "赔他鸡钱。" if not paid:
                $ paid = True
                ## A7-KR2 条件分支：listened  〔改稿〕
                ## A7-KR2a 【如果听他说过】
                if listened:
                    $ attitude += 1
                    show uncle sigh at figure_at(0.68, 1.0)
                    ## A7-R310  〔改稿〕
                    n "我把那几张湿钱又递过去。他看了一会儿，叹了口气，接了。" id A7_R310
                    ## A7-R320  〔改稿〕
                    villager "“钱不是这个事。把狗拴好。”" id A7_R320
                ## A7-KR2b 【如果没听他说过】
                elif not listened:
                    ## A7-R330  〔改稿〕
                    n "我在口袋里摸了半天，摸出几张泡湿的零钱，皱成一团。" id A7_R330
                    ## A7-R332  〔改稿〕
                    me "“鸡……多少钱，我赔。”" id A7_R332
                    ## A7-R334  〔改稿〕
                    n "他低头看着我手里那几张钱，没有接。" id A7_R334
                    show uncle sigh at figure_at(0.68, 1.0)
                    ## A7-R336  〔改稿〕
                    villager "“你这点钱，够干啥？”" id A7_R336

            ## A7-CR2B
            "先听他说。" if not listened:
                $ listened = True
                ## A7-R340  〔改稿〕
                me "“叔叔……您想怎么办？”" id A7_R340
                ## A7-KR3 条件分支：greeted_villagers  〔改稿〕
                ## A7-KR3a 【如果第二幕打过招呼】
                if greeted_villagers:
                    $ choice_echo()
                    $ attitude += 2
                    show uncle surprised at figure_at(0.68, 1.0)
                    ## A7-R350  〔改稿〕
                    n "他举着棍子的手停住了。过了好一会儿，他才开口。" id A7_R350
                    show uncle tired at figure_at(0.68, 1.0)
                    ## A7-R360  〔改稿〕
                    villager "“我儿子儿媳在外头打工，一年回来一趟。娃娃跟着我，那几个蛋是留给他的。”" id A7_R360
                    ## A7-R370  〔改稿〕
                    villager "“我也不想打狗。可它今天不死，明天还来。”" id A7_R370
                ## A7-KR3b 【如果第二幕没打招呼】
                elif not greeted_villagers:
                    $ choice_echo()
                    show uncle fierce at figure_at(0.68, 1.0)
                    ## A7-R380  〔改稿〕
                    villager "“你一个学校的女娃娃，问这些做啥？”他把棍子握得更紧了，“让开。”" id A7_R380

            ## A7-CR2C
            "说我已经报警了。" if called_police and not bluffed:
                $ bluffed = True; attitude -= 2
                ## A7-R390  〔改稿〕
                me "“我……我已经报警了。”" id A7_R390
                show uncle fierce at figure_at(0.68, 1.0)
                ## A7-R392  〔改稿〕
                n "他看着我，看了很久。然后笑了一声。" id A7_R392
                ## A7-R394  〔改稿〕
                villager "“警察？翻三座山来管一条狗？”" id A7_R394
                ## A7-R396  〔改稿〕
                n "他往前走了一步。" id A7_R396
            ## A7-CR2D
            "承诺会让她家把狗拴好。":
                pass
                ## A7-KR4 条件分支：listened  〔改稿〕
                ## A7-KR4a 【如果听他说过】
                if listened:
                    $ attitude += 1
                    ## A7-R430  〔改稿〕
                    me "“我会看着它的。明天我就去她家，帮着搭个狗窝，把它拴上。”" id A7_R430
                    show uncle surprised at figure_at(0.68, 1.0)
                    ## A7-R440  〔改稿〕
                    villager "“你一个女娃娃，说话算数？”" id A7_R440
                    ## A7-R450  〔改稿〕
                    me "“算数。”" id A7_R450
                ## A7-KR4b 【如果没听他说过】
                elif not listened:
                    ## A7-R460  〔改稿〕
                    me "“我会看着它的。”" id A7_R460
                    show uncle sigh at figure_at(0.68, 1.0)
                    ## A7-R470  〔改稿〕
                    villager "“你一个女娃娃，看得住？”" id A7_R470

            ## A7-CR2E
            "讲小麦三妹的事。" if sister_memory:
                pass
                ## A7-R480  〔改稿〕
                me "“小麦的三妹就是在河里没的。这条狗……是她的。”" id A7_R480
                show uncle surprised at figure_at(0.68, 1.0)
                ## A7-R490  〔改稿〕
                n "他的手顿了一下。" id A7_R490
                show uncle tired at figure_at(0.68, 1.0)
                ## A7-R500  〔改稿〕
                villager "“村里哪个不晓得她家的事。”" id A7_R500
                ## A7-R510  〔改稿〕
                n "他别过脸去，看着地上那只死鸡。" id A7_R510
            ## A7-CR2F
            "不说话，站着不走。":
                pass
                ## A7-R530  〔改稿〕
                n "我什么都没说，也没有让开。雨从头发上流进眼睛里，我没有擦。" id A7_R530
                show uncle fierce at figure_at(0.68, 1.0)
                ## A7-R540  〔改稿〕
                n "他盯着我，我也盯着他。" id A7_R540

        ## A7-KR9 条件分支：attitude  〔改稿〕
        ## A7-KR9a 【如果大叔的态度 ≥ 1】
        if attitude >= 1:
            $ trust += 1; village = "intact"
            show uncle sigh at figure_at(0.68, 1.0)
            ## A7-R610  〔改稿〕
            n "他把棍子扔进泥里。" id A7_R610
            ## A7-R620  〔改稿〕
            villager "“拴好它。下回我就不管你在不在了。”" id A7_R620
            ## A7-450  〔草案〕
            n "他转身走了，另一个人跟在后面。" id A7_450
            hide uncle
        ## A7-KR9b 【如果大叔的态度 ≤ 0】
        elif attitude <= 0:
            $ village = "cold"
            show uncle sigh at figure_at(0.68, 1.0)
            ## A7-420  〔草案〕
            villager "“你们城里的这些小姑娘就是容易心软。心软能当饭吃吗？”" id A7_420
            ## A7-430  〔草案〕
            n "然后，他把棍子扔进泥里。" id A7_430
            show uncle tired at figure_at(0.68, 1.0)
            ## A7-440  〔草案〕
            villager "“你能看住它一天，看不住一辈子。”" id A7_440
            ## A7-R640  〔改稿〕
            n "他转身走了，另一个人跟在后面。" id A7_R640
            hide uncle

    ## A7-K4c 【如果不插手】
    elif action == "stay":
        $ dog = "dead"; village = "intact"
        ## A7-480  〔草案〕
        n "我站在鸡舍墙角的黑暗里，没有动。" id A7_480
        ## A7-490  〔草案〕
        n "雨声盖住了大部分声音。" id A7_490
        show uncle tired at figure_at(0.68, 1.0)
        ## A7-500  〔草案〕
        n "结束以后，他从我身边走过，停了一下，像是想说什么，最后什么也没说。" id A7_500
        hide uncle
        ## A7-510  〔草案〕
        n "他没有回头看那条狗。我也没有。我像是被钉在了原地。" id A7_510
        scene bg rain_night with dissolve
        ## A7-520  〔草案〕
        n "我冒着雨走回小麦和其他老师等着的地方。她看见我，跑了过来。" id A7_520
        ## A7-C3 选择：lie  〔草案〕
        menu:
            ## A7-530  〔草案〕
            mei "“找到了吗？”" id A7_530
            ## A7-C3A
            "告诉她真相。":
                $ trust += 1
                ## A7-540  〔草案〕
                n "我告诉了她。" id A7_540
                ## A7-550  〔草案〕
                n "她没有马上哭。她问：" id A7_550
                ## A7-560  〔草案〕
                mei "“它疼吗？”" id A7_560
                ## A7-570  〔草案〕
                n "我不知道该怎么回答，所以这一句，我也说了实话。" id A7_570
                ## A7-580  〔草案〕
                n "然后她哭了。我陪着她，一直到雨停。" id A7_580
            ## A7-C3B
            "告诉她麦仔可能只是跑远了。":
                $ lie = True
                ## A7-590  〔草案〕
                me "“没找到。可能跑到别的地方去了。狗会自己回来的。”" id A7_590
                ## A7-600  〔草案〕
                n "说出口我才发现，这和她妈妈说的话一模一样。" id A7_600
                ## A7-610  〔草案〕
                n "她点点头。" id A7_610
                ## A7-620  〔草案〕
                mei "“它每次都会回来的。”她说，朝山的方向望过去。" id A7_620


    ## A7-K5 条件分支：action  〔新增〕
    ## A7-K5a 【如果救下了麦仔】
    if action != "stay":
        hide uncle
        ## A7-700  〔新增〕
        n "小麦被一位老师留在小卖部的屋檐下等着。她一看见手电筒的光，就冲进了雨里。" id A7_700
        ## A7-K6 条件分支：dog  〔新增〕
        ## A7-K6a 【如果麦仔完好】
        if dog == "fine":
            show dog hurt at figure_at(0.5, 1.08)
            ## A7-460  〔草案〕
            n "我把麦仔抱回小麦身边。它很沉，一直在发抖，但它一直乖乖地躺在我怀里。" id A7_460
            ## A7-710  〔新增〕
            n "麦仔认出了小麦，尾巴在雨里一下一下地拍着她的胳膊。" id A7_710
        ## A7-K6b 【如果麦仔断了腿】
        elif dog == "lame":
            show dog hurt at figure_at(0.5, 1.08)
            ## A7-720  〔新增〕
            n "麦仔是被我们用一件雨衣兜着抬回来的。它的一条后腿软软地垂着，一碰就呜咽一声。" id A7_720
            ## A7-730  〔新增〕
            n "它认出了小麦，想站起来，后腿一软，又趴了下去。最后，它只是把头搁在了她的膝盖上。" id A7_730

        ## A7-740  〔新增〕
        n "小麦跪在泥里，把脸埋进麦仔湿透的毛里，很久都没有抬头。" id A7_740
        ## A7-750  〔新增〕
        mei "“我就知道你会回来的。”" id A7_750
        ## A7-760  〔新增〕
        n "她抬起头看着我。雨水顺着她的脸往下流，我分不清哪些是雨。" id A7_760
        ## A7-770  〔新增〕
        mei "“谢谢你，[teacher_name]老师。”" id A7_770
        ## A7-780  〔新增〕
        n "她说得很轻，好像怕声音大了，麦仔又会不见。" id A7_780
        ## A7-K7 条件分支：dog  〔新增〕
        ## A7-K7a 【如果麦仔断了腿】
        if dog == "lame":
            ## A7-790  〔新增〕
            mei "“它的腿……”" id A7_790
            ## A7-800  〔新增〕
            me "“会好的。”" id A7_800
            ## A7-810  〔新增〕
            n "我不知道会不会好。可那天晚上，我只能这么说。" id A7_810
            ## A7-380  〔草案〕
            n "麦仔活了下来。它的一条后腿断了，再也不能像以前那样一溜烟地冲上山顶。" id A7_380
        ## A7-K7b 【如果麦仔完好】不播放
        elif dog == "fine":
            pass

    ## A7-K5b 【如果不插手】不播放（不插手分支有自己的回去的戏）
    elif action == "stay":
        pass

    ## A7-K8 条件分支：village  〔新增〕
    ## A7-K8a 【如果救下麦仔，村子态度 intact】
    if action != "stay" and village == "intact":
        $ choice_echo()
        ## A7-390  〔草案〕
        n "第二天在路上碰见，大叔朝我点了点头。不算友善，但他点了头。" id A7_390
    ## A7-K8b 【如果救下麦仔，村子态度 cold】
    elif action != "stay" and village == "cold":
        $ choice_echo()
        ## A7-470  〔草案〕
        n "第二天早上，我们经过小卖部，门口小木椅上的大叔们都不约而同地把脸转开了。" id A7_470
    ## A7-K8c 【如果不插手】不播放
    elif action == "stay":
        pass


label proto_act8:

    call start_day(60)
    scene bg chapter_08 with dissolve
    stop ambient fadeout 2.0
    pause
    scene bg dusk_classroom with dissolve
    play ambient cicadas volume 0.4 fadeout 2.0 fadein 2.0 if_changed
    ## A8-010  〔草案〕
    n "最后一节课下课后，孩子们没有马上走。有人往我手里塞了一颗糖，有人在我的本子上画了一朵歪歪扭扭的花。" id A8_010
    ## A8-K4 条件分支：braid_upset  〔新增〕
    ## A8-K4a 【如果编辫子时男孩生气地走开了】
    if "boy" in braid_upset:
        $ choice_echo()
        ## A8-012  〔新增〕
        n "那天来找我修电扇的男孩，没有过来。" id A8_012
    ## A8-K4b 【否则】
    elif "boy" not in braid_upset:
        $ choice_echo()
        ## A8-014  〔新增〕
        n "那天找我修电扇的男孩，往我手里塞了一张画：一台呼呼转着的电扇，旁边歪歪扭扭地写着“谢谢老师”。" id A8_014

    ## A8-020  〔草案〕
    n "人慢慢散了。小麦留在最后。" id A8_020
    ## A8-030  〔草案〕
    n "她站在讲台边，手指一下一下地抠着讲台的木边。" id A8_030
    ## A8-K0 条件分支：told_secret  〔改稿〕
    ## A8-K0a 【如果第七幕当着老师们说出了三妹的事】
    if told_secret:
        $ choice_echo()
        ## A8-032  〔新增〕
        mei "“[teacher_name]老师，三妹的事，是你跟别的老师说的吗？”" id A8_032
        ## A8-034  〔新增〕
        n "我点了点头。她没有再问，低下头，继续抠着讲台的木边。" id A8_034
        $ trust -= 1
    ## A8-K0b 【否则】不播放
    elif not told_secret:
        pass

    ## A8-040  〔草案〕
    mei "“[teacher_name]老师，你明年还会来吗？”" id A8_040
    ## A8-050  〔草案〕
    inner_teacher "她问得这么认真。我不想骗一个真诚的孩子，但是我也不想让她伤心。" id A8_050
    ## A8-060  〔草案〕
    inner_visitor "明年？离开这里以后，我就要回去上学了。以后的假期我会被学业和实习填满，这辈子……可能都不会再来这里了……" id A8_060
    ## A8-C1 选择：promise  〔建议〕
    menu:
        ## A8-070  〔草案〕
        n "我沉默了很久。" id A8_070
        ## A8-C1A
        "“会的。”":
            $ promise = "yes"
            ## A8-080  〔草案〕
            n "她笑了，露出那口很好的白牙。" id A8_080
            ## A8-090  〔草案〕
            mei "“说好了噢，那我明年等你。”" id A8_090
        ## A8-C1B
        "“明年还会有很多有意思的老师们来的。”":
            $ promise = "evade"
            ## A8-100  〔草案〕
            n "她看着我，看了很久。" id A8_100
            ## A8-110  〔草案〕
            mei "“哦。去年的那些老师也是这么说的。”" id A8_110
        ## A8-C1C
        "“明年应该不会再来了，但是老师会很想念你们的。”":
            $ promise = "no"
            ## A8-120  〔草案〕
            n "她点点头。" id A8_120
            ## A8-130  〔草案〕
            mei "“我知道。”" id A8_130
            ## A8-140  〔草案〕
            n "她转过头，看着窗外的山。" id A8_140
        ## A8-C1D
        "沉默。":
            $ promise = "silent"
            ## A8-150  〔草案〕
            n "我张了张嘴，什么也没说出来。" id A8_150
            ## A8-160  〔草案〕
            n "她等了一会儿，然后说：“[teacher_name]老师再见。”转身跑出了教室。" id A8_160

    scene bg night_classroom with dissolve
    play ambient crickets volume 0.6 fadeout 2.0 fadein 2.0 if_changed
    ## A8-C2 选择：gift  〔草案〕
    menu:
        ## A8-170  〔草案〕
        n "那天晚上，我躺在教室的地铺上，想着要不要给她留下点什么。" id A8_170
        ## A8-C2A
        "什么也不留。":
            $ gift = "none"
            ## A8-180  〔草案〕
            n "我能给她的东西，在我离开以后，好像都不会再有什么意义。" id A8_180
        ## A8-C2B
        "留下一台儿童相机。" if camera:
            $ gift = "camera"
            ## A8-190  〔草案〕
            n "我带了几台便宜的儿童相机，本来是想上一节摄影课，最后没来得及上。我把其中一台放进她的课桌，旁边留了一张纸条：想拍什么，就拍什么。" id A8_190
        ## A8-C2C
        "留下那根发绳。" if not camera:
            $ gift = "hairtie"
            ## A8-200  〔草案〕
            n "我从手腕上褪下最后一根小黄鸭发绳，和那天给她编辫子用的是一对，放进了她的课桌。" id A8_200
        ## A8-C2D
        "留下一封信。":
            $ gift = "letter"
            ## A8-210  〔草案〕
            n "我写了很久，写了又划掉，划掉又写。最后，我把信折好，放进了她的课桌。" id A8_210

    scene bg village_gate with dissolve
    play ambient cicadas volume 0.4 fadeout 2.0 fadein 2.0 if_changed
    ## A8-220  〔草案〕
    n "第二天一早，三轮车停在村口的老槐树下，要载我们翻过山，去最近的镇子。" id A8_220
    ## A8-225  〔新增〕
    n "路两边的院坝上，家家都铺满了刚收下来的新玉米。" id A8_225
    ## A8-K1 条件分支：village  〔草案〕
    ## A8-K1a 【如果 village = "intact"】
    if village == "intact":
        $ choice_echo()
        ## A8-230  〔草案〕
        n "小卖部门口站着几个村民。一位大叔往我手里塞了一袋煮鸡蛋。" id A8_230
        ## A8-240  〔草案〕
        villager "“路上吃。”" id A8_240
    ## A8-K1b 【如果 village = "cold"】
    elif village == "cold":
        $ choice_echo()
        ## A8-250  〔草案〕
        n "路上空荡荡的。小卖部的门关着。" id A8_250

    play sound tricycle volume 0.3 fadein 1.0
    ## A8-K2 条件分支：gift／trust  〔草案〕
    ## A8-K2a 【如果 什么也不留 或 发绳，trust ≥ 4】
    if gift in ("none", "hairtie") and trust >= 4:
        $ choice_echo()
        ## A8-260  〔草案〕
        n "三轮车开动的时候，我看见她跑着追了上来，辫子一甩一甩的。早就追不上了，她还在跑。" id A8_260
    ## A8-K2b 【如果 什么也不留 或 发绳，trust 2–3】
    elif gift in ("none", "hairtie") and 2 <= trust <= 3:
        $ choice_echo()
        ## A8-270  〔草案〕
        n "她站在村口，抬起手，一直挥，直到车拐过了山脚。" id A8_270
    ## A8-K2c 【如果 什么也不留 或 发绳，trust ≤ 1】
    elif gift in ("none", "hairtie") and trust <= 1:
        $ choice_echo()
        ## A8-280  〔草案〕
        n "她没有出来。我一直看着那条路，直到村子消失在山的后面。" id A8_280
    ## A8-K2d 【如果 儿童相机 或 信】
    elif gift in ("camera", "letter"):
        $ choice_echo()
        ## A8-290  〔草案〕
        n "三轮车开动了。我回头看了一眼，老槐树下站着几个孩子，我没有看清里面有没有她。" id A8_290


label proto_epilogue:

    scene bg chapter_09 with dissolve
    stop ambient fadeout 2.0
    stop sound fadeout 3.0
    pause
    scene bg chat with dissolve
    ## EP-010  〔建议〕
    chat_n "九月。" id EP_010
    ## EP-K0 条件分支：camera  〔改稿〕
    ## EP-K0a 【如果 camera = True】
    if camera:
        ## EP-012  〔改稿〕
        chat_n "影展截止的前一晚，我把那个夏天的素材导进了电脑。" id EP_012
        ## EP-014  〔改稿〕
        chat_n "手机亮了一下。是她发来的。" id EP_014
    ## EP-K0b 【如果 camera = False】不播放
    elif not camera:
        pass

    ## EP-C1 选择：chat_reply  〔建议〕
    menu:
        ## EP-020  〔建议〕
        chat_mei "[teacher_name]老师，你到家了吗？" id EP_020
        ## EP-C1A
        "到啦！你在学校还好吗？":
            $ chat_reply = "now"
            ## EP-021  〔新增〕
            chat_me "到啦！你在学校还好吗？" id EP_021
        ## EP-C1B
        "到了，最近有点忙，晚点跟你说。":
            $ chat_reply = "brief"
            ## EP-023  〔新增〕
            chat_me "到了，最近有点忙，晚点跟你说。" id EP_023
        ## EP-C1C
        "晚点再回。":
            $ chat_reply = "later"
            ## EP-025  〔新增〕
            chat_n "我把手机扣在桌上，想着晚点再回。" id EP_025

    ## EP-K5 条件分支：festival  〔改稿〕
    ## EP-K5a 【如果 camera = True 且拍了素材】
    if camera and footage:
        $ choice_echo()
        ## EP-C2 选择：festival  〔改稿〕
        menu:
            ## EP-022  〔改稿〕
            chat_n "截止时间是明天中午十二点。" id EP_022
            ## EP-C2A
            "投完整的版本。":
                $ festival = "full"
                ## EP-024  〔新增〕
                chat_n "我投了完整的版本。十一月，片子入围了。" id EP_024
                ## EP-026  〔新增〕
                chat_n "放映结束后，有个观众举手问：“那个女孩现在怎么样了？”" id EP_026
                ## EP-028  〔新增〕
                chat_n "我站在台上，答不上来。" id EP_028
            ## EP-C2B
            "剪掉那些镜头再投。":
                $ festival = "cut"
                ## EP-032  〔新增〕
                chat_n "我把那些镜头剪掉了，只留下山和云。片子很干净。" id EP_032
                ## EP-034  〔新增〕
                chat_n "它没有入围。我知道，最好的镜头是我自己剪掉的。" id EP_034
            ## EP-C2C
            "先问问她。":
                $ festival = "ask"
                ## EP-036  〔新增〕
                chat_n "我问她，片子里有她，能不能给很多很多人看。" id EP_036
                ## EP-038  〔新增〕
                chat_mei "可以呀！" id EP_038
                ## EP-039  〔新增〕
                chat_n "她回得很快。我把片子投了出去。我不知道，一个孩子明不明白自己答应了什么。" id EP_039
            ## EP-C2D
            "不投了。":
                $ festival = "none"
                ## EP-043  〔新增〕
                chat_n "我关掉了电脑。素材留在了硬盘里。" id EP_043

    ## EP-K5b 【如果 camera = True 但只有空镜】
    elif camera and not footage:
        $ choice_echo()
        ## EP-045  〔新增〕
        chat_n "我还是把片子投了。只有几个山的空镜，片子太单薄，投了也没有回音。" id EP_045
    ## EP-K5c 【如果 camera = False】不播放
    elif not camera:
        pass

    ## EP-K1 条件分支：dog  〔建议〕
    ## EP-K1a 【如果麦仔断了腿活下来】
    if dog == "lame":
        $ choice_echo()
        ## EP-030  〔建议〕
        chat_n "十月。" id EP_030
        ## EP-040  〔建议〕
        chat_mei "〔图片〕麦仔会走路了，就是有点瘸" id EP_040
        ## EP-C3 选择：pass  〔改稿〕
        menu:
            ## EP-C3A
            "腿还疼吗？要好好照顾它。":
                pass
                ## EP-041  〔新增〕
                chat_me "腿还疼吗？要好好照顾它。" id EP_041
            ## EP-C3B
            "它看起来真精神！替我摸摸它。":
                pass
                ## EP-042  〔新增〕
                chat_me "它看起来真精神！替我摸摸它。" id EP_042
            ## EP-C3C
            "不回。":
                pass

    ## EP-K1b 【如果麦仔完好地活下来】
    elif dog == "fine":
        $ choice_echo()
        ## EP-050  〔新增〕
        chat_n "十月。" id EP_050
        ## EP-060  〔新增〕
        chat_mei "〔图片〕麦仔今天又送我到山顶了" id EP_060
        ## EP-C4 选择：pass  〔改稿〕
        menu:
            ## EP-C4A
            "它看起来真精神！替我摸摸它。":
                pass
                ## EP-061  〔新增〕
                chat_me "它看起来真精神！替我摸摸它。" id EP_061
            ## EP-C4B
            "真好。你也要好好的。":
                pass
                ## EP-062  〔新增〕
                chat_me "真好。你也要好好的。" id EP_062
            ## EP-C4C
            "不回。":
                pass

    ## EP-K1c 【如果麦仔死了】不播放
    elif dog == "dead":
        pass

    ## EP-070  〔建议〕
    chat_n "十二月。" id EP_070
    ## EP-080  〔建议〕
    chat_mei "[teacher_name]老师你在干嘛" id EP_080
    ## EP-090  〔建议〕
    chat_n "我三天以后才看到这条消息。" id EP_090
    ## EP-C5 选择：pass  〔改稿〕
    menu:
        ## EP-C5A
        "在准备期末考试。你呢？":
            pass
            ## EP-091  〔新增〕
            chat_me "在准备期末考试。你呢？" id EP_091
        ## EP-C5B
        "刚看到，最近太忙了，对不起。":
            pass
            ## EP-092  〔新增〕
            chat_me "刚看到，最近太忙了，对不起。" id EP_092
        ## EP-C5C
        "不回。":
            pass

    ## EP-K2 条件分支：promise  〔建议〕
    ## EP-K2a 【如果 promise = "yes"】
    if promise == "yes":
        $ choice_echo()
        ## EP-100  〔建议〕
        chat_n "第二年七月。" id EP_100
        ## EP-110  〔建议〕
        chat_mei "[teacher_name]老师，你什么时候来？" id EP_110
        ## EP-C6 选择：pass  〔改稿〕
        menu:
            ## EP-C6A
            "今年可能来不了了……对不起。":
                pass
                ## EP-111  〔新增〕
                chat_me "今年可能来不了了……对不起。" id EP_111
            ## EP-C6B
            "再等等，老师争取。":
                pass
                ## EP-112  〔新增〕
                chat_me "再等等，老师争取。" id EP_112
            ## EP-C6C
            "不回。":
                pass

    ## EP-K2b 【其他】不播放
    elif promise != "yes":
        pass

    call chat_clear
    scene bg memory with dissolve
    ## EP-130  〔草案〕
    n "很多年以后。" id EP_130
    ## EP-K3 条件分支：gift／trust  〔草案〕
    ## EP-K3a 【如果 儿童相机，trust ≥ 4，麦仔断了腿】
    if gift == "camera" and trust >= 4 and dog == "lame":
        $ choice_echo()
        ## EP-140  〔草案〕
        n "有一天，我收到一个没有寄件地址的信封。里面是一叠照片：玉米地，河，一条瘸了腿的黄狗。还有一张是我，站在教室门口，眯着眼看太阳。我不记得她什么时候拍的。" id EP_140
    ## EP-K3b 【如果 儿童相机，trust ≥ 4，麦仔完好】
    elif gift == "camera" and trust >= 4 and dog == "fine":
        $ choice_echo()
        ## EP-150  〔新增〕
        n "有一天，我收到一个没有寄件地址的信封。里面是一叠照片：玉米地，河，一条蹲在山顶的黄狗。还有一张是我，站在教室门口，眯着眼看太阳。我不记得她什么时候拍的。" id EP_150
    ## EP-K3c 【如果 儿童相机，trust ≥ 3，麦仔死了（不插手时 trust 最多为 3）】
    elif gift == "camera" and trust >= 3 and dog == "dead":
        $ choice_echo()
        ## EP-160  〔新增〕
        n "有一天，我收到一个没有寄件地址的信封。里面是一叠照片：玉米地，河，空荡荡的山顶。还有一张是我，站在教室门口，眯着眼看太阳。我不记得她什么时候拍的。" id EP_160
    ## EP-K3d 【如果 儿童相机，trust 2–3（麦仔死了且 trust = 3 的除外）】
    elif gift == "camera" and 2 <= trust <= 3 and not (dog == "dead" and trust == 3):
        $ choice_echo()
        ## EP-170  〔草案〕
        n "那年秋天，我收到过几张照片。玉米地。山顶上的天空。照片里没有人。" id EP_170
    ## EP-K3e 【如果 儿童相机，trust ≤ 1】
    elif gift == "camera" and trust <= 1:
        $ choice_echo()
        ## EP-180  〔草案〕
        n "后来听别的老师说，新学期开学的时候，那台相机还放在讲台上。没有人拿走。" id EP_180
    ## EP-K3f 【如果 信】
    elif gift == "letter":
        $ choice_echo()
        ## EP-190  〔草案〕
        n "我始终不知道她什么时候读了那封信，读的时候又在想什么。" id EP_190
    ## EP-K3g 【如果 什么也不留 或 发绳】不播放
    elif gift in ("none", "hairtie"):
        pass

    ## EP-200  〔草案〕
    n "很多年以后，那个雨夜我还记得，可我已经想不起她的声音了。" id EP_200
    ## EP-K4 条件分支：camera  〔草案〕
    ## EP-K4a 【如果 camera = True 且没有投影展】
    if camera and festival in (None, "none"):
        ## EP-210  〔草案〕
        n "那些我拍下来的画面，倒是一帧都没有丢。我还能把它们一遍遍地放出来看。可每次看，都像在看别人的夏天。" id EP_210
    ## EP-K4b 【否则】不播放
    elif not (camera and festival in (None, "none")):
        pass

    ## EP-220  〔草案〕
    n "那两个月对她来说意味着什么，我不知道。" id EP_220
    ## EP-230  〔草案〕
    n "我甚至不知道，我该怎么回忆你。" id EP_230
    ## EP-240  〔草案〕
    n "更多的，就留在那片玉米地里吧。来年秋天，她会长得很好吧。" id EP_240

label proto_credits:

    scene black with dissolve
    ## CRD-K4 条件分支：maizai_shot  〔新增〕
    ## CRD-K4a 【如果第五幕拍下了麦仔】
    if maizai_shot:
        ## CRD-005  〔新增〕
        centered "山路上，一条黄狗冲上来，一头扑到一个女孩腿上。" id CRD_005
    ## CRD-K4b 【否则】不播放
    elif not maizai_shot:
        pass

    ## CRD-K1 条件分支：footage  〔草案〕
    ## CRD-K1a 【如果 footage 包含 "grandpa"】
    if "grandpa" in footage:
        ## CRD-010  〔草案〕
        centered "老人想把毯子往上拉，拉不动，把脸转向了墙。" id CRD_010
    ## CRD-K1b 【否则】不播放
    elif "grandpa" not in footage:
        pass

    ## CRD-K5 条件分支：geese_shot  〔新增〕
    ## CRD-K5a 【如果第六幕拍下了麦仔追鹅】
    if geese_shot:
        ## CRD-015  〔新增〕
        centered "阳光下，一群大肥鹅张着翅膀逃窜，一条黄狗在后面不远不近地追。" id CRD_015
    ## CRD-K5b 【否则】不播放
    elif not geese_shot:
        pass

    ## CRD-K2 条件分支：footage  〔草案〕
    ## CRD-K2a 【如果 footage 包含 "river"】
    if "river" in footage:
        ## CRD-020  〔草案〕
        centered "河边，一个女孩的话说到一半，停住了。" id CRD_020
    ## CRD-K2b 【否则】不播放
    elif "river" not in footage:
        pass

    ## CRD-K3 条件分支：footage  〔草案〕
    ## CRD-K3a 【如果 camera = True 且什么都没拍】
    if camera and not footage and not geese_shot and not maizai_shot:
        ## CRD-030  〔草案〕
        centered "几个山的空镜。没有别的。" id CRD_030
    ## CRD-K3b 【否则】不播放
    elif not (camera and not footage and not geese_shot and not maizai_shot):
        pass

    ## CRD-040  〔草案〕
    centered "《我不知道该如何回忆你》" id CRD_040

label proto_end:

    scene black with dissolve
    ## END-010  〔草案〕
    centered "完" id END_010
    return
