## 视觉效果与声音设置 ###############################################################

## 环境音频道：自动循环，音量跟随设置里的"音效"滑块。
## 用法：play ambient "audio/ambient/wind.ogg" fadein 1.0
##       stop ambient fadeout 1.0
init python:
    renpy.music.register_channel("ambient", mixer="sfx", loop=True)
    ## 教室里孩子们的嘈杂声单独一个频道，加低通滤波，听起来隔了一层、不抢台词。
    renpy.music.register_channel("crowd", mixer="sfx", loop=True)

    def play_crowd(fadein=2.0, volume=0.5):
        renpy.music.set_audio_filter("crowd", renpy.audio.filter.Lowpass(700))
        renpy.music.play(audio.classroom, channel="crowd", fadein=fadein, relative_volume=volume, if_changed=True)

## 选择留下的印记：某段台词因为之前的选择才出现时（主稿里的条件分支），
## 对话框正上方浮出一行字，停 5 秒后淡出。由 tools/build_script.py 在分支开头生成 $ choice_echo()。
init python:
    def choice_echo():
        renpy.hide_screen("choice_echo")     # 先隐藏再显示，连续两段分支时重新计时
        renpy.show_screen("choice_echo")

transform choice_echo_fade:
    alpha 0.0
    linear 0.6 alpha 1.0
    pause 5.0
    linear 1.5 alpha 0.0

screen choice_echo():
    zorder 50
    text _("你以前的选择在这一帧的走向里留下了印记") style "choice_echo_text" at choice_echo_fade
    timer 7.2 action Hide("choice_echo")

## 对话框（上沿 y=750）正上方居中，压在背景图上，用浅色字。
style choice_echo_text is default:
    size 27
    italic True
    color "#f3eee8"
    xalign 0.5
    ypos 738 yanchor 1.0

## 环境音（ambient 频道循环）。剧本里 play ambient cicadas fadein 2.0 等。
define audio.classroom = "audio/ambient/classroom_noise_need_to_blur.mp3"
define audio.cicadas = "audio/ambient/daytime-cicades.mp3"
define audio.crickets = "audio/ambient/oxidvideos-crickets-at-night-406603.mp3"
define audio.stream = "audio/ambient/dragon-studio-quiet-stream-420899.mp3"
define audio.wind = "audio/ambient/freesound_community-bushes-medium-heavy-wind-in-dry-vegetation-19537.mp3"
define audio.chickens = "audio/ambient/freesound_community-chickens-30684.mp3"
define audio.rain_roof = "audio/ambient/freesound_community-under-the-metal-roof-while-raining-22324.mp3"
define audio.storm = "audio/ambient/loswin23-thunderstorm-with-rain-516367.mp3"

## 音效（sound 频道，同时响两个时第二个用 audio 频道）。铃声、三轮车等音量调低。
define audio.school_bell = "audio/SFX/dobcommunications-vintage-interior-school-bell-ringing-376334.mp3"
define audio.geese = "audio/SFX/freesound_community-geese-freaking-out-25661.mp3"
define audio.knock = "audio/SFX/freesound_community-knocking-on-a-window-104412.mp3"
define audio.hose = "audio/SFX/freesound_community-water-hose-103476.mp3"
define audio.tricycle = "audio/SFX/gregorquendel_sounddesign-motorcycle-engine-start-and-drive-away-137243.mp3"
define audio.thunder = "audio/SFX/gregorquendel_sounddesign-thunder-lightning-i-without-rain-wind-background-noise-136313.mp3"
define audio.bark = "audio/SFX/lazychillzone-dog-barking-224786.mp3"
define audio.splash = "audio/SFX/nematoki-water-splash-stone-fell-in-water-332077.mp3"
## 拍照小游戏：占位的合成快门声、过片声（tools/gen_camera_ui.py 生成），以后可换成录音。
define audio.shutter = "audio/SFX/shutter_synth.wav"
define audio.film_advance = "audio/SFX/film_advance_synth.wav"

## 回忆画面：轻微模糊、降低饱和度。
## 用法：show cg braid at memory
transform memory:
    blur 4
    matrixcolor SaturationMatrix(0.6)

## 从模糊慢慢变清楚（例如结尾重看同一张图）。
transform memory_clear:
    blur 8
    matrixcolor SaturationMatrix(0.4)
    linear 2.0 blur 0 matrixcolor SaturationMatrix(1.0)

## 黑屏 / 停顿：请用可点击跳过的写法，如
##     scene black with fade
##     pause 1.5
## 不要用 renpy.pause(hard=True)。

## 冷开场结束后：明显地淡出到全黑，停一会儿，再淡入（淡出 2 秒、全黑 1.5 秒、淡入 2 秒）。
define slowfade = Fade(2.0, 1.5, 2.0)
