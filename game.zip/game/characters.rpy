## 角色定义 ######################################################################
##
## 名字栏的英文写在 story/bilingual_script.md 的“名字栏”表里，由生成脚本写入翻译。
## 内心声音靠"名字 + 颜色"一起区分，不只依赖颜色。

define n = Character(None)                     # 旁白

## 玩家（老师）：名字栏显示花名。TeacherName 负责按语言显示预设名、转义文本标签。
define me = Character("[teacher_name]", who_color="#8a6a4a")

## 名字栏按“我”此刻知道的身份显示：小麦被认出之前是“？”，议论她的女生始终不知姓名。
define unknown_girl = Character(_("？"),     who_color="#a0522d")
define mei          = Character(_("小麦"),     who_color="#a0522d")
define girl_a       = Character(_("女生甲"), who_color="#7a6a8a")
define girl_b       = Character(_("女生乙"), who_color="#7a6a8a")
define boy          = Character(_("男孩"),   who_color="#5f7a91")
define boys         = Character(_("男孩们"), who_color="#5f7a91")
define team         = Character(_("支教队"), who_color="#6a7f5a")
define villager     = Character(_("大叔"),   who_color="#7a6650")
define girl         = Character(_("女生"),   who_color="#7a6a8a")
define grandpa      = Character(_("爷爷"),   who_color="#7a6650")
define mom          = Character(_("小麦的妈妈"), who_color="#7a6650")

## 尾声的线上聊天：NVL 模式，消息逐条累积在屏幕上。换一个时间点前 call chat_clear。
define chat_mei = Character(_("小麦"), kind=nvl, who_color="#a0522d")
## “我”的回复：名字栏显示花名，颜色和口头对白里的“我”一致。
define chat_me  = Character("[teacher_name]", kind=nvl, who_color="#8a6a4a")
define chat_n   = Character(None, kind=nvl, what_italic=True, what_color="#6a6a6a")

## 本稿的内心声音：名字栏标“心声”，文字颜色偏冷、偏淡，和口头对白区分。
define inner_teacher = Character(_("老师・心声"), who_color="#4f7590", what_color="#3d6580")
define inner_visitor = Character(_("过客・心声"), who_color="#8a6a48", what_color="#7a5a3a")
## 第三个声音只在 camera = True 时出现。
define inner_lens    = Character(_("摄影师・心声"), who_color="#5a6e5a", what_color="#4a5e4a")

## 正文中 *小麦* 的强调样式：{=em}小麦{/=em}
style em:
    bold True
    color "#a0522d"

## 以下为早期模板角色，dev_example.rpy 仍在使用，本稿不用。
define t = Character("我")
define jm = Character("示例角色", who_color="#a0522d")
define v_cam  = Character("〔拍摄者〕",   who_color="#5f7a91", what_color="#4a4a4a")
define v_care = Character("〔关怀〕",     who_color="#a87b4f", what_color="#4a4a4a")
define v_dbt  = Character("〔自我怀疑〕", who_color="#7a7a7a", what_color="#4a4a4a")
