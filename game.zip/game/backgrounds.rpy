## 背景 ##########################################################################
##
## 目前全部是占位背景（纯色渐变 + 左上角“占位背景”字样），不引用任何图片文件。
## 以后换成自己的照片，只改这一个文件：
##
##     1. 把照片放进 game/images/bg/，建议 1920×1080 的 jpg/png/webp。
##     2. 把对应一行改成例如：
##            image bg dusk_classroom = "images/bg/dusk_classroom.jpg"
##     3. 剧本里的 scene bg dusk_classroom 不需要改。
##
## 场景名在 story/bilingual_script.md 的〔场景〕指令里使用。
## 左上角的占位说明只显示当前语言，文字和英文写在主稿 UI 部分（UI-100 起）。

init python:

    def _placeholder_label(st, at, label, color):
        # 每次互动重新翻译，切换语言后立即更新。
        return Text(__(label), size=24, color=color), None

    def placeholder_bg(top, bottom, label, dark_label=False, bands=54):
        """竖向简单渐变（分带填色）+ 占位说明文字。浅色背景用 dark_label=True。"""
        top, bottom = Color(top), Color(bottom)
        h = config.screen_height // bands
        parts = []
        for i in range(bands):
            parts += [(0, i * h), Solid(top.interpolate(bottom, i / (bands - 1.0)), xsize=config.screen_width, ysize=h + 1)]
        color = "#00000080" if dark_label else "#ffffffa0"
        parts += [(36, 24), DynamicDisplayable(_placeholder_label, label=label, color=color)]
        return Composite((config.screen_width, config.screen_height), *parts)

## 纯色背景（第二天醒来、还没进教室时用）。
image bg plain = Solid("#f3eee8")

## 章节封面（00 序幕 … 08 第八幕，09 尾声），封面里已写章节名。
## 中文版在 images/chapter/，英文版在 images/chapter/en/，按当前语言切换。
init python:
    for _i in range(10):
        renpy.image("bg chapter_%02d" % _i, ConditionSwitch(
            "_preferences.language == 'english'", "images/chapter/en/chapter_%02d_en.png" % _i,
            "True", "images/chapter/chapter_%02d.png" % _i,
        ))

image bg intro             = "images/bg/intro.jpg"
image bg prologue          = placeholder_bg("#59606e", "#2f343e", _("占位背景：出发前的名单"))
image bg dusk_classroom    = "images/bg/dusk_classroom.jpg"
image bg old_dorm          = placeholder_bg("#4a514f", "#1e2221", _("占位背景：废弃的旧宿舍"))
image bg shop              = "images/bg/shop.jpg"
image bg night_classroom   = "images/bg/night_classroom.jpg"
image bg morning_classroom = "images/bg/morning_classroom.jpg"
image bg village_restaurant = "images/bg/village_restaurant.jpg"
image bg noon_classroom    = "images/bg/dusk_classroom.jpg"
image bg bathroom          = "images/bg/bathroom.jpg"

## 第五幕起（草案 2026-10-21）
## 第五幕去小麦家：先是田埂/山坡土路（country_path），进竹林后换 mountain_path。
image bg country_path      = "images/bg/country_path.jpg"
image bg mountain_path     = "images/bg/mountain_path.jpg"
image bg mei_yard          = "images/bg/mei_yard.jpg"
image bg mei_house         = "images/bg/mei_house.jpg"
## 狗追鹅那场整张图上移一个字幕框的高度（330px），下面垫草地绿，狗和鹅就不会被字幕挡住。
image bg goose_meadow      = Composite((1920, 1080), (0, 0), Solid("#89913e"), (0, -330), "images/bg/goose_meadow.jpg")
image bg river_bend        = "images/bg/river_bend.jpg"
image bg cornfield         = "images/bg/cornfield.jpg"
## 雨夜里教室的窗（冷开场、第七幕小麦敲窗求助）；第七幕出门找狗以后仍用 rain_night。
image bg rain_classroom    = "images/bg/rainy_night.jpg"
image bg rain_night        = "images/bg/rain_night.jpg"
image bg chicken_coop      = "images/bg/rain_night.jpg"
image bg village_gate      = "images/bg/village_gate.jpg"
image bg chat              = placeholder_bg("#2a2c33", "#14151a", _("占位背景：离开之后"))
image bg memory            = placeholder_bg("#d9d2c5", "#8f8676", _("占位背景：很多年以后"), dark_label=True)
